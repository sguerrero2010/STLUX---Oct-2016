/**
  ******************************************************************************
  * @file stlux_btm.c
  * @brief This file contains all the functions/macros for the Basic Timer (BSCTIM).
  * @author STMicroelectronics
  * @version V2.0
  * @date 27/10/2015
  ******************************************************************************
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  ******************************************************************************
  */

#ifndef __STLUX_BTM_H
#define __STLUX_BTM_H

#if defined(_STNRG388A_) || defined(_STNRG328A_) || defined(_STNRG288A_)
#include "stlux.h"

/* Includes ------------------------------------------------------------------*/
/* Exported types ------------------------------------------------------------*/
// Basic Timer Selector.
typedef enum {
  BTM_0  = ((u8)0x01),
  BTM_1  = ((u8)0x02)
} BTM_Selection_TypeDef;

// Basic Timer Clock Source Selector.
typedef enum {
	CLK_BTM_SOURCE_HSI    = (u8)0x00, /*!< Clock Source HSI. */
	CLK_BTM_SOURCE_HSE    = (u8)0x01, /*!< Clock Source PLL. */
	CLK_BTM_SOURCE_LSI    = (u8)0x02, /*!< Clock Source LSI. */
	CLK_BTM_SOURCE_PLL    = (u8)0x03 /*!< Clock Source HSE. */
} CLK_BTM_Source_TypeDef;

typedef enum {
  BTM_IT_LEV_HIGH       = (u8)0x01,     /*!< Set Interrupt Sensitivity Level on high level or rising edge */
  BTM_IT_LEV_LOW        = (u8)(~0x01)   /*!< Set Interrupt Sensitivity Level on low level or falling edge */
} BTM_ITPolarity_TypeDef;

// Interrupt Trigger system configuration.
typedef enum {
  BTM_IT_SEL_EDGE       = (u8)0x04,     /*!< Set Interrupt Trigger on rising/falling edge */
  BTM_IT_SEL_LEVEL      = (u8)0x06,     /*!< Set Interrupt Trigger on high/low level */
  BTM_IT_SEL_LEVWAKEUP  = (u8)(~0x06)   /*!< Set Interrupt Trigger on high/low asynchronous level with wakeup capability */
}BTM_ITTrigger_TypeDef;

// Interrupt Type system configuration.
typedef enum {
  BTM_IT_TYPE_IRQ       = (u8)(~0x10),     /*!< Set Interrupt Type to Maskable Interrupt */
  BTM_IT_TYPE_NMI       = (u8)0x10,     /*!< Set Interrupt Type to Non Maskable Interrupt */
  BTM_IT_TYPE_POL       = (u8)0x00     /*!< Set to Polling mode. No Interrupt is generated */
}BTM_ITType_TypeDef; 

/* Exported constants --------------------------------------------------------*/

/* Exported macros -------------------------------------------------------------*/
/* Exported variables ---------------------------------------------------------*/

/* Public functions ----------------------------------------------------------*/

void BTM_Reset(void);
void BTM_Config(BTM_Selection_TypeDef BTMx, CLK_BTM_Source_TypeDef CLK_SRC,u8 CLK_DIV, u8 CLK_CNT, BTM_ITPolarity_TypeDef IT_LEV, BTM_ITTrigger_TypeDef IT_SEL, BTM_ITType_TypeDef IT_TYPE);
void BTM_ITConfig(BTM_Selection_TypeDef BTMx, FunctionalState NewState);
void BTM_ITClear(BTM_Selection_TypeDef BTMx);
void BTM_Cmd(BTM_Selection_TypeDef BTMx, FunctionalState NewState);
#endif //if defined STNRG
#endif //__STLUX_BTM_H

/******************* (C) COPYRIGHT 2015 STMicroelectronics *****END OF FILE****/
