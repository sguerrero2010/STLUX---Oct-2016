/**
  ******************************************************************************
  * @file stlux_gpio.h
  * @brief This file contains function definitions GPIOs of STLUX / STNRG
  * @author STMicroelectronics
  * @version V2.0
  * @date 27/10/2015
  ******************************************************************************
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __STLUX_GPIO_H
#define __STLUX_GPIO_H

/* Includes ------------------------------------------------------------------*/
#include "stlux.h"



/* Exported variables ------------------------------------------------------- */
/* Exported types ------------------------------------------------------------*/

/** @addtogroup GPIO_Exported_Types
  * @{
  */

/**
  * @brief GPIO modes
  *
  * Bits definitions:
  * - Bit 7: 0 = INPUT mode
  *          1 = OUTPUT mode
  *          1 = PULL-UP (input) or PUSH-PULL (output)
  * - Bit 5: 0 = No external interrupt (input) or No slope control (output)
  *          1 = External interrupt (input) or Slow control enabled (output)
  * - Bit 4: 0 = Low level (output)
  *          1 = High level (output push-pull) or HI-Z (output open-drain)
  */
typedef enum
{
  GPIO_MODE_IN_FL_NO_IT      = (u8)0x00,        /*!< 0b0000 0000 Input floating, no external interrupt */
  GPIO_MODE_IN_PU_NO_IT      = (u8)0x40,        /*!< 0b0100 0000 Input pull-up, no external interrupt */
  GPIO_MODE_IN_FL_IT         = (u8)0x20,        /*!< 0b0010 0000 Input floating, external interrupt */
  GPIO_MODE_IN_PU_IT         = (u8)0x60,        /*!< 0b0110 0000 Input pull-up, external interrupt */
  GPIO_MODE_OUT_OD_LOW_FAST  = (u8)0xA0,        /*!< 0b1010 0000 Output open-drain, low level, 10MHz */
  GPIO_MODE_OUT_PP_LOW_FAST  = (u8)0xE0,        /*!< 0b1110 0000 Output push-pull, low level, 10MHz */
  GPIO_MODE_OUT_OD_LOW_SLOW  = (u8)0x80,        /*!< 0b1000 0000 Output open-drain, low level, 2MHz */
  GPIO_MODE_OUT_PP_LOW_SLOW  = (u8)0xC0,        /*!< 0b1100 0000 Output push-pull, low level, 2MHz */
  GPIO_MODE_OUT_OD_HIZ_FAST  = (u8)0xB0,        /*!< 0b1011 0000 Output open-drain, high-impedance level,10MHz */
  GPIO_MODE_OUT_PP_HIGH_FAST = (u8)0xF0,        /*!< 0b1111 0000 Output push-pull, high level, 10MHz */
  GPIO_MODE_OUT_OD_HIZ_SLOW  = (u8)0x90,        /*!< 0b1001 0000 Output open-drain, high-impedance level, 2MHz */
  GPIO_MODE_OUT_PP_HIGH_SLOW = (u8)0xD0         /*!< 0b1101 0000 Output push-pull, high level, 2MHz */
}GPIO_Mode_TypeDef;

/**
  * @brief Definition of the GPIO pins. Used by the @ref GPIO_Init function in
  * order to select the pins to be initialized.
  */

typedef enum
{
  GPIO_PIN_0    = ((u8)0x01),  /*!< Pin 0 selected */
  GPIO_PIN_1    = ((u8)0x02),  /*!< Pin 1 selected */
  GPIO_PIN_2    = ((u8)0x04),  /*!< Pin 2 selected */
  GPIO_PIN_3    = ((u8)0x08),   /*!< Pin 3 selected */
  GPIO_PIN_4    = ((u8)0x10),  /*!< Pin 4 selected */
  GPIO_PIN_5    = ((u8)0x20),  /*!< Pin 5 selected */
  GPIO_PIN_6    = ((u8)0x40),  /*!< Pin 6 selected */
  GPIO_PIN_7    = ((u8)0x80),  /*!< Pin 7 selected */
  GPIO_PIN_LNIB = ((u8)0x0F),  /*!< Low nibble pins selected */
  GPIO_PIN_HNIB = ((u8)0xF0),  /*!< High nibble pins selected */
  GPIO_PIN_ALL  = ((u8)0xFF)   /*!< All pins selected */
}GPIO_Pin_TypeDef;

/**
  * @}
  */

/* Exported constants --------------------------------------------------------*/
/* Exported macros -----------------------------------------------------------*/

/* Exported functions ------------------------------------------------------- */
/** @addtogroup GPIO_Exported_Functions
  * @{
  */

void GPIO_Reset(GPIO_TypeDef* GPIOx);
void GPIO_Init(GPIO_TypeDef* GPIOx, GPIO_Pin_TypeDef GPIO_Pin, GPIO_Mode_TypeDef GPIO_Mode);
void GPIO_Write(GPIO_TypeDef* GPIOx, u8 PortVal);
void GPIO_WriteHigh(GPIO_TypeDef* GPIOx, GPIO_Pin_TypeDef PortPins);
void GPIO_WriteLow(GPIO_TypeDef* GPIOx, GPIO_Pin_TypeDef PortPins);
void GPIO_WriteReverse(GPIO_TypeDef* GPIOx, GPIO_Pin_TypeDef PortPins);
u8 GPIO_ReadInputData(GPIO_TypeDef* GPIOx);
u8 GPIO_ReadOutputData(GPIO_TypeDef* GPIOx);
BitStatus GPIO_ReadInputPin(GPIO_TypeDef* GPIOx, GPIO_Pin_TypeDef GPIO_Pin);
void GPIO_ExternalPullUpConfig(GPIO_TypeDef* GPIOx, GPIO_Pin_TypeDef GPIO_Pin, FunctionalState NewState);
/**
  * @}
  */

#endif /* __STLUX_GPIO_H */

/******************* (C) COPYRIGHT 2015 STMicroelectronics *****END OF FILE****/
