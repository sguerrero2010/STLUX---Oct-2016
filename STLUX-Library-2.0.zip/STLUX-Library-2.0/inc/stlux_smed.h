/**
  ******************************************************************************
  * @file stlux_smed.h
  * @brief This file contains function definitions System Timer of STLUX / STNRG
  * @author STMicroelectronics
  * @version V2.0
  * @date 27/10/2015
  ******************************************************************************
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __STLUX_SMED_H
#define __STLUX_SMED_H

#include "stm8s_type.h"
#include "stlux.h"





/*-----------------------------------------------------*/

typedef enum
{
    SMED_T0         = ((u8)0x04),
    SMED_T1         = ((u8)0x06),
    SMED_T2         = ((u8)0x08),
    SMED_T3         = ((u8)0x0A)
}SMED_TIMES_Typedef;

typedef enum
{
    SMED_T0_VAL         = ((u8)0x01),
    SMED_T1_VAL         = ((u8)0x02),
    SMED_T2_VAL         = ((u8)0x04),
    SMED_T3_VAL         = ((u8)0x08),
    SMED_DITHER_VAL     = ((u8)0x10)
}SMED_VALIDATE_TypeDef;

/*---Exported FUNCTIONS---*/




void SMED_Start(SMED_TypeDef* SMEDx);
void SMED_Stop(SMED_TypeDef* SMEDx);
u8 SMED_SetTime(SMED_TypeDef* SMEDx, SMED_TIMES_Typedef TimeRegister, u16 value); 
u8 SMED_ValidateTimeValues(SMED_TypeDef* SMEDx, SMED_VALIDATE_TypeDef TimeVal);

#define SMED_TrigSWEvent(x) SetBit(MSC->SMSWEV,x);

void SMED_Init(void); /* function from SMED configurator */

#endif


/*** (c) 2015  STMicroelectronics ****************** END OF FILE ***/

