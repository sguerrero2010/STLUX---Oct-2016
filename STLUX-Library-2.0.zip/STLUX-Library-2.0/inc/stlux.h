/**
  ******************************************************************************
  * @file stlux.h
  * @brief This file contains system definitions for STLUX / STNRG
  * @author STMicroelectronics
  * @version V2.0
  * @date 27/10/2015
  ******************************************************************************
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __STLUX_H
#define __STLUX_H

/******************************************************************************/
/*                   Library configuration section                            */
/******************************************************************************/
/* Check the used compiler */
#if defined(__CSMC__)
 #define _COSMIC_
#elif defined(__RCST7__)
 #define _RAISONANCE_
#elif defined(__ICCSTM8__)
 #define _IAR_
#else
 #error "Unsupported Compiler!"          /* Compiler defines not found */
#endif

/* In the following line adjust the value of External High Speed oscillator (HSE)
   used in your application */
#define HSE_VALUE ((u32)24000000) /*!< Value of the External oscillator in Hz */
#define HSI_VALUE ((u32)16000000) /*!< Value of the Internal HS oscillator in Hz */
#define LSI_VALUE ((u32)153600)   /*!< Value of the Internal LS oscillator in Hz */

#ifdef _COSMIC_
 #define FAR  @far
 #define NEAR @near
 #define TINY @tiny
 #define EEPROM @eeprom
 #define CONST  const
#elif defined (_RAISONANCE_) /* __RCST7__ */
 #define FAR  far
 #define NEAR data
 #define TINY page0
 #define EEPROM eeprom
 #define CONST  code
  /*!< Used with memory Models for code less than 64K */
  #define MEMCPY memcpy 
#else /*_IAR_*/
 #define FAR  __far
 #define NEAR __near
 #define TINY __tiny
 #define EEPROM __eeprom __no_init
 #define CONST  const
#endif /* __CSMC__ */

/* For FLASH routines, select whether pointer will be declared as near (2 bytes, handle
   code smaller than 64KB) or far (3 bytes, handle code larger than 64K) */
#define PointerAttr NEAR

/* Uncomment the line below to enable the FLASH functions execution from RAM */
#if !defined (RAM_EXECUTION)
/* #define RAM_EXECUTION  (1) */
#endif /* RAM_EXECUTION */

#ifdef RAM_EXECUTION
 #ifdef _COSMIC_
   #define IN_RAM(a) a
 #elif defined (_RAISONANCE_) /* __RCST7__ */
   #define IN_RAM(a) a inram
 #else /*_IAR_*/
  #define IN_RAM(a) __ramfunc a
 #endif /* _COSMIC_ */
#else 
  #define IN_RAM(a) a
#endif /* RAM_EXECUTION */

//Macro command to allocate a variable to an absolute address memory location
//so that in your code you can use ABSADR(a, b)
//i.e. ABSADR( 0x4898, STLUX_ID) will allocate the variable STLUX_ID at 0x4898 

#ifdef _COSMIC_
#define ABSADR(a,b) vu8 b @a 
#endif /* _COSMIC_ */

#ifdef _RAISONANCE_
#define ABSADR(a,b)  at a vu8 b 
#endif /* _RAISONANCE_ */

#ifdef _IAR_
#define ABSADR(a,b)  __no_init vu8 b @ a 
#endif /* _IAR_ */

/******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "stm8s_type.h"

/* Exported types and constants-----------------------------------------------*/
/** @addtogroup MAP_FILE_Exported_Types_and_Constants
  * @{
  */

/******************************************************************************/
/*                          IP registers structures                           */
/******************************************************************************/
/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
/**
  * @brief General Purpose I/Os (GPIO)
  */

typedef struct GPIO_struct
{
  vu8 ODR; /*!< Output Data Register */
  vu8 IDR; /*!< Input Data Register */
  vu8 DDR; /*!< Data Direction Register */
  vu8 CR1; /*!< Configuration Register 1 */
  vu8 CR2; /*!< Configuration Register 2 */
}
GPIO_TypeDef;

/** @addtogroup GPIO_Registers_Reset_Value
  * @{
  */
#define GPIO_ODR_RESET_VALUE ((u8)0x00)
#define GPIO_DDR_RESET_VALUE ((u8)0x00)
#define GPIO_CR1_RESET_VALUE ((u8)0x00)
#define GPIO_CR2_RESET_VALUE ((u8)0x00)

/**
  * @}
  */

/**
  * @brief Analog to Digital Converter (ADC)
  */
typedef struct ADC_struct
{
  vu8 CFG;      	/*!< Configuration Register  */
  vu8 SOC;      	/*!< Start of Conversion Register  */
  vu8 IER;      	/*!< Interrupt Enable Register  */
  vu8 SEQ;      	/*!< Sequencer Register  */
  vu8 DATL_0;      	/*!< Low part of Data 0 Converted  */
  vu8 DATH_0;      	/*!< High part of Data 0 Converted  */
  vu8 DATL_1;      	/*!< Low part of Data 1 Converted  */
  vu8 DATH_1;      	/*!< High part of Data 1 Converted  */
  vu8 DATL_2;      	/*!< Low part of Data 2 Converted  */
  vu8 DATH_2;      	/*!< High part of Data 2 Converted  */
  vu8 DATL_3;      	/*!< Low part of Data 3 Converted  */
  vu8 DATH_3;      	/*!< High part of Data 3 Converted  */
  vu8 DATL_4;      	/*!< Low part of Data 4 Converted  */
  vu8 DATH_4;      	/*!< High part of Data 4 Converted  */
  vu8 DATL_5;      	/*!< Low part of Data 5 Converted  */
  vu8 DATH_5;      	/*!< High part of Data 5 Converted  */
  vu8 DATL_6;      	/*!< Low part of Data 6 Converted  */
  vu8 DATH_6;      	/*!< High part of Data 6 Converted  */
  vu8 DATL_7;      	/*!< Low part of Data 7 Converted  */
  vu8 DATH_7;      	/*!< High part of Data 7 Converted  */
  vu8 SR; 			/*!< Status Register */
  vu8 DLYCNT;       /*!< SOC Delay Counter Register */
}
ADC_TypeDef;


/** @addtogroup ADC_Registers_Reset_Value
  * @{
  */
#define  ADC_CFG_RESET_VALUE  	((u8)0x01)
#define  ADC_SOC_RESET_VALUE  	((u8)0x00)
#define  ADC_IER_RESET_VALUE  	((u8)0x00)
#define  ADC_SEQ_RESET_VALUE  	((u8)0x00)
#define  ADC_DATL_RESET_VALUE 	((u8)0x00)
#define  ADC_DATH_RESET_VALUE 	((u8)0x00)
#define  ADC_SR_RESET_VALUE 	((u8)0x00)
#define  ADC_DLYCNT_RESET_VALUE ((u8)0x00)

/**
  * @}
  */

/** @addtogroup ADC_Registers_Bits_Definition
  * @{
  */
#define ADC_CFG_DATA_OUT_FORMAT_bit		(4) /*!< Data out format */
#define ADC_CFG_CIRCULAR_bit			(3) /*!< Circular mode */
#define ADC_CFG_SEQ_DATA_FIFO_FLUSH_bit	(2) /*!< DATA Buffer Flushing */
#define ADC_CFG_STOP_bit				(1) /*!< Stop the sequencer FSM */
#define ADC_CFG_PD_bit					(0) /*!< Power Down */
#define ADC_CFG_DATA_OUT_FORMAT			((u8)0x10) /*!< Data out format */
#define ADC_CFG_CIRCULAR				((u8)0x08) /*!< Circular mode */
#define ADC_CFG_SEQ_DATA_FIFO_FLUSH		((u8)0x04) /*!< DATA Buffer Flushing */
#define ADC_CFG_STOP					((u8)0x02) /*!< Stop the sequencer FSM */
#define ADC_CFG_PD						((u8)0x01) /*!< Power Down */

#define ADC_SOC_SOC_bit					(0) /*!< Start of Conversion */
#define ADC_SOC_SOC						((u8)0x01) /*!< Start of Conversion */

#define ADC_IER_SEQ_FULL_EN_bit			(2) /*!< Sequencer Buffer Full interrupt enable */
#define ADC_IER_EOS_EN_bit				(1) /*!< End of Sequence mode interrupt enable */
#define ADC_IER_EOC_EN_bit				(0) /*!< End of Conversion mode interrupt enable */
#define ADC_IER_SEQ_FULL_EN				((u8)0x04) /*!< Sequencer Buffer Full interrupt enable */
#define ADC_IER_EOS_EN					((u8)0x02) /*!< End of Sequence mode interrupt enable */
#define ADC_IER_EOC_EN					((u8)0x01) /*!< End of Conversion mode interrupt enable */

#define ADC_SEQ_GAIN_bit				(3) /*!< Gain x1.6 / x6.4 */
#define ADC_SEQ_GAIN					((u8)0x08) /*!< Gain Mask */
#define ADC_SEQ_CH						((u8)0x07) /*!< Channel Selection Mask */

#define ADC_SR_SEQ_FULL_bit				(2) /*!< Sequencer Buffer Full flag */
#define ADC_SR_EOS_bit					(1) /*!< End of Sequence mode flag */
#define ADC_SR_EOC_bit					(0) /*!< End of Conversion mode flag */
#define ADC_SR_SEQ_FULL_EN				((u8)0x04) /*!< Sequencer Buffer Full flag */
#define ADC_SR_EOS						((u8)0x02) /*!< End of Sequence mode flag */
#define ADC_SR_EOC						((u8)0x01) /*!< End of Conversion mode flag */

/**
  * @}
  */

/*----------------------------------------------------------------------------*/
/**
  * @brief Auto Wake Up (AWU) peripheral registers.
  */

typedef struct AWU_struct
{
  vu8 CSR; /*!< AWU Control status register */
  vu8 APR; /*!< AWU Asynchronous prescalar buffer */
  vu8 TBR; /*!< AWU Time base selection register */
}
AWU_TypeDef;

/** @addtogroup AWU_Registers_Reset_Value
  * @{
  */

#define AWU_CSR_RESET_VALUE ((u8)0x00)
#define AWU_APR_RESET_VALUE ((u8)0x3F)
#define AWU_TBR_RESET_VALUE ((u8)0x00)

/**
  * @}
  */
/*----------------------------------------------------------------------------*/
/** @addtogroup AWU_Registers_Bits_Definition
  * @{
  */

#define AWU_CSR_AWUF  ((u8)0x20) /*!< Interrupt flag mask */
#define AWU_CSR_AWUEN ((u8)0x10) /*!< Auto Wake-up enable mask */

#define AWU_APR_APR ((u8)0x3F) /*!< Asynchronous Prescaler divider mask */

#define AWU_TBR_AWUTB ((u8)0x0F) /*!< Timebase selection mask */

/**
  * @}
  */ 

/**
  * @brief Clock Controller (CLK)
  */

typedef struct CLK_struct
{
	vu8 SMD0;			/*!< SMED0 clock config. register */
	vu8 SMD1; 		    /*!< SMED1 clock config. register */
	vu8 SMD2;		    /*!< SMED2 clock config. register */
	vu8 SMD3;			/*!< SMED3 clock config. register */	
	vu8 SMD4;			/*!< SMED4 clock config. register */	
	vu8 SMD5; 	 	    /*!< SMED5 clock config. register */	
	u8 RESERVED2[4];    /*!< Reserved byte */
	vu8 PLLDIVR;		/*!< PLL Divider/Prescaler register */
	vu8 AWUDIVR;		/*!< AWU Divider register */
	vu8 ICKR;           /*!< Internal Clocks Control Register */
	vu8 ECKR;           /*!< External Clocks Control Register */
	vu8 PLLR; 		    /*!< PLL status register */
	vu8 CMSR;           /*!< Clock Master Status Register */
	vu8 SWR;            /*!< Clock Master Switch Register */
	vu8 SWCR;           /*!< Switch Control Register */
	vu8 CKDIVR;         /*!< Clock Divider Register */
	vu8 PCKENR1;        /*!< Peripheral Clock Gating Register 1 */
	vu8 CSSR;           /*!< Clock Security Sytem Register */
	vu8 CCOR;           /*!< Configurable Clock Output Register */
	vu8 PCKENR2;        /*!< Peripheral Clock Gating Register 2 */
	u8 RESERVED;        /*!< reserved byte */
	vu8 HSITRIMR;       /*!< HSI Calibration Trimmer Register */
	vu8 SWIMCCR;        /*!< SWIM clock control register */
	vu8 CCODIVR;        /*!< CCO Divider register */
	vu8 ADCR;		    /*!< ADC Status register */
}
CLK_TypeDef;

/** @addtogroup CLK_Registers_Reset_Value
  * @{
  */
#define CLK_SMD0_RESET_VALUE     ((u8)0x00)
#define CLK_SMD1_RESET_VALUE     ((u8)0x00)
#define CLK_SMD2_RESET_VALUE     ((u8)0x00)
#define CLK_SMD3_RESET_VALUE     ((u8)0x00)
#define CLK_SMD4_RESET_VALUE     ((u8)0x00)
#define CLK_SMD5_RESET_VALUE     ((u8)0x00)
#define CLK_PLLDIV_RESET_VALUE   ((u8)0x02)
#define CLK_AWUDIV_RESET_VALUE   ((u8)0x00)
#define CLK_ICKR_RESET_VALUE     ((u8)0x01)
#define CLK_ECKR_RESET_VALUE     ((u8)0x00)
#define CLK_PLLR_RESET_VALUE     ((u8)0x00)
#define CLK_CMSR_RESET_VALUE     ((u8)0xE1)
#define CLK_SWR_RESET_VALUE      ((u8)0xE1)
#define CLK_SWCR_RESET_VALUE     ((u8)0x00)
#define CLK_CKDIVR_RESET_VALUE   ((u8)0x18)
#define CLK_PCKENR1_RESET_VALUE  ((u8)0xFF)
#define CLK_CSSR_RESET_VALUE     ((u8)0x00)
#define CLK_CCOR_RESET_VALUE     ((u8)0x00)
#define CLK_PCKENR2_RESET_VALUE  ((u8)0xFF)
#define CLK_HSITRIMR_RESET_VALUE ((u8)0x00)
#define CLK_SWIMCCR_RESET_VALUE  ((u8)0x00)
#define CLK_CCODIVR_RESET_VALUE  ((u8)0x00)
#define CLK_ADCR_RESET_VALUE  	 ((u8)0x20)

/**
  * @}
  */

/** @addtogroup CLK_Registers_Bits_Definition
  * @{
  */
#define CLK_SMD_CK_SW           ((u8)0x03) /*!< SMED clock switch mask */
#define CLK_SMD_SMED_DIV        ((u8)0x70) /*!< SMED division factor mask */

#define CLK_PLLDIV_PLL_DIV      ((u8)0x03) /*!< PLL clock factor division factor mask */
#define CLK_PLLDIV_PLL_PRES_DIV ((u8)0x18)/*!< PLL clock prescaler factor mask */

#define CLK_AWUDIV_AWUDIV		((u8)0x0F)	/*!< AWU clock post divider mask */

#define CLK_ICKR_REGAH  ((u8)0x20) /*!< Regulator power-off in Active Halt mode */
#define CLK_ICKR_LSIRDY ((u8)0x10) /*!< Low speed internal oscillator ready */
#define CLK_ICKR_LSIEN  ((u8)0x08) /*!< Low speed internal RC oscillator enable */
#define CLK_ICKR_FHWU    ((u8)0x04) /*!< Fast Wake-up from Active Halt/Halt mode */
#define CLK_ICKR_HSIRDY ((u8)0x02) /*!< High speed internal RC oscillator ready */
#define CLK_ICKR_HSIEN  ((u8)0x01) /*!< High speed internal RC oscillator enable */

#define CLK_ECKR_HSERDY ((u8)0x02) /*!< High speed external crystal oscillator ready */
#define CLK_ECKR_HSEEN  ((u8)0x01) /*!< High speed external crystal oscillator enable */


#define CLK_PLLR_PLL_LOCK_INT	((u8)0x40) /*!< PLL Lock Interrupt enable */
#define CLK_PLLR_SPREAD_CTRL	((u8)0x20) /*!< PLL spread input */
#define CLK_PLLR_SSCG_CTRL		((u8)0x10) /*!< PLL sscg input */
#define CLK_PLLR_BYPASS				((u8)0x08) /*!< PLL bypass enable */
#define CLK_PLLR_REF_SEL			((u8)0x04) /*!< PLL Clock Input reference clock Selection */
#define CLK_PLLR_LOCKP				((u8)0x02) /*!< PLL Lock Signal */
#define CLK_PLLR_PLLON				((u8)0x01) /*!< PLL Power-Down */		

#define CLK_CMSR_CKM    ((u8)0xFF) /*!< Clock master status bits */


#define CLK_SWR_SWI     ((u8)0xFF) /*!< Clock master selection bits */

#define CLK_SWCR_SWIF   ((u8)0x08) /*!< Clock switch interrupt flag */
#define CLK_SWCR_SWIEN  ((u8)0x04) /*!< Clock switch interrupt enable */
#define CLK_SWCR_SWEN   ((u8)0x02) /*!< Switch start/stop */
#define CLK_SWCR_SWBSY  ((u8)0x01) /*!< Switch busy */

#define CLK_CKDIVR_HSIDIV ((u8)0x18) /*!< High speed internal clock prescaler */
#define CLK_CKDIVR_CPUDIV ((u8)0x07) /*!< CPU clock prescaler */

#define CLK_PCKENR1_PCKEN17   ((u8)0x80) /*!< ADC Peripheral clocks enable */ 
#define CLK_PCKENR1_PCKEN16   ((u8)0x40) /*!< AWU Peripheral clocks enable */
#define CLK_PCKENR1_PCKEN15   ((u8)0x20) /*!< GPIO1 Peripheral clocks enable */
#define CLK_PCKENR1_PCKEN14   ((u8)0x10) /*!< STMR Peripheral clocks enable */
#define CLK_PCKENR1_PCKEN13   ((u8)0x08) /*!< DALI Peripheral clocks enable */
#define CLK_PCKENR1_PCKEN12   ((u8)0x04) /*!< UART Peripheral clocks enable */
#define CLK_PCKENR1_PCKEN11   ((u8)0x02) /*!< GPIO0 Peripheral clocks enable */
#define CLK_PCKENR1_PCKEN10   ((u8)0x01) /*!< I2C Peripheral clocks enable */

#define CLK_CSSR_CSSD   ((u8)0x08) /*!< Clock security sytem detection */
#define CLK_CSSR_CSSDIE ((u8)0x04) /*!< Clock security system detection interrupt enable */
#define CLK_CSSR_AUX    ((u8)0x02) /*!< Auxiliary oscillator connected to master clock */
#define CLK_CSSR_CSSEN  ((u8)0x01) /*!< Clock security system enable */

#define CLK_CCOR_CCOBSY ((u8)0x40) /*!< Configurable clock output busy */
#define CLK_CCOR_CCORDY ((u8)0x20) /*!< Configurable clock output ready */
#define CLK_CCOR_CCOSEL ((u8)0x1E) /*!< Configurable clock output selection */
#define CLK_CCOR_CCOEN  ((u8)0x01) /*!< Configurable clock output enable */

#define CLK_PCKENR2_PCKEN27   ((u8)0x80) /*!< Clock Enable of MISC�s uP interface */
#define CLK_PCKENR2_PCKEN25   ((u8)0x20) /*!< Clock Enable for SMED5�s uP interface */
#define CLK_PCKENR2_PCKEN24   ((u8)0x10) /*!< Clock Enable for SMED4�s uP interface */
#define CLK_PCKENR2_PCKEN23   ((u8)0x08) /*!< Clock Enable for SMED3�s uP interface */
#define CLK_PCKENR2_PCKEN22   ((u8)0x04) /*!< Clock Enable for SMED2�s uP interface */
#define CLK_PCKENR2_PCKEN21   ((u8)0x02) /*!< Clock Enable for SMED1�s uP interface */
#define CLK_PCKENR2_PCKEN20   ((u8)0x01) /*!< Clock Enable for SMED0�s uP interface */

#define CLK_HSITRIMR_HSITRIM ((u8)0x07) /*!< High speed internal oscillator trimmer */

#define CLK_SWIMCCR_SWIMDIV ((u8)0x01) /*!< SWIM Clock Dividing Factor */

#define CLK_ADCR_ADC_DIV		((u8)0xF0) /*!< Divider Factor for ADC clock */
#define CLK_ADCR_SEL				((u8)0x03) /*!< ADC Clock selection */

/**
  * @}
  */
/*----------------------------------------------------------------------------*/
/**
  * @brief SMED timer-counter
  */

typedef struct SMED_struct
{
	vu8 CTR; 					/*!<  Control register */
	vu8 CTR_TMR; 				/*!<  Control Time */
	vu8 CTR_INP; 				/*!<  Control Inputs */
	vu8 CTR_DTHR; 				/*!<  Dithering */
	vu8 TMR_T0L; 				/*!<  Time T0 */
	vu8 TMR_T0H; 				/*!<  Time T0 */
	vu8 TMR_T1L; 				/*!<  Time T1 */
	vu8 TMR_T1H; 				/*!< Time T1 */
	vu8 TMR_T2L; 				/*!<  Time T2 */
	vu8 TMR_T2H; 				/*!<  Time T2 */
	vu8 TMR_T3L; 				/*!<  Time T3 */
	vu8 TMR_T3H; 				/*!<  Time T3 */
	vu8 PRM_ID0; 				/*!< IDLE state parameter0 */
	vu8 PRM_ID1; 				/*!<  IDLE state parameter1 */
	vu8 PRM_ID2; 				/*!<  IDLE state parameter2 */
	vu8 PRM_S00; 				/*!<  S0 state parameter0 */
	vu8 PRM_S01; 				/*!<  S0 state parameter1 */
	vu8 PRM_S02; 				/*!<  S0 state parameter2 */
	vu8 PRM_S10; 				/*!<  S1 state parameter0 */
	vu8 PRM_S11; 				/*!<  S1 state parameter1 */
	vu8 PRM_S12; 				/*!<  S1 state parameter2 */
	vu8 PRM_S20; 				/*!<  S2 state parameter0 */
	vu8 PRM_S21; 				/*!<  S2 state parameter1 */
	vu8 PRM_S22; 				/*!<  S2 state parameter2 */
	vu8 PRM_S30;  				/*!<  S3 state parameter0 */
	vu8 PRM_S31; 				/*!<  S3 state parameter1 */
	vu8 PRM_S32; 				/*!<  S3 state parameter2 */
	vu8 CFG; 						/*!<  Time registers configuration */
	vu8 DMP_L; 					/*!<  Counter LSB Dump */
	vu8 DMP_H; 					/*!<  Counter MSB Dump */
	vu8 GSTS; 						/*!<  General Status */
	vu8 IRQ; //ISR; 						/*!<  Interrupt Request Register */
	vu8 IER; //IMR; 						/*!<  Interrupt Enable Register */
	vu8 ISEL; 						/*!<  External events Control */
	vu8 DMP; 						/*!<  Dump enable */
	vu8 FSM_STS; 				/*!<  FSM core status */
}SMED_TypeDef;

/** @addtogroup SMED_Registers_Reset_Value
  * @{
  */
#define SMED_CTR_RESET_VALUE			((u8)0x00)
#define SMED_CTR_TMR_RESET_VALUE		((u8)0x00)
#define SMED_CTR_INP_RESET_VALUE		((u8)0x00)
#define SMED_CTR_DTHR_RESET_VALUE		((u8)0x00)
#define SMED_TMR_T0L_RESET_VALUE		((u8)0x00)
#define SMED_TMR_T0H_RESET_VALUE		((u8)0x00)
#define SMED_TMR_T1L_RESET_VALUE		((u8)0x00)
#define SMED_TMR_T1H_RESET_VALUE		((u8)0x00)
#define SMED_TMR_T2L_RESET_VALUE		((u8)0x00)
#define SMED_TMR_T2H_RESET_VALUE		((u8)0x00)
#define SMED_TMR_T3L_RESET_VALUE		((u8)0x00)
#define SMED_TMR_T3H_RESET_VALUE		((u8)0x00)
#define SMED_PRM_ID0_RESET_VALUE		((u8)0x00)
#define SMED_PRM_ID1_RESET_VALUE		((u8)0x00)
#define SMED_PRM_ID2_RESET_VALUE		((u8)0x00)
#define SMED_PRM_S00_RESET_VALUE		((u8)0x00)
#define SMED_PRM_S01_RESET_VALUE		((u8)0x00)
#define SMED_PRM_S02_RESET_VALUE		((u8)0x00)
#define SMED_PRM_S10_RESET_VALUE		((u8)0x00)
#define SMED_PRM_S11_RESET_VALUE		((u8)0x00)
#define SMED_PRM_S12_RESET_VALUE		((u8)0x00)
#define SMED_PRM_S20_RESET_VALUE		((u8)0x00)
#define SMED_PRM_S21_RESET_VALUE		((u8)0x00)
#define SMED_PRM_S22_RESET_VALUE		((u8)0x00)
#define SMED_PRM_S30_RESET_VALUE		((u8)0x00)
#define SMED_PRM_S31_RESET_VALUE		((u8)0x00)
#define SMED_PRM_S32_RESET_VALUE		((u8)0x00)
#define SMED_CFG_RESET_VALUE			((u8)0x00)
#define SMED_DMP_L_RESET_VALUE			((u8)0x00)
#define SMED_DMP_H_RESET_VALUE			((u8)0x00)
#define SMED_GSTS_RESET_VALUE			((u8)0x00)
#define SMED_IRQ_RESET_VALUE			((u8)0x00)
#define SMED_IER_RESET_VALUE			((u8)0x00)
#define SMED_ISEL_RESET_VALUE			((u8)0x00)
#define SMED_DMP_RESET_VALUE			((u8)0x00)
#define SMED_FSM_STS_RESET_VALUE		((u8)0x00)
/**
  * @}
  */
/** @addtogroup SMED_Registers_Bits_Definition
  * @{
  */
#define SMED_CTR_FSM_ENA		    ((u8)0x02)	/*!< Synchronous FSM Enable */
#define SMED_CTR_START_CNT		    ((u8)0x01)	/*!< Start counter */

#define SMED_CTR_TMR_DITHER_VAL		((u8)0x10)	/*!< Validation of SMED_CTR_DTHR register */
#define SMED_CTR_TMR_TIME_T3_VAL	((u8)0x08)	/*!< Validation of SMED_TMR_T3 register */
#define SMED_CTR_TMR_TIME_T2_VAL	((u8)0x04)	/*!< Validation of SMED_TMR_T2 register */
#define SMED_CTR_TMR_TIME_T1_VAL	((u8)0x02)	/*!< Validation of SMED_TMR_T1 register */
#define SMED_CTR_TMR_TIME_T0_VAL	((u8)0x01)	/*!< Validation of SMED_TMR_T0 register */

#define SMED_CTR_INP_EL_EN						((u8)0x80)	/*!< ASY_ENABLE Input characteristic */
#define SMED_CTR_INP_EL_INSIG2				((u8)0x40)	/*!< External IN_SIG(2) Input characteristic */
#define SMED_CTR_INP_EL_INSIG1				((u8)0x20)	/*!< External IN_SIG(1) Input characteristic */
#define SMED_CTR_INP_EL_INSIG0				((u8)0x10)	/*!< External IN_SIG(0) Input characteristic */
#define SMED_CTR_INP_RAIS_EN					((u8)0x08)	/*!< Asynchronous Enable Input polarity level */
#define SMED_CTR_INP_RS_INSIG2				((u8)0x04)	/*!< External event (2) Input polarity level */
#define SMED_CTR_INP_RS_INSIG1				((u8)0x02)	/*!< External event (1) Input polarity level */
#define SMED_CTR_INP_RS_INSIG0				((u8)0x01)	/*!< External event (0) Input polarity level */

/* note: SMED_PRM_x is same for all the states (ID, S0,S1,S2,S3) */
#define SMED_PRM_0_AND_OR          ((u8)0x80)	/*!< Jumping Boolean function definition */
#define SMED_PRM_0_HOLD_JMP        ((u8)0x40)	/*!< Hold state definition */
#define SMED_PRM_0_PULS_EDG        ((u8)0x20)	/*!< PWM pulse out level */
#define SMED_PRM_0_CNT_RSTE        ((u8)0x10)	/*!< Counter reset */
#define SMED_PRM_0_NX_STATE_S0     ((u8)0x03)   /*!< next state is S0 */
#define SMED_PRM_0_NX_STATE_S1     ((u8)0x00)   /*!< next state is S1 */
#define SMED_PRM_0_NX_STATE_S2     ((u8)0x01)   /*!< next state is S2 */
#define SMED_PRM_0_NX_STATE_S3     ((u8)0x02)   /*!< next state is S3 */
#define SMED_PRM_0_EDGEY_NOEDGE    ((u8)0x00)  /*!< no edge used as edgeY*/
#define SMED_PRM_0_EDGEY_EDGE0     ((u8)0x04)   /*!< edge0 used as edgeY*/
#define SMED_PRM_0_EDGEY_EDGE1     ((u8)0x08)   /*!< edge1 used as edgeY*/
#define SMED_PRM_0_EDGEY_EDGE2     ((u8)0x0C)   /*!< edge2 used as edgeY*/



#define SMED_PRM_1_HOLD_EXIT       ((u8)0x40)	/*!< Hold state exit cause definition */
#define SMED_PRM_1_PULS_CMP        ((u8)0x20)	/*!< PWM pulse out level definition */
#define SMED_PRM_1_CNT_RSTC        ((u8)0x10)	/*!< Counter reset definition */
#define SMED_PRM_1_CEDGE_NOEDGE    ((u8)0x0)  /*!< no edge used as edge(x)*/
#define SMED_PRM_1_CEDGE_EDGE0     ((u8)0x4)   /*!< edge0 used as edge(x)*/
#define SMED_PRM_1_CEDGE_EDGE1     ((u8)0x8)   /*!< edge1 used as edge(x)*/
#define SMED_PRM_1_CEDGE_EDGE2     ((u8)0xC)   /*!< edge2 used as edge(x)*/


#define SMED_PRM_2_LATCH_RS				((u8)0x01)	/*!< Latch reset definition */
#define SMED_PRM_2_QCOUP_ST				((u8)0x80)	/*!< Fast start in 2 coupled mode */

#define SMED_CFG_TIM_UPD					((u8)0x0C)  /*!< Time registers update mode	*/
#define SMED_CFG_TIM_NUM					((u8)0x03)  /*!< Time registers to be incremented selection	*/

#define SMED_GSTS_EVENT_OV				((u8)0x40)	/*!< Event overflow flag */
#define SMED_GSTS_DMP_LK	 				((u8)0x30)	/*!< Counter dump status */
#define SMED_GSTS_CNT_FLAG				((u8)0x08)	/*!< Counter reset flag when dump is enabled*/
#define SMED_GSTS_EX2_DUMP				((u8)0x04)	/*!< Dumping cause flag */
#define SMED_GSTS_EX1_DUMP				((u8)0x02)	/*!< Dumping cause flag */
#define SMED_GSTS_EX0_DUMP				((u8)0x01)	/*!< Dumping cause flag */

#define SMED_IRQ_STA_S3_IT				((u8)0x80)	/*!< Interrupt jumping out S3 state for cmp(3) flag */
#define SMED_IRQ_STA_S2_IT				((u8)0x40)	/*!< Interrupt jumping out S2 state for cmp(2) flag */
#define SMED_IRQ_STA_S1_IT				((u8)0x20)	/*!< Interrupt jumping out S1 state for cmp(1) flag */
#define SMED_IRQ_STA_S0_IT				((u8)0x10)	/*!< Interrupt jumping out S0 state for cmp(0) flag */
#define SMED_IRQ_EXT2_INT					((u8)0x08)	/*!< Interrupt IN_SIG(2) flag */
#define SMED_IRQ_EXT1_INT					((u8)0x04)	/*!< Interrupt IN_SIG(1) flag */
#define SMED_IRQ_EXT0_INT					((u8)0x02)	/*!< Interrupt IN_SIG(0) flag */
#define SMED_IRQ_CNT_OVER					((u8)0x01)	/*!< Interrupt internal counter overflow flag */

#define SMED_IER_IT_STA_S3					((u8)0x80)		/*!< Interrupt enable jumping out S3 for cmp(3) */
#define SMED_IER_IT_STA_S2					((u8)0x40)		/*!< Interrupt enable jumping out S2 for cmp(2) */
#define SMED_IER_IT_STA_S1					((u8)0x20)		/*!< Interrupt enable jumping out S1 for cmp(1)*/
#define SMED_IER_IT_STA_S0					((u8)0x10)		/*!< Interrupt enable jumping out S0 for cmp(0) */
#define SMED_IER_IT_EN_EX2					((u8)0x08)		/*!< Interrupt enable IN_SIG(2) */
#define SMED_IER_IT_EN_EX1					((u8)0x04)		/*!< Interrupt enable IN_SIG(1) */
#define SMED_IER_IT_EN_EX0					((u8)0x02)		/*!< Interrupt enable IN_SIG(0) */
#define SMED_IER_CNT_OV_E						((u8)0x01)		/*!< Interrupt enable internal counter overflow */

#define SMED_ISEL_INPUT_LAT				((u8)0x08)		/*!< Enable latch function on IN_SIG(0) input */
#define SMED_ISEL_INPUT2_EN				((u8)0x04)		/*!< IN_SIG(2) input enable */
#define SMED_ISEL_INPUT1_EN				((u8)0x02)		/*!< IN_SIG(1) input enable */
#define SMED_ISEL_INPUT0_EN				((u8)0x01)		/*!< IN_SIG(0) input enable */

#define SMED_DMP_CPL_IT_GE				((u8)0x10)	/*!< Lock together GEN_STAT & INT_STAT res. signals */
#define SMED_DMP_DMP_EVER				   ((u8)0x08)		/*!< Dump update mode */
#define SMED_DMP_DMPE_EX2					((u8)0x04)		/*!< Dump update mode */
#define SMED_DMP_DMPE_EX1					((u8)0x02)		/*!< Dump update mode */
#define SMED_DMP_DMPE_EX0					((u8)0x01)		/*!< Dump update mode */

#define SMED_FSM_STS_EVINP				    ((u8)0x70)		/*!< Event input signals state mask */
#define SMED_FSM_STS_PWM					((u8)0x08)		/*!< PWM output signal state */
#define SMED_FSM_STS_FSM					((u8)0x07)		/*!< SMED Finite State Machine state mask*/

/**
  * @}
  */

/*----------------------------------------------------------------------------*/
/**
  * @brief 16-bit system timer (STMR)
  */

typedef struct STMR_struct
{
	vu8 CR1;		/*!< Control register 1 */
	vu8 IER;		/*!< Interrupt enable register*/
	vu8 SR1;		/*!< Status register 1*/
	vu8 EGR; 		/*!< Event Generation register */
	vu8 CNTH; 	/*!< Counter High register */
	vu8 CNTL; 	/*!< Counter Low register */
	vu8 PSCL; 	/*!< Prescaler Low register */
	vu8 ARRH; 	/*!< Auto-Reload High register */
	vu8 ARRL;		/*!< Auto-Reload Low register*/
}
STMR_TypeDef;

/** @addtogroup STMR_Registers_Reset_Value
  * @{
  */
#define  STMR_CR1_RESET_VALUE  		((u8)0x00)
#define  STMR_IER_RESET_VALUE  		((u8)0x00)
#define  STMR_SR1_RESET_VALUE  		((u8)0x00)
#define  STMR_EGR_RESET_VALUE  		((u8)0x00)
#define  STMR_CNTH_RESET_VALUE  	((u8)0x00)
#define  STMR_CNTL_RESET_VALUE  	((u8)0x00)
#define  STMR_PSCL_RESET_VALUE  	((u8)0x00)
#define  STMR_ARRH_RESET_VALUE  	((u8)0xFF)
#define  STMR_ARRL_RESET_VALUE  	((u8)0xFF)
/**
  * @}
  */
/** @addtogroup STMR_Registers_Bits_Definition
  * @{
  */
#define STMR_CR1_ARPE  		((u8)0x80) /*!< Auto-Reload Preload Enable */
#define STMR_CR1_OPM  		((u8)0x08) /*!< One Pulse Mode */
#define STMR_CR1_URS  		((u8)0x04) /*!< Update Request Source */
#define STMR_CR1_UDIS  		((u8)0x02) /*!< Update Disable */
#define STMR_CR1_CEN  		((u8)0x01) /*!< Counter Enable */

#define STMR_IER_UIE  		((u8)0x01) /*!< Update Interrupt Enable */

#define STMR_SR1_UIF  		((u8)0x01) /*!< Update Interrupt Flag */

#define STMR_EGR_UG  		((u8)0x01) /*!< Update generation */

#define STMR_PSCR_PSC       ((u8)0x07) /*!< mask for prescaler bits */
/**
  * @}
  */
  
 /*----------------------------------------------------------------------------*/
/**
  * @brief Inter-Integrated Circuit (I2C)
  */

typedef struct I2C_struct
{
  vu8 CR1;       /*!< I2C control register 1 */
  vu8 CR2;       /*!< I2C control register 2 */
  vu8 FREQR;     /*!< I2C frequency register */
  vu8 OARL;      /*!< I2C own address register LSB */
  vu8 OARH;      /*!< I2C own address register MSB */
  vu8 RESERVED1; /*!< Reserved byte */
  vu8 DR;        /*!< I2C data register */
  vu8 SR1;       /*!< I2C status register 1 */
  vu8 SR2;       /*!< I2C status register 2 */
  vu8 SR3;       /*!< I2C status register 3 */
  vu8 ITR;       /*!< I2C interrupt register */
  vu8 CCRL;      /*!< I2C clock control register low */
  vu8 CCRH;      /*!< I2C clock control register high */
  vu8 TRISER;    /*!< I2C maximum rise time register */
}
I2C_TypeDef;

/** @addtogroup I2C_Registers_Reset_Value
  * @{
  */

#define I2C_CR1_RESET_VALUE    ((u8)0x00)
#define I2C_CR2_RESET_VALUE    ((u8)0x00)
#define I2C_FREQR_RESET_VALUE  ((u8)0x00)
#define I2C_OARL_RESET_VALUE   ((u8)0x00)
#define I2C_OARH_RESET_VALUE   ((u8)0x00)
#define I2C_DR_RESET_VALUE     ((u8)0x00)
#define I2C_SR1_RESET_VALUE    ((u8)0x00)
#define I2C_SR2_RESET_VALUE    ((u8)0x00)
#define I2C_SR3_RESET_VALUE    ((u8)0x00)
#define I2C_ITR_RESET_VALUE    ((u8)0x00)
#define I2C_CCRL_RESET_VALUE   ((u8)0x00)
#define I2C_CCRH_RESET_VALUE   ((u8)0x00)
#define I2C_TRISER_RESET_VALUE ((u8)0x02)

/**
  * @}
  */

/** @addtogroup I2C_Registers_Bits_Definition
  * @{
  */

#define I2C_CR1_NOSTRETCH ((u8)0x80) /*!< Clock Stretching Disable (Slave mode) */
#define I2C_CR1_ENGC      ((u8)0x40) /*!< General Call Enable */
#define I2C_CR1_PE        ((u8)0x01) /*!< Peripheral Enable */

#define I2C_CR2_SWRST ((u8)0x80) /*!< Software Reset */
#define I2C_CR2_POS   ((u8)0x08) /*!< Acknowledge */
#define I2C_CR2_ACK   ((u8)0x04) /*!< Acknowledge Enable */
#define I2C_CR2_STOP  ((u8)0x02) /*!< Stop Generation */
#define I2C_CR2_START ((u8)0x01) /*!< Start Generation */

#define I2C_FREQR_FREQ ((u8)0x3F) /*!< Peripheral Clock Frequency */

#define I2C_OARL_ADD  ((u8)0xFE) /*!< Interface Address bits [7..1] */
#define I2C_OARL_ADD0 ((u8)0x01) /*!< Interface Address bit0 */

#define I2C_OARH_ADDMODE ((u8)0x80) /*!< Addressing Mode (Slave mode) */
#define I2C_OARH_ADDCONF ((u8)0x40) /*!< Address Mode Configuration */
#define I2C_OARH_ADD     ((u8)0x06) /*!< Interface Address bits [9..8] */

#define I2C_DR_DR ((u8)0xFF) /*!< Data Register */

#define I2C_SR1_TXE   ((u8)0x80) /*!< Data Register Empty (transmitters) */
#define I2C_SR1_RXNE  ((u8)0x40) /*!< Data Register not Empty (receivers) */
#define I2C_SR1_STOPF ((u8)0x10) /*!< Stop detection (Slave mode) */
#define I2C_SR1_ADD10 ((u8)0x08) /*!< 10-bit header sent (Master mode) */
#define I2C_SR1_BTF   ((u8)0x04) /*!< Byte Transfer Finished */
#define I2C_SR1_ADDR  ((u8)0x02) /*!< Address sent (master mode)/matched (slave mode) */
#define I2C_SR1_SB    ((u8)0x01) /*!< Start Bit (Master mode) */

#define I2C_SR2_WUFH    ((u8)0x20) /*!< Wake-up from Halt */
#define I2C_SR2_OVR     ((u8)0x08) /*!< Overrun/Underrun */
#define I2C_SR2_AF      ((u8)0x04) /*!< Acknowledge Failure */
#define I2C_SR2_ARLO    ((u8)0x02) /*!< Arbitration Lost (master mode) */
#define I2C_SR2_BERR    ((u8)0x01) /*!< Bus Error */

#define I2C_SR3_GENCALL ((u8)0x10) /*!< General Call Header (Slave mode) */
#define I2C_SR3_TRA     ((u8)0x04) /*!< Transmitter/Receiver */
#define I2C_SR3_BUSY    ((u8)0x02) /*!< Bus Busy */
#define I2C_SR3_MSL     ((u8)0x01) /*!< Master/Slave */

#define I2C_ITR_ITBUFEN ((u8)0x04) /*!< Buffer Interrupt Enable */
#define I2C_ITR_ITEVTEN ((u8)0x02) /*!< Event Interrupt Enable */
#define I2C_ITR_ITERREN ((u8)0x01) /*!< Error Interrupt Enable */

#define I2C_CCRL_CCR ((u8)0xFF) /*!< Clock Control Register (Master mode) */

#define I2C_CCRH_FS   ((u8)0x80) /*!< Master Mode Selection */
#define I2C_CCRH_DUTY ((u8)0x40) /*!< Fast Mode Duty Cycle */
#define I2C_CCRH_CCR  ((u8)0x0F) /*!< Clock Control Register in Fast/Standard mode (Master mode) bits [11..8] */

#define I2C_TRISER_TRISE ((u8)0x3F) /*!< Maximum Rise Time in Fast/Standard mode (Master mode) */

/**
  * @}
  */

/*----------------------------------------------------------------------------*/
/**
  * @brief Interrupt Controller (ITC)
  */
 typedef struct ITC_struct
{
  vu8 SPR0; /*!< Interrupt Software Priority register 0 */
  vu8 SPR1; /*!< Interrupt Software Priority register 1 */
  vu8 SPR2; /*!< Interrupt Software Priority register 2 */
  vu8 SPR3; /*!< Interrupt Software Priority register 3 */
  vu8 SPR4; /*!< Interrupt Software Priority register 4 */
  vu8 SPR5; /*!< Interrupt Software Priority register 5 */
  vu8 SPR6; /*!< Interrupt Software Priority register 6 */
  vu8 SPR7; /*!< Interrupt Software Priority register 7 */
}
ITC_TypeDef;

/** @addtogroup ITC_Registers_Reset_Value
  * @{
  */
#define ITC_SPRX_RESET_VALUE ((u8)0xFF) /*!< Reset value of Software Priority registers */
/**
  * @}
  */

/** @addtogroup CPU_Registers_Bits_Definition
  * @{
  */

#define CPU_CC_I1I0 ((u8)0x28) /*!< Condition Code register, I1 and I0 bits mask */

/**
  * @}
  */

/*----------------------------------------------------------------------------*/
/**
  * @brief FLASH program and Data memory (FLASH)
  */

typedef struct FLASH_struct
{
	vu8 CR1;		/*!< Flash control register 1 */
	vu8 CR2;		/*!< Flash control register 2 */
	vu8 NCR2;		/*!< Flash complementary control register 2 */
	vu8 FPR;		/*!< Flash protection register */
	vu8 NFPR;		/*!< Flash complementary protection register */
	vu8 IAPSR;		/*!< Flash in-application programming status register */
	vu8 RES1[2];            /*!< Reserved byte */
	vu8 PUKR;		/*!< Flash program memory unprotection register */
	vu8 RES3;		/*!< Reserved byte */
	vu8 DUKR;		/*!< Data EEPROM unprotection register */
	vu8 RES4[11];           /*!< Reserved bytes */
	vu8 WAIT;		/*!< Flash wait state register */
}
FLASH_TypeDef;

/** @addtogroup FLASH_Registers_Reset_Value
  * @{
  */

#define FLASH_CR1_RESET_VALUE   ((u8)0x00)
#define FLASH_CR2_RESET_VALUE   ((u8)0x00)
#define FLASH_NCR2_RESET_VALUE  ((u8)0xFF)
#define FLASH_IAPSR_RESET_VALUE ((u8)0x40)
#define FLASH_PUKR_RESET_VALUE  ((u8)0x00)
#define FLASH_DUKR_RESET_VALUE  ((u8)0x00)

/**
  * @}
  */

/** @addtogroup FLASH_Registers_Bits_Definition
  * @{
  */

#define FLASH_CR1_HALT			((u8)0x08) /*!< Standby in Halt mode mask */
#define FLASH_CR1_AHALT			((u8)0x04) /*!< Standby in Active Halt mode mask */
#define FLASH_CR1_IE			((u8)0x02) /*!< Flash Interrupt enable mask */
#define FLASH_CR1_FIX			((u8)0x01) /*!< Fix programming time mask */

#define FLASH_CR2_OPT			((u8)0x80) /*!< Select option byte mask */
#define FLASH_CR2_WWO			((u8)0x40) /*!< Word Write Once */
#define FLASH_CR2_ERASE			((u8)0x20) /*!< Erase block mask */
#define FLASH_CR2_FPRG			((u8)0x10) /*!< Fast programming mode mask */
#define FLASH_CR2_PRG			((u8)0x01) /*!< Program block mask */

#define FLASH_NCR2_NOPT			((u8)0x80) /*!< Select option byte mask */
#define FLASH_NCR2_NWWO			((u8)0x40) /*!< Word Write Once */
#define FLASH_NCR2_NERASE		((u8)0x20) /*!< Erase block mask */
#define FLASH_NCR2_NFPRG		((u8)0x10) /*!< Fast programming mode mask */
#define FLASH_NCR2_NPRG			((u8)0x01) /*!< Program block mask */

#define FLASH_IAPSR_HVOFF		((u8)0x40) /*!< End of high voltage flag mask */
#define FLASH_IAPSR_DUL			((u8)0x08) /*!< Data EEPROM unlocked flag mask */
#define FLASH_IAPSR_EOP			((u8)0x04) /*!< End of operation flag mask */
#define FLASH_IAPSR_PUL			((u8)0x02) /*!< Flash Program memory unlocked flag mask */
#define FLASH_IAPSR_WR_PG_DIS	((u8)0x01) /*!< Write attempted to protected page mask */

#define FLASH_PUKR_PUK			((u8)0xFF) /*!< Flash Program memory unprotection mask */

#define FLASH_DUKR_DUK			((u8)0xFF) /*!< Data EEPROM unprotection mask */

#define FLASH_WAIT_WAIT			((u8)0x03) /*!< Flash wait cycles mask */

/**
  * @}
  */

 /*----------------------------------------------------------------------------*/
/**
  * @brief Option Bytes (OPT)
  */
typedef struct OPT_struct
{
    vu8 ROP;  			/*!< OPT0 Read-out protection (not accessible in IAP mode) */
    vu8 UBC;  			/*!< OPT1 User boot code */
    vu8 NUBC; 			
    vu8 GENCFG;  		/*!< OPT2 General configuration register  */
    vu8 NGENCFG; 		
    vu8 MISCUOPT;  	    /*!< OPT3 Misc. config. register */
    vu8 NMISCUOPT; 	
    vu8 CLKCTL;  		/*!< OPT4 CKC config. register */
    vu8 NCLKCTL; 		
    vu8 HSESTAB;  	    /*!< OPT5 HSE clock stabiliz. reg. */
    vu8 NHSESTAB; 	
    vu8 RESERVED1;      /*!< Reserved Option byte*/
    vu8 RESERVED2; 	    /*!< Reserved Option byte*/
    vu8 WAITSTATE;      /*!< OPT7 E2PROM wait state */
    vu8 NWAITSTATE;
	vu8 AFR_IOMXP0;     /*!< Alternate config. Port0 */
	vu8 nAFR_IOMXP0;
	vu8 AFR_IOMXP1;     /*!< Alternate config. Port1 */
	vu8 nAFR_IOMXP1;
	vu8 AFR_IOMXP2;     /*!< Alternate config. Port1 */
	vu8 nAFR_IOMXP2;
	vu8 MSC_OPT0; 	    /*!< Miscellaneous opt. reg0 */
	vu8 nMSC_OPT0;
    vu8 RESERVED3[103]; 	    /*!< Reserved Option byte*/    
	vu8 OPTBL;			/*!< boot loader */
	vu8 nOPTBL;
}
OPT_TypeDef;

/*----------------------------------------------------------------------------*/
/**
  * @brief Independent Watchdog (IWDG)
  */

typedef struct IWDG_struct
{
  vu8 KR;  /*!< Key Register */
  vu8 PR;  /*!< Prescaler Register */
  vu8 RLR; /*!< Reload Register */
}
IWDG_TypeDef;

/** @addtogroup IWDG_Registers_Reset_Value
  * @{
  */

#define IWDG_PR_RESET_VALUE  ((u8)0x00)
#define IWDG_RLR_RESET_VALUE ((u8)0xFF)

/**
  * @}
  */
/*----------------------------------------------------------------------------*/
/**
  * @brief Window Watchdog (WWDG)
  */

typedef struct WWDG_struct
{
  vu8 CR; /*!< Control Register */
  vu8 WR; /*!< Window Register */
}
WWDG_TypeDef;

/** @addtogroup WWDG_Registers_Reset_Value
  * @{
  */

#define WWDG_CR_RESET_VALUE ((u8)0x7F)
#define WWDG_WR_RESET_VALUE ((u8)0x7F)

/**
  * @}
  */

/** @addtogroup WWDG_Registers_Bits_Definition
  * @{
  */

#define WWDG_CR_WDGA ((u8)0x80) /*!< WDGA bit mask */
#define WWDG_CR_T6   ((u8)0x40) /*!< T6 bit mask */
#define WWDG_CR_T    ((u8)0x7F) /*!< T bits mask */

#define WWDG_WR_MSB  ((u8)0x80) /*!< MSB bit mask */
#define WWDG_WR_W    ((u8)0x7F) /*!< W bits mask */

/**
  * @}
  */
/*----------------------------------------------------------------------------*/
/**
  * @brief Reset Controller (RST)
  */

typedef struct RST_struct
{
  vu8 SR; /*!< Reset status register */
}
RST_TypeDef;

/** @addtogroup RST_Registers_Bits_Definition
  * @{
  */

#define RST_SR_EMCF   ((u8)0x10) /*!< EMC reset flag bit mask */
#define RST_SR_SWIMF  ((u8)0x08) /*!< SWIM reset flag bit mask */
#define RST_SR_ILLOPF ((u8)0x04) /*!< Illegal opcode reset flag bit mask */
#define RST_SR_IWDGF  ((u8)0x02) /*!< IWDG reset flag bit mask */
#define RST_SR_WWDGF  ((u8)0x01) /*!< WWDG reset flag bit mask */

/**
  * @}
  */
/*----------------------------------------------------------------------------*/
/**
  * @brief Single Wire Interface Module (SWIM)
  */
typedef struct SWIM_struct
{
  vu8 CSR; /*!< Control/Status register */
  vu8 DR;  /*!< Data register */
}
SWIM_TypeDef;

#define SWIM_CSR_SAFE_MASK ((u8)0x80) /*!< SAFE_MASK SWIM internal reset sources flag bit mask */
#define SWIM_CSR_DM        ((u8)0x20) /*!< DM SWIM debug mode flag bit mask */
#define SWIM_CSR_HS        ((u8)0x10) /*!< HS SWIM high speed flag bit mask */
#define SWIM_CSR_OSCOFF    ((u8)0x08) /*!< OSCOFF SWIM Oscillator Control Bit mask  */
#define SWIM_CSR_RST       ((u8)0x04) /*!< RST SWIM Reset Control Bit mask */
#define SWIM_CSR_OBL       ((u8)0x02) /*!< OBL SWIM Option Byte Loading done flag bit mask */
#define SWIM_CSR_PRI       ((u8)0x01) /*!< PRI SWIM direct memory access priority flag bit mask */

/*----------------------------------------------------------------------------*/
/**
  * @brief Universal Asynchronous Receiver Transmitter (UART)
  */

typedef struct UART_struct
{
  vu8 SR;   /*!< UART status register */
  vu8 DR;   /*!< UART data register */
  vu8 BRR1; /*!< UART baud rate register */
  vu8 BRR2; /*!< UART DIV mantissa[11:8] SCIDIV fraction */
  vu8 CR1;  /*!< UART control register 1 */
  vu8 CR2;  /*!< UART control register 2 */
  vu8 CR3;  /*!< UART control register 3 */
  vu8 CR4;  /*!< UART control register 4 */
}
UART_TypeDef;

/** @addtogroup UART_Registers_Reset_Value
  * @{
  */

#define UART_SR_RESET_VALUE   ((u8)0xC0)
#define UART_BRR1_RESET_VALUE ((u8)0x00)
#define UART_BRR2_RESET_VALUE ((u8)0x00)
#define UART_CR1_RESET_VALUE  ((u8)0x00)
#define UART_CR2_RESET_VALUE  ((u8)0x00)
#define UART_CR3_RESET_VALUE  ((u8)0x00)
#define UART_CR4_RESET_VALUE  ((u8)0x00)

/**
  * @}
  */

/** @addtogroup UART_Registers_Bits_Definition
  * @{
  */

#define UART_SR_TXE   ((u8)0x80) /*!< Transmit Data Register Empty mask */
#define UART_SR_TC    ((u8)0x40) /*!< Transmission Complete mask */
#define UART_SR_RXNE  ((u8)0x20) /*!< Read Data Register Not Empty mask */
#define UART_SR_IDLE  ((u8)0x10) /*!< IDLE line detected mask */
#define UART_SR_OR   ((u8)0x08) /*!< OverRun error mask */
#define UART_SR_NF    ((u8)0x04) /*!< Noise Flag mask */
#define UART_SR_FE    ((u8)0x02) /*!< Framing Error mask */
#define UART_SR_PE    ((u8)0x01) /*!< Parity Error mask */

#define UART_BRR1_DIVM  ((u8)0xFF) /*!< LSB mantissa of UARTDIV [7:0] mask */

#define UART_BRR2_DIVM  ((u8)0xF0) /*!< MSB mantissa of UARTDIV [11:8] mask */
#define UART_BRR2_DIVF  ((u8)0x0F) /*!< Fraction bits of UARTDIV [3:0] mask */

#define UART_CR1_R8      ((u8)0x80) /*!< Receive Data bit 8 */
#define UART_CR1_T8      ((u8)0x40) /*!< Transmit data bit 8 */
#define UART_CR1_UARTD   ((u8)0x20) /*!< UART1 Disable (for low power consumption) */
#define UART_CR1_M       ((u8)0x10) /*!< Word length mask */
#define UART_CR1_WAKE    ((u8)0x08) /*!< Wake-up method mask */
#define UART_CR1_PCEN    ((u8)0x04) /*!< Parity Control Enable mask */
#define UART_CR1_PS      ((u8)0x02) /*!< UART1 Parity Selection */
#define UART_CR1_PIEN    ((u8)0x01) /*!< UART1 Parity Interrupt Enable mask */

#define UART_CR2_TIEN    ((u8)0x80) /*!< Transmitter Interrupt Enable mask */
#define UART_CR2_TCIEN   ((u8)0x40) /*!< TransmissionComplete Interrupt Enable mask */
#define UART_CR2_RIEN    ((u8)0x20) /*!< Receiver Interrupt Enable mask */
#define UART_CR2_ILIEN   ((u8)0x10) /*!< IDLE Line Interrupt Enable mask */
#define UART_CR2_TEN     ((u8)0x08) /*!< Transmitter Enable mask */
#define UART_CR2_REN     ((u8)0x04) /*!< Receiver Enable mask */
#define UART_CR2_RWU     ((u8)0x02) /*!< Receiver Wake-Up mask */
#define UART_CR2_SBK     ((u8)0x01) /*!< Send Break mask */

#define UART_CR3_STOP    ((u8)0x30) /*!< STOP bits [1:0] mask */

#define UART_CR4_ADD     ((u8)0x0F) /*!< Address of the UART node mask */

/**
  * @}
  */
/*----------------------------------------------------------------------------*/
/**
  * @brief DALI
  */
typedef struct DALI_struct
{
	vu8 DALI_CLK_L; 	/*!<  Data Rate Control Register LSB */
	vu8 DALI_CLK_H; 	/*!<  Data Rate Control Register MSB*/
	vu8 DALI_FB0; 		/*!<  Forward Message byte 0 Register */
	vu8 DALI_FB1; 		/*!<  Forward Message byte 1 Register */
	vu8 DALI_FB2; 		/*!<  Forward Message byte 2 Register */
	vu8 DALI_BD; 			/*!<  Backward Message Register */
	vu8 DALI_CR; 			/*!<  Control Register */
	vu8 DALI_CSR; 		/*!<  Status and Control Register */
	vu8 DALI_CSR1; 		/*!<  Status and Control Register1 */
	vu8 DALI_REVLN; 	/*!<  Control reverse signal line */
}
DALI_TypeDef;

/** @addtogroup DALI_Registers_Reset_Value
  * @{
  */
#define  DALI_CLK_L_RESET_VALUE  	((u8)0x00)
#define  DALI_CLK_H_RESET_VALUE  	((u8)0x00)
#define  DALI_FB0_RESET_VALUE  		((u8)0x00)
#define  DALI_FB1_RESET_VALUE  		((u8)0x00)
#define  DALI_FB2_RESET_VALUE  		((u8)0x00)
#define  DALI_BD_RESET_VALUE  		((u8)0x00)
#define  DALI_CR_RESET_VALUE  		((u8)0x00)
#define  DALI_CSR_RESET_VALUE  		((u8)0x00)
#define  DALI_CSR1_RESET_VALUE 		((u8)0x00)
#define  DALI_REVLN_RESET_VALUE  	((u8)0x00)

/**
  * @}
  */
/** @addtogroup DALI_Registers_Bits_Definition
  * @{
  */
#define DALI_CR_LNWDG_EN	((u8)0x80) /*!< Interface failure monitor enable */
#define DALI_CR_SMK			((u8)0x40) /*!< Mask Start bit */
#define DALI_CR_MLN			((u8)0x30) /*!< Message length mask */
#define DALI_CR_DCME		((u8)0x08) /*!< Dali Communication enable */
#define DALI_CR_RTA			((u8)0x04) /*!< Receive/Transmit acknowledge */
#define DALI_CR_RTS			((u8)0x02) /*!< Receive/Transmit state */
#define DALI_CR_FRTS		((u8)0x01) /*!< Force Transmit State */

#define DALI_CSR_IEN		((u8)0x80) /*!< Interrupt Enable */
#define DALI_CSR_ITF		((u8)0x40) /*!< Interrupt Flag */
#define DALI_CSR_EF			((u8)0x20) /*!< Error Flag */
#define DALI_CSR_RTF		((u8)0x10) /*!< Receive/Transmit Flag */
#define DALI_CSR_WDGE		((u8)0x08) /*!< interface failure Interrupt enable */
#define DALI_CSR_WDGF		((u8)0x04) /*!< interface failure Interrupt flag */

#define DALI_CSR1_CKS		((u8)0xF0) /*!< Clock Counter Value mask */
#define DALI_CSR1_RDY_REC	((u8)0x08) /*!< Ready to receive Flag */
#define DALI_CSR1_WDG_PRSC	((u8)0x07) /*!< interface failure prescaler timer */

#define DALI_REVLN_REV_DOUT	((u8)0x04) /*!< Reverse Dali_tx signal line */
#define DALI_REVLN_REV_DIN	((u8)0x02) /*!< Reverse Dali_rx signal line */
#define DALI_REVLN_REV		((u8)0x01) /*!< Reverse Dali reverse signal line enable */

/**
  * @}
  */
/*----------------------------------------------------------------------------*/
/**
  * @brief Configuration Registers (CFGR)
  */
typedef struct CFGR_struct
{
  vu8 GCR; /*!< Global Configuration register */
}CFGR_TypeDef;

/** @addtogroup CFG_Registers_Reset_Value
  * @{
  */
#define CONFIG_GCR_RESET_VALUE ((u8)0x00)

/** @addtogroup CFG_Registers_Bits_Definition
  * @{
  */
#define CFGR_GCR_HSIT   ((u8)0x80) /*!< High Speed Oscillator Trimmed */
#define CFGR_GCR_AL  	((u8)0x02) /*!< Activation Level bit mask */
#define CFGR_GCR_SWD 	((u8)0x01) /*!< Swim disable bit mask */


/**
  * @}
  */

/*----------------------------------------------------------------------------*/
/**
  * @brief Miscellaneous registers (MSC)
  */

typedef struct MSC_struct
{
	vu8 CFGP00;		/*!< Control Register for P00 input line */
	vu8 CFGP01;		/*!< Control Register for P01 input line */
	vu8 CFGP02;		/*!< Control Register for P02 input line */
	vu8 CFGP03;		/*!< Control Register for P03 input line */
	vu8 CFGP04;		/*!< Control Register for P04 input line */
	vu8 CFGP05;		/*!< Control Register for P05 input line */
	vu8 CFGP20;		/*!< Control Register for P20 input line */
	vu8 CFGP21;		/*!< Control Register for P21 input line */
	vu8 CFGP22;		/*!< Control Register for P22 input line */
	vu8 CFGP23;		/*!< Control Register for P23 input line */
	vu8 CFGP24;		/*!< Control Register for P24 input line */
	vu8 CFGP25;		/*!< Control Register for P25 input line */
	vu8 STSP0;		/*!< Port 0 Status Register */
	vu8 STSP2;		/*!< Port 2 Status Register */
	vu8 INPP2;		/*!< Port 2 Read Register */
	vu8 RES1;		/*!< Reserved for future use */
	vu8 DACCTR;		/*!< Comparator4 and DAC4 configuration */
	vu8 DACIN0;		/*!< Input data of DAC0 */
	vu8 DACIN1;		/*!< Input data of DAC1 */
	vu8 DACIN2;		/*!< Input data of DAC2 */
	vu8 DACIN3;		/*!< Input data of DAC3 */
	vu8 SMDCFG01;	/*!< SMED 0-1 Behavioural register */
	vu8 SMDCFG23;	/*!< SMED 2-3 Behavioural register */
	vu8 SMDCFG45;	/*!< SMED 4-5 Behavioural register */
	vu8 SMSWEV;		/*!< SMEDs SW Events register */
	vu8 SMULOCK;	/*!< SMEDs unlock register */
	vu8 CBOXS0;		/*!< Connection Box selection SMED0 */
	vu8 CBOXS1;		/*!< Connection Box selection SMED1 */
	vu8 CBOXS2;		/*!< Connection Box selection SMED2 */
	vu8 CBOXS3;		/*!< Connection Box selection SMED3 */
	vu8 CBOXS4;		/*!< Connection Box selection SMED4 */
	vu8 CBOXS5;		/*!< Connection Box selection SMED5 */
	vu8 IOMXSMD;	/*!< I/O mux Port0 signal muxGPIO0/Smed fsm */
    vu8 CFGP10;     /*!< Control register for AUXTIM input line */
    vu8 CFGP11;     /*!< Control register for AUXTIM input line */
#ifdef _STLUX285A_
    vu8 RES2[2];	/*!< Reserved for future use */
#else
    vu8 CFGP12;     /*!< Control register for AUXTIM input line */
    vu8 CFGP13;     /*!< Control register for AUXTIM input line */
#endif //_STLUX285A_
    vu8 CFGP14;     /*!< Control register for AUXTIM input line */
    vu8 CFGP15;     /*!< Control register for AUXTIM input line */
    vu8 STSP1;      /*!< AUXTIM status register */
    vu8 RES3;   	/*!< Reserved for future use */
	vu8 INPP3;		/*!< Port 3 inputs read register (Comparator) */
	vu8 IOMXP0;		/*!< Mux alternate funct. on GPIO0 signals */
	vu8 IOMXP1;		/*!< I/O mux Port1 signals PWM/GPIO1 */
    vu8 IDXADD;     /*!< Miscellaneous indirect address */
    vu8 IDXDAT;     /*!< Miscellaneous indirect data */
}MSC_TypeDef;

/** @addtogroup MSC_Registers_Reset_Value
  * @{
  */
#define MSC_DACCTR_RESET_VALUE ((u8)0x00)
#define MSC_DACIN0_RESET_VALUE ((u8)0x00)
#define MSC_DACIN1_RESET_VALUE ((u8)0x00)
#define MSC_DACIN2_RESET_VALUE ((u8)0x00)
#define MSC_DACIN3_RESET_VALUE ((u8)0x00)
#define MSC_INPP3_RESET_VALUE ((u8)0x00)

#define MSC_SMDCFG01_RESET_VALUE ((u8)0x00)
#define MSC_SMDCFG23_RESET_VALUE ((u8)0x00)
#define MSC_SMDCFG45_RESET_VALUE ((u8)0x00)
#define MSC_SMSWEV_RESET_VALUE ((u8)0x00)
#define MSC_SMULOCK_RESET_VALUE ((u8)0x00)
#define MSC_CBOXS0_RESET_VALUE ((u8)0x00)
#define MSC_CBOXS1_RESET_VALUE ((u8)0x00)
#define MSC_CBOXS2_RESET_VALUE ((u8)0x00)
#define MSC_CBOXS3_RESET_VALUE ((u8)0x00)
#define MSC_CBOXS4_RESET_VALUE ((u8)0x00)
#define MSC_CBOXS5_RESET_VALUE ((u8)0x00)
#define MSC_IOMXSMD_RESET_VALUE ((u8)0x00)

#define MSC_CFGP00_RESET_VALUE ((u8)0x00)
#define MSC_CFGP01_RESET_VALUE ((u8)0x00)
#define MSC_CFGP02_RESET_VALUE ((u8)0x00)
#define MSC_CFGP03_RESET_VALUE ((u8)0x00)
#define MSC_CFGP04_RESET_VALUE ((u8)0x00)
#define MSC_CFGP05_RESET_VALUE ((u8)0x00)
#define MSC_CFGP10_RESET_VALUE ((u8)0x00)
#define MSC_CFGP11_RESET_VALUE ((u8)0x00)
#define MSC_CFGP12_RESET_VALUE ((u8)0x00)
#define MSC_CFGP13_RESET_VALUE ((u8)0x00)
#define MSC_CFGP14_RESET_VALUE ((u8)0x00)
#define MSC_CFGP15_RESET_VALUE ((u8)0x00)
#define MSC_CFGP20_RESET_VALUE ((u8)0x00)
#define MSC_CFGP21_RESET_VALUE ((u8)0x00)
#define MSC_CFGP22_RESET_VALUE ((u8)0x00)
#define MSC_CFGP23_RESET_VALUE ((u8)0x00)
#define MSC_CFGP24_RESET_VALUE ((u8)0x00)
#define MSC_CFGP25_RESET_VALUE ((u8)0x00)
#define MSC_STSP0_RESET_VALUE ((u8)0x00)
#define MSC_STSP1_RESET_VALUE ((u8)0x00)
#define MSC_STSP2_RESET_VALUE ((u8)0x00)
#define MSC_INPP2_RESET_VALUE ((u8)0x00)
#define MSC_IOMXP0_RESET_VALUE ((u8)0x11)
#define MSC_IOMXP1_RESET_VALUE ((u8)0x3F)



/**
  * @}
  */

/** @addtogroup MSC_Registers_Bits_Definition
  * @{
  */
#define MSC_DACCTR_DACBIAS_EN		((u8)0x80) /*!< Dac bias enable */

#if defined(_STLUX385A_) || defined(_STLUX383A_) || defined(_STLUX325A_)
#define MSC_DACCTR_DAC3_SEL			((u8)0x20) /*!< Comparator3 source reference voltage selection */
#define MSC_DACCTR_DAC3_EN			((u8)0x10) /*!< Enable Comparator3 logic unit */
#else //FOR ALL THE NEW DEVICES (STNRG FAMILY + STLUX285A)
#define MSC_DACCTR_DAC3_EN_EREF			((u8)0x80) /*!< Enable DAC3 External Reference logic unit */
#define MSC_DACCTR_DAC2_EN_EREF			((u8)0x40) /*!< Enable DAC2 External Reference logic unit */
#define MSC_DACCTR_DAC1_EN_EREF			((u8)0x20) /*!< Enable DAC1 External Reference logic unit */
#define MSC_DACCTR_DAC0_EN_EREF			((u8)0x10) /*!< Enable DAC0 External Reference logic unit */
#endif

//#define MSC_DACCTR_DAC3_EN			((u8)0x08) /*!< Enable DAC3 and Comparator3 logic unit */
//#define MSC_DACCTR_DAC2_EN			((u8)0x04) /*!< Enable DAC2 and Comparator2 logic unit */
//#define MSC_DACCTR_DAC1_EN			((u8)0x02) /*!< Enable DAC1 and Comparator1 logic unit */
//#define MSC_DACCTR_DAC0_EN			((u8)0x01) /*!< Enable DAC0 and Comparator0 logic unit */
#define MSC_DACIN0_DAC_IN0			((u8)0x0F) /*!< DAC0 input digital conversion data mask */
#define MSC_DACIN1_DAC_IN1			((u8)0x0F) /*!< DAC1 input digital conversion data mask */
#define MSC_DACIN2_DAC_IN2			((u8)0x0F) /*!< DAC2 input digital conversion data mask */
#define MSC_DACIN3_DAC_IN3			((u8)0x0F) /*!< DAC3 input digital conversion data mask */
#define MSC_INPP3_COMP				((u8)0x0F) /*!< Internal comparator logic output */

#define MSC_SMDCFG01_SMED1_GBLCONF	((u8)0xF0) /*!< SMED1 global configuration */
#define MSC_SMDCFG01_SMED0_GBLCONF	((u8)0x0F) /*!< SMED0 global configuration */

#define MSC_SMDCFG23_SMED3_GBLCONF	((u8)0xF0) /*!< SMED3 global configuration */
#define MSC_SMDCFG23_SMED2_GBLCONF	((u8)0x0F) /*!< SMED2 global configuration */

#define MSC_SMDCFG45_SMED5_GBLCONF	((u8)0xF0) /*!< SMED5 global configuration */
#define MSC_SMDCFG45_SMED4_GBLCONF	((u8)0x0F) /*!< SMED4 global configuration */

#define MSC_SMSWEV_SW5				((u8)0x20) /*!< SMED5 Software event */
#define MSC_SMSWEV_SW4				((u8)0x10) /*!< SMED4 Software event */
#define MSC_SMSWEV_SW3				((u8)0x08) /*!< SMED3 Software event */
#define MSC_SMSWEV_SW2				((u8)0x04) /*!< SMED2 Software event */
#define MSC_SMSWEV_SW1				((u8)0x02) /*!< SMED1 Software event */
#define MSC_SMSWEV_SW0				((u8)0x01) /*!< SMED0 Software event */

#define MSC_SMULOCK_UNLOCK_45		((u8)0x20) /*!< feature unlock for SMED4 and SMED5 */
#define MSC_SMULOCK_UNLOCK_23		((u8)0x10) /*!< feature unlock for SMED2 and SMED3 */
#define MSC_SMULOCK_UNLOCK_01		((u8)0x08) /*!< feature unlock for SMED0 and SMED1 */
#define MSC_SMULOCK_USE_UNLOCK_45	((u8)0x04) /*!< feature unlock for SMED4 and SMED5 enable */
#define MSC_SMULOCK_USE_UNLOCK_23	((u8)0x02) /*!< feature unlock for SMED2 and SMED3 enable */
#define MSC_SMULOCK_USE_UNLOCK_01	((u8)0x01) /*!< feature unlock for SMED0 and SMED1 enable */

#define MSC_CBOXS_CONB_S0_2			((u8)0x30) /*!< Connection box selection for the SMEDx input 2 */
#define MSC_CBOXS_CONB_S0_1			((u8)0x0C) /*!< Connection box selection for the SMEDx input 1 */
#define MSC_CBOXS_CONB_S0_0			((u8)0x03) /*!< Connection box selection for the SMEDx input 0 */

#define MSC_IOMXSMD_SEL_FSMEN1		((u8)0x80) /*!< Enable Smed�s States multiplexing output signal on P0[5:3] */
#define MSC_IOMXSMD_SMD_FSMS1		((u8)0x70) /*!< Smed�s States multiplexing output state selection */
#define MSC_IOMXSMD_SEL_FSMEN0		((u8)0x08) /*!< Enable Smed�s States multiplexing output signal on P0[2:0] */
#define MSC_IOMXSMD_SMD_FSMS0		((u8)0x07) /*!< Smed�s States multiplexing output state selection */

#define MSC_CFGP_INT_TYPE			((u8)0x10) /*!< Interrupt type configuration IRQ /NMI */
#define MSC_CFGP_INT_ENB			((u8)0x08) /*!< Interrupt enable */
#define MSC_CFGP_INT_SEL			((u8)0x06) /*!< Interrupt source configuration */
#define MSC_CFGP_INT_LEV			((u8)0x01) /*!< Interrupt request active level */

#define MSC_STSP_BIT_5_INT			((u8)0x20) /*!< Interrupt pending flag */
#define MSC_STSP_BIT_4_INT			((u8)0x10) /*!< Interrupt pending flag */
#define MSC_STSP_BIT_3_INT			((u8)0x08) /*!< Interrupt pending flag */
#define MSC_STSP_BIT_2_INT			((u8)0x04) /*!< Interrupt pending flag */
#define MSC_STSP_BIT_1_INT			((u8)0x02) /*!< Interrupt pending flag */
#define MSC_STSP_BIT_0_INT			((u8)0x01) /*!< Interrupt pending flag */

#define MSC_INPP2_DATA_IN			((U8)0x3F) /*!< Port P2 input signals */

#define MSC_IOMXP0_SEL_P054			((u8)0x30) /*!< Port0[5:4] I/O multiplexing scheme */
#define MSC_IOMXP0_SEL_P032			((u8)0x0C) /*!< Port0[3:2] I/O multiplexing scheme */
#define MSC_IOMXP0_SEL_P010			((u8)0x03) /*!< Port0[1:0] I/O multiplexing scheme */

#define MSC_IOMXP1_SEL_P15			((u8)0x20) /*!< Port1[5] I/O multiplexing scheme */
#define MSC_IOMXP1_SEL_P14			((u8)0x10) /*!< Port1[4] I/O multiplexing scheme */
#define MSC_IOMXP1_SEL_P13			((u8)0x08) /*!< Port1[3] I/O multiplexing scheme */
#define MSC_IOMXP1_SEL_P12			((u8)0x04) /*!< Port1[2] I/O multiplexing scheme */
#define MSC_IOMXP1_SEL_P11			((u8)0x02) /*!< Port1[1] I/O multiplexing scheme */
#define MSC_IOMXP1_SEL_P10			((u8)0x01) /*!< Port1[0] I/O multiplexing scheme */

//Miscellaneous Registers Indirect Address
#if !defined(_STLUX385A_) && !defined(_STLUX383A_) && !defined(_STLUX325A_)
#define	MSC_FTM0CKSEL	0x00	/*!< Filter 0/1 clock selection */
#define	MSC_FTM0CKDIV	0x01	/*!< Filter 0 clock division */
#define	MSC_FTM0CONF		0x02	/*!< Filter 0 mode configuration and counter */
#define	MSC_FTM1CKDIV	0x03	/*!< Filter 1 clock division */
#define	MSC_FTM1CONF		0x04	/*!< Filter 1 mode configuration and counter */
#endif 

#define	MSC_DALICKSEL	0x05	/*!< Filter 2/3 clock selection */
#define	MSC_DALICKDIV	0x06	/*!< Filter 2 clock division */
#define	MSC_DALICONF	0x07	/*!< Filter 2 mode configuration and counter */
#define	MSC_INPP2AUX1	0x08	/*!< Filter 3 clock division */
#define	MSC_INPP2AUX2	0x09	/*!< Filter 3 mode configuration and counter */

#if !defined(_STLUX385A_) && !defined(_STLUX383A_) && !defined(_STLUX325A_)
#define	MSC_DAC0HYS		0x0A	/*!< DAC0 hysteresis configuration */
#define	MSC_DAC1HYS		0x0B	/*!< DAC1 hysteresis configuration */
#define	MSC_DAC2HYS		0x0C	/*!< DAC2 hysteresis configuration */
#define	MSC_DAC3HYS		0x0D	/*!< DAC3 hysteresis configuration */
#define MSC_CFGP30		0x0E	/*!< Control Register for P30 input line */
#define MSC_CFGP31		0x0F	/*!< Control Register for P31 input line */
#define MSC_CFGP32		0x10	/*!< Control Register for P32 input line */
#define MSC_CFGP33		0x11	/*!< Control Register for P33 input line */
#define MSC_STSP3		0x12	/*!< Port 3 Status Register */
#endif

#define MSC_IOMXP2		0x13	/*!< I/O mux Port2 signals DIGIN */

//Miscellaneous Indirect Registers Reset Values
#if !defined(_STLUX385A_) && !defined(_STLUX383A_) && !defined(_STLUX325A_)

#define	MSC_FTM0CKSEL_RESET_VALUE	((u8)0x00) /*!< Filter 0/1 clock selection */
#define	MSC_FTM0CKDIV_RESET_VALUE	((u8)0x00) /*!< Filter 0 clock division */
#define	MSC_FTM0CONF_RESET_VALUE	((u8)0x00) /*!< Filter 0 mode configuration and counter */
#define	MSC_FTM1CKDIV_RESET_VALUE	((u8)0x00) /*!< Filter 1 clock division */
#define	MSC_FTM1CONF_RESET_VALUE	((u8)0x00) /*!< Filter 1 mode configuration and counter */

#endif 

#define	MSC_DALICKSEL_RESET_VALUE	((u8)0x00) /*!< Filter 2/3 clock selection */
#define	MSC_DALICKDIV_RESET_VALUE	((u8)0x00) /*!< Filter 2 clock division */
#define	MSC_DALICONF_RESET_VALUE	((u8)0x00) /*!< Filter 2 mode configuration and counter */
#define	MSC_INPP2AUX1_RESET_VALUE	((u8)0x00) /*!< Filter 3 clock division */
#define	MSC_INPP2AUX2_RESET_VALUE	((u8)0x00) /*!< Filter 3 mode configuration and counter */

#if !defined(_STLUX385A_) && !defined(_STLUX383A_) && !defined(_STLUX325A_)
#define	MSC_DAC0HYS_RESET_VALUE		((u8)0x00) /*!< DAC0 hysteresis configuration */
#define	MSC_DAC1HYS_RESET_VALUE		((u8)0x00) /*!< DAC1 hysteresis configuration */
#define	MSC_DAC2HYS_RESET_VALUE		((u8)0x00) /*!< DAC2 hysteresis configuration */
#define	MSC_DAC3HYS_RESET_VALUE		((u8)0x00) /*!< DAC3 hysteresis configuration */
#define MSC_CFGP30_RESET_VALUE		((u8)0x00) /*!< Control Register for P30 input line */
#define MSC_CFGP31_RESET_VALUE		((u8)0x00) /*!< Control Register for P31 input line */
#define MSC_CFGP32_RESET_VALUE		((u8)0x00) /*!< Control Register for P32 input line */
#define MSC_CFGP33_RESET_VALUE		((u8)0x00) /*!< Control Register for P33 input line */
#define MSC_STSP3_RESET_VALUE		((u8)0x00) /*!< Port 3 Status Register */
#endif

/******************************************************************************/
/*                          Peripherals Base Address                          */
/******************************************************************************/

/** @addtogroup MAP_FILE_Base_Addresses
  * @{
  */
#define OPT_BaseAddress 		0x4800
#define GPIO0_BaseAddress 		0x5000
#define GPIO1_BaseAddress 		0x5005
#define MSC_BaseAddress	        0x5010
#define RST_BaseAddress		    0x50B3
#define FLASH_BaseAddress 	    0x505A
#define CLK_BaseAddress         0x50B4
#define WWDG_BaseAddress 		0x50D1
#define IWDG_BaseAddress 		0x50E0
#define AWU_BaseAddress 		0x50F0
#define I2C_BaseAddress 		0x5210
#define UART_BaseAddress		0x5230
#define STMR_BaseAddress 		0x5340
#define DALI_BaseAddress 		0x53C0
#define ADC_BaseAddress 		0x5400
#define SMED0_BaseAddress       0x5500 
#define SMED1_BaseAddress       0x5540
#define SMED2_BaseAddress       0x5580 
#define SMED3_BaseAddress       0x55C0 
#define SMED4_BaseAddress       0x5600 
#define SMED5_BaseAddress       0x5640 
#define CFGR_BaseAddress 		0x7F60
#define ITC_BaseAddress		    0x7F70
#define SWIM_BaseAddress 		0x7F80

/**
  * @}
  */
/******************************************************************************/
/*                          Peripherals declarations                          */
/******************************************************************************/
#define GPIO0 		((GPIO_TypeDef *) 		GPIO0_BaseAddress)
#define GPIO1 		((GPIO_TypeDef *) 		GPIO1_BaseAddress)
#define STMR 		((STMR_TypeDef *) 		STMR_BaseAddress)  
#define SMED0		((SMED_TypeDef *) 	    SMED0_BaseAddress)
#define SMED1		((SMED_TypeDef *) 	    SMED1_BaseAddress)
#define SMED2		((SMED_TypeDef *) 	    SMED2_BaseAddress)
#define SMED3		((SMED_TypeDef *) 	    SMED3_BaseAddress)
#define SMED4		((SMED_TypeDef *) 	    SMED4_BaseAddress)
#define SMED5		((SMED_TypeDef *) 	    SMED5_BaseAddress)
#define MSC     	((MSC_TypeDef *) 	    MSC_BaseAddress)
#define OPT 		((OPT_TypeDef *)		OPT_BaseAddress)
#define RST 		((RST_TypeDef *) 		RST_BaseAddress)
#define FLASH 	    ((FLASH_TypeDef *)  	FLASH_BaseAddress)
#define CLK 		((CLK_TypeDef *) 		CLK_BaseAddress)
#define WWDG 		((WWDG_TypeDef *) 	    WWDG_BaseAddress)
#define IWDG 		((IWDG_TypeDef *) 	    IWDG_BaseAddress)
#define AWU 		((AWU_TypeDef *) 		AWU_BaseAddress)
#define I2C 		((I2C_TypeDef *) 		I2C_BaseAddress)
#define UART 		((UART_TypeDef *) 	    UART_BaseAddress)
#define DALI 		((DALI_TypeDef *) 	    DALI_BaseAddress)
#define ADC 		((ADC_TypeDef *) 		ADC_BaseAddress)
#define CFGR 		((CFGR_TypeDef *) 		CFGR_BaseAddress)
#define ITC			((ITC_TypeDef *)		ITC_BaseAddress)
#define SWIM 		((SWIM_TypeDef *) 	    SWIM_BaseAddress)

#define DEV_ID      ((u8 *) 	            0x4896)
#define Rev_ID      ((u8 *) 	            0x4898)
#define Rev_ID_MASK      0x1F

/* Exported macro --------------------------------------------------------------*/

/*============================== Interrupts ====================================*/
#ifdef _RAISONANCE_
 #include <intrist7.h>
 #define enableInterrupts()    _rim_()  /* enable interrupts */
 #define disableInterrupts()   _sim_()  /* disable interrupts */
 #define rim()                 _rim_()  /* enable interrupts */
 #define sim()                 _sim_()  /* disable interrupts */
 #define nop()                 _nop_()  /* No Operation */
 #define trap()                _trap_() /* Trap (soft IT) */
 #define wfi()                 _wfi_()  /* Wait For Interrupt */
 #define halt()                _halt_() /* Halt */
#elif defined(_COSMIC_)
 #define enableInterrupts()    {_asm("rim\n");}  /* enable interrupts */
 #define disableInterrupts()   {_asm("sim\n");}  /* disable interrupts */
 #define rim()                 {_asm("rim\n");}  /* enable interrupts */
 #define sim()                 {_asm("sim\n");}  /* disable interrupts */
 #define nop()                 {_asm("nop\n");}  /* No Operation */
 #define trap()                {_asm("trap\n");} /* Trap (soft IT) */
 #define wfi()                 {_asm("wfi\n");}  /* Wait For Interrupt */
 #define halt()                {_asm("halt\n");} /* Halt */
#else /*_IAR_*/
 #include <intrinsics.h>
 #define enableInterrupts()    __enable_interrupt()  /* enable interrupts */
 #define disableInterrupts()   __disable_interrupt() /* disable interrupts */
 #define rim()                 __enable_interrupt()  /* enable interrupts */
 #define sim()                 __disable_interrupt() /* disable interrupts */
 #define nop()                 __no_operation()      /* No Operation */
 #define trap()                __trap()              /* Trap (soft IT) */
 #define wfi()                 __wait_for_interrupt() /* Wait For Interrupt */
 #define halt()                __halt()              /* Halt */
#endif /*_RAISONANCE_*/

/*============================ Access to the INDIRECT area ========================*/

#define	INDIRECT_RD(a,d) MSC->IDXADD=a; d=MSC->IDXDAT;
#define	INDIRECT_WR(a,d) MSC->IDXADD=a; MSC->IDXDAT=d;

/*============================== Interrupt vector Handling ========================*/

#ifdef _COSMIC_
 #define INTERRUPT_HANDLER(a,b) @interrupt void a(void)
 #define INTERRUPT_HANDLER_TRAP(a) void @interrupt a(void)
#endif /* _COSMIC_ */

#ifdef _RAISONANCE_
 #define INTERRUPT_HANDLER(a,b) void a(void) interrupt b
 #define INTERRUPT_HANDLER_TRAP(a) void a(void) trap
#endif /* _RAISONANCE_ */

#ifdef _IAR_
 #define STRINGVECTOR(x) #x
 #define VECTOR_ID(x) STRINGVECTOR( vector = (x) )
 #define INTERRUPT_HANDLER( a, b )  \
 _Pragma( VECTOR_ID( (b)+2 ) )        \
 __interrupt void (a)( void )
 #define INTERRUPT_HANDLER_TRAP(a) \
 _Pragma( VECTOR_ID( 1 ) ) \
 __interrupt void (a) (void)  
#endif /* _IAR_ */

/*============================== INLINE directive declaration ========================*/
#ifdef _RAISONANCE_			//_RAISONANCE_
#define INLINE inline
#elif defined (_COSMIC_)  //_COSMIC_
#define INLINE 			
#elif defined (_IAR_)  //_IAR_
#define INLINE 
#endif  //_IAR_
 
/*============================== Interrupt Handler declaration ========================*/
#ifdef _COSMIC_
 #define INTERRUPT @interrupt
#elif defined(_IAR_)
 #define INTERRUPT __interrupt
#endif /* _COSMIC_ */

/*============================== Handling bits ====================================*/
/*-----------------------------------------------------------------------------
Method : I
Description : Handle the bit from the character variables.
Comments :    The different parameters of commands are
              - VAR : Name of the character variable where the bit is located.
              - Place : Bit position in the variable (7 6 5 4 3 2 1 0)
              - Value : Can be 0 (reset bit) or not 0 (set bit)
              The "MskBit" command allows to select some bits in a source
              variables and copy it in a destination var (return the value).
              The "ValBit" command returns the value of a bit in a char
              variable: the bit is reseted if it returns 0 else the bit is set.
              This method generates not an optimised code yet.
-----------------------------------------------------------------------------*/
#define SetBit(VAR,Place)         ( (VAR) |= (u8)((u8)1<<(u8)(Place)) )
#define ClrBit(VAR,Place)         ( (VAR) &= (u8)((u8)((u8)1<<(u8)(Place))^(u8)255) )

#define ChgBit(VAR,Place)         ( (VAR) ^= (u8)((u8)1<<(u8)(Place)) )
#define AffBit(VAR,Place,Value)   ((Value) ? \
                                   ((VAR) |= ((u8)1<<(Place))) : \
                                   ((VAR) &= (((u8)1<<(Place))^(u8)255)))
#define MskBit(Dest,Msk,Src)      ( (Dest) = ((Msk) & (Src)) | ((~(Msk)) & (Dest)) )

#define ValBit(VAR,Place)         ((u8)(VAR) & (u8)((u8)1<<(u8)(Place)))

#define BYTE_0(n)                 ((u8)((n) & (u8)0xFF))        /*!< Returns the low byte of the 32-bit value */
#define BYTE_1(n)                 ((u8)(BYTE_0((n) >> (u8)8)))  /*!< Returns the second byte of the 32-bit value */
#define BYTE_2(n)                 ((u8)(BYTE_0((n) >> (u8)16))) /*!< Returns the third byte of the 32-bit value */
#define BYTE_3(n)                 ((u8)(BYTE_0((n) >> (u8)24))) /*!< Returns the high byte of the 32-bit value */

/*============================== Assert Macros ====================================*/
#define IS_STATE_VALUE_OK(SensitivityValue) \
  (((SensitivityValue) == ENABLE) || \
   ((SensitivityValue) == DISABLE))

/*-----------------------------------------------------------------------------
Method : II
Description : Handle directly the bit.
Comments :    The idea is to handle directly with the bit name. For that, it is
              necessary to have RAM area descriptions (example: HW register...)
              and the following command line for each area.
              This method generates the most optimized code.
-----------------------------------------------------------------------------*/

#define AREA 0x00     /* The area of bits begins at address 0x10. */

#define BitClr(BIT)  ( *((unsigned char *) (AREA+(BIT)/8)) &= (~(1<<(7-(BIT)%8))) )
#define BitSet(BIT)  ( *((unsigned char *) (AREA+(BIT)/8)) |= (1<<(7-(BIT)%8)) )
#define BitVal(BIT)  ( *((unsigned char *) (AREA+(BIT)/8)) & (1<<(7-(BIT)%8)) )

/* Exported functions ------------------------------------------------------- */

#endif

/****************************************************************************/

/******************* (C) COPYRIGHT 2015 STMicroelectronics *****END OF FILE****/
