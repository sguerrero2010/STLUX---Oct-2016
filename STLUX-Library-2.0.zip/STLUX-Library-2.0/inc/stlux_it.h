/**
  ******************************************************************************
  * @file     stlux_it.h
  * @brief    This file contains the headers of the interrupt handlers
  * @author   STMicroelectronics
  * @version V2.0
  * @date 27/10/2015
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  ******************************************************************************
  */ 

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __STLUX_IT_H
#define __STLUX_IT_H

/* Includes ------------------------------------------------------------------*/
#include "stlux.h"

/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */

#ifdef _COSMIC_
 void _stext(void); /* RESET startup routine */
 INTERRUPT void NonHandledInterrupt(void);
#endif /* _COSMIC_ */

#ifndef _RAISONANCE_ /* COSMIC and IAR */

 INTERRUPT void TRAP_IRQHandler(void);          /* TRAP */
 INTERRUPT void NMI_IRQHandler(void);           /* irq 0 - NMI */
 INTERRUPT void AWU_IRQHandler(void);           /* irq 1 - AWU */
 INTERRUPT void CLK_IRQHandler(void);           /* irq 2 - CLOCK */
 INTERRUPT void PORT0_IRQHandler(void);         /* irq 3 - EXTI PORT0 */
 INTERRUPT void PORT1_IRQHandler(void);         /* irq 4 - Ext PORT1 - Aux/Bsc timer */ 
 INTERRUPT void PORT2_IRQHandler(void);         /* irq 5 - EXTI PORT2 (DIGIN) */
 INTERRUPT void SMED0_IRQHandler(void);         /* irq 6 - SMED0 */
 INTERRUPT void SMED1_IRQHandler(void); 		/* irq 7 - SMED1 */
 
#if defined(_STNRG388A_) || defined(_STNRG328A_) || defined(_STNRG288A_) 
 INTERRUPT void INPP3_IRQHandler(void); 		/* irq 8 - INPP3 - Comparators */
#endif //STNRG 

 INTERRUPT void SMED2_IRQHandler(void); 		/* irq 15 - SMED2 */
 INTERRUPT void SMED3_IRQHandler(void); 		/* irq 16 - SMED3 */
 INTERRUPT void UART_TX_IRQHandler(void);       /* irq 17 - UART TX */
 INTERRUPT void UART_RX_IRQHandler(void);       /* irq 18 - UART RX */
 INTERRUPT void I2C_IRQHandler(void);           /* irq 19 - I2C */
 INTERRUPT void ADC_IRQHandler(void);           /* irq 22 - ADC */
 INTERRUPT void STMR_IRQHandler(void);   		/* irq 23 - STMR Update interrupt */
 INTERRUPT void FLASH_IRQHandler(void);         /* irq 24 - EOC/WR_PG_DIS */
 INTERRUPT void DALI_IRQHandler(void);          /* irq 25 - DALI */
 INTERRUPT void SMED4_IRQHandler(void); 		/* irq 26 - SMED4 */
 INTERRUPT void SMED5_IRQHandler(void); 		/* irq 27 - SMED5 */

#endif /* not _RAISONANCE_ */

#endif /* __STLUX_IT_H */

/******************* (C) COPYRIGHT 2015 STMicroelectronics *****END OF FILE****/
