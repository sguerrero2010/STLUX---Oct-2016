/**
  ******************************************************************************
  * @file    stlux_flash.h
  * @brief This file contains all the prototypes/macros for the Flash Data Memory.
  * @author STMicroelectronics
  * @version V2.0
  * @date 27/10/2015
  ******************************************************************************
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __STLUX_FLASH_H
#define __STLUX_FLASH_H

/* Includes ------------------------------------------------------------------*/
#include "stlux.h"

/* Exported constants --------------------------------------------------------*/

#define FLASH_RASS_KEY1 ((u8)0x56) /*!< First RASS key */
#define FLASH_RASS_KEY2 ((u8)0xAE) /*!< Second RASS key */

/* Exported types ------------------------------------------------------------*/

/* Exported functions ------------------------------------------------------- */

void Unlock_eeprom_data_area(void);
void Lock_eeprom_data_area(void);
void Dump_data_to_eeprom(u16 ramaddr, u16 eeaddr);
void Write_data_eeprom(u16 addr, u8 val);
u8 Read_8_data_eeprom(u16 addr);

#endif /*__STLUX_FLASH_H */

/******************* (C) COPYRIGHT 2015 STMicroelectronics *****END OF FILE****/