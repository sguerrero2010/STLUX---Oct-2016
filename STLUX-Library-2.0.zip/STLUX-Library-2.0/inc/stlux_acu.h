/**
  ******************************************************************************
  * @file stlux_acu.h
  * @brief This file contains all the prototypes/macros for the ACU peripheral.
  * @author STMicroelectronics
  * @version V2.0
  * @date 27/10/2015
  ******************************************************************************
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  ******************************************************************************
  */


/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __STLUX_ACU_H
#define __STLUX_ACU_H

/* Includes ------------------------------------------------------------------*/
#include "stlux.h"


/*-----------------------------------------------------------------------------------------*/


/**
  * @brief ACU DAC input values
  */
typedef enum {
DACIN_0mV     =   ((u8)0x0),
DACIN_82mV    =   ((u8)0x1),
DACIN_164mV   =   ((u8)0x2),
DACIN_246mV   =   ((u8)0x3),
DACIN_328mV   =   ((u8)0x4),
DACIN_410mV   =   ((u8)0x5),
DACIN_492mV   =   ((u8)0x6),
DACIN_574mV   =   ((u8)0x7),
DACIN_656mV   =   ((u8)0x8),
DACIN_738mV   =   ((u8)0x9),
DACIN_820mV   =   ((u8)0xA),
DACIN_902mV   =   ((u8)0xB),
DACIN_984mV   =   ((u8)0xC),
DACIN_1066mV  =   ((u8)0xD),
DACIN_1148mV  =   ((u8)0xE),
DACIN_1230mV  =   ((u8)0xF)
} ACU_DACIN_VALUES_TypeDef;


#if !defined(_STLUX385A_) && !defined(_STLUX383A_) && !defined(_STLUX325A_)
/**
  * @brief ACU Hysteresis voltage codes
  */
typedef enum {
HYSTDN_V_CODE0  =   ((u8)0x08),
HYSTDN_V_CODE3  =   ((u8)0x03),
HYSTDN_V_CODE4  =   ((u8)0x04),
HYSTDN_V_CODE5  =   ((u8)0x05),
HYSTDN_V_CODE6  =   ((u8)0x06),
HYSTDN_V_CODE7  =   ((u8)0x07),
HYSTUP_V_CODE0  =   ((u8)0x80),
HYSTUP_V_CODE3  =   ((u8)0x30),
HYSTUP_V_CODE4  =   ((u8)0x40),
HYSTUP_V_CODE5  =   ((u8)0x50),
HYSTUP_V_CODE6  =   ((u8)0x60),
HYSTUP_V_CODE7  =   ((u8)0x70)
} ACU_HYS_VALUES_TypeDef;
#endif

/*-----------------------------------------------------------------------------------------*/



/**
  * @brief ACU Comparator selection
  */
typedef enum {
  CMP_0  = ((u8)0x01),
  CMP_1  = ((u8)0x02),
  CMP_2  = ((u8)0x04),
  CMP_3  = ((u8)0x08)
} ACU_Selection_TypeDef;


/*-----------------------------------------------------------------------------------------*/

/**
  * @brief ACU Comparator 3 negative input selection
  */
typedef enum {
#if defined(_STLUX385A_) || defined(_STLUX383A_) || defined(_STLUX325A_)
  ACU_CP3_SEL_EXT  = MSC_DACCTR_DAC3_SEL,
  ACU_CP3_SEL_INT  = (u8)0x00
#else // FOR ALL THE NEW DEVICES (STNRG FAMILY + STLUX285A)
  ACU_CP0_SEL_EXT  = MSC_DACCTR_DAC0_EN_EREF,
  ACU_CP1_SEL_EXT  = MSC_DACCTR_DAC1_EN_EREF,
  ACU_CP2_SEL_EXT  = MSC_DACCTR_DAC2_EN_EREF,
  ACU_CP3_SEL_EXT  = MSC_DACCTR_DAC3_EN_EREF,
  ACU_CPx_SEL_INT  = (u8)0x00
#endif
} ACU_CP_SEL_Typedef;


/*-----------------------------------------------------------------------------------------*/


/**
  * @}
  */

/* Exported functions ------------------------------------------------------- */

/** @addtogroup ADC_Exported_Functions
  * @{
  */
void ACU_Reset(void);

#if defined(_STLUX385A_) || defined(_STLUX383A_) || defined(_STLUX325A_)
void ACU_Init(void);
#endif

bool ACU_Read(ACU_Selection_TypeDef ACUx);
void ACU_Enable(ACU_Selection_TypeDef ACUx, ACU_CP_SEL_Typedef CP_SEL);
void ACU_Disable(ACU_Selection_TypeDef ACUx);
void ACU_SetCompareLevel(ACU_Selection_TypeDef ACUx,ACU_DACIN_VALUES_TypeDef DACIN);

#if !defined(_STLUX385A_) && !defined(_STLUX383A_) && !defined(_STLUX325A_)
void ACU_SetHysteresisLevel(ACU_Selection_TypeDef ACUx,ACU_HYS_VALUES_TypeDef HYSIN);
#endif

/**
  * @}
  */

#endif /* __STLUX_ADC_H */

/******************* (C) COPYRIGHT 2015 STMicroelectronics *****END OF FILE****/
