/**
  ******************************************************************************
  * @file stlux_atm.c
  * @brief This file contains all the functions/macros for the Auxiliaty Timer.
  * @author STMicroelectronics
  * @version V2.0
  * @date 27/10/2015
  ******************************************************************************
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  ******************************************************************************
  */

#ifndef __STLUX_ATM_H
#define __STLUX_ATM_H

/* Includes ------------------------------------------------------------------*/

#include "stlux_clk.h"

/* Exported types ------------------------------------------------------------*/
// Interrupt Sensitivity Level system configuration.
typedef enum {
  ATM_IT_LEV_HIGH       = (u8)0x01,     /*!< Set Interrupt Sensitivity Level on high level or rising edge */
  ATM_IT_LEV_LOW        = (u8)(~0x01)   /*!< Set Interrupt Sensitivity Level on low level or falling edge */
} ATM_ITPolarity_TypeDef;

// Interrupt Trigger system configuration.
typedef enum {
  ATM_IT_SEL_EDGE       = (u8)0x04,     /*!< Set Interrupt Trigger on rising/falling edge */
  ATM_IT_SEL_LEVEL      = (u8)0x06,     /*!< Set Interrupt Trigger on high/low level */
  ATM_IT_SEL_LEVWAKEUP  = (u8)(~0x06)   /*!< Set Interrupt Trigger on high/low asynchronous level with wakeup capability */
}ATM_ITTrigger_TypeDef;

// Interrupt Type system configuration.
typedef enum {
  ATM_IT_TYPE_IRQ       = (u8)(~0x10),     /*!< Set Interrupt Type to Maskable Interrupt */
  ATM_IT_TYPE_NMI       = (u8)0x10,     /*!< Set Interrupt Type to Non Maskable Interrupt */
  ATM_IT_TYPE_POL       = (u8)0x00     /*!< Set to Polling mode. No Interrupt is generated */
}ATM_ITType_TypeDef; 

/* Exported constants --------------------------------------------------------*/

/* Exported macros -------------------------------------------------------------*/
/* Exported variables ---------------------------------------------------------*/

/* Public functions ----------------------------------------------------------*/

void ATM_Reset(void);
void ATM_Config(CLK_Output_TypeDef CLK_CCO,u8 CLK_CCODIVR, ATM_ITPolarity_TypeDef IT_LEV, ATM_ITTrigger_TypeDef IT_SEL, ATM_ITType_TypeDef IT_TYPE);
void ATM_OutDigIn0(FunctionalState NewState);
void ATM_ITConfig(FunctionalState NewState);
void ATM_ITClear(void);
#endif //__STLUX_ATM_H

/******************* (C) COPYRIGHT 2015 STMicroelectronics *****END OF FILE****/
