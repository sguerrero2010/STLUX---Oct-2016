/**
  ******************************************************************************
  * @file    stlux_awu.h
  * @brief   This file contains all functions prototype and macros for the AWU peripheral.
  * @author  STMicroelectronics
  * @version V2.0
  * @date 27/10/2015
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __STLUX_AWU_H
#define __STLUX_AWU_H

/* Includes ------------------------------------------------------------------*/
#include "stlux.h"

/* Exported types ------------------------------------------------------------*/

/** @addtogroup AWU_Exported_Types
  * @{
  */

/**
  * @brief  AWU TimeBase selection
  */
//!< AWU Timebase equals to [2^(TBR-1) * APRDIV / f_AWU] ms
typedef enum
{
  AWU_TIMEBASE_NO_IT    = (u8)0,  //!< No AWU interrupt selected 
  AWU_TIMEBASE_1        = (u8)1,  //!< AWU Timebase equals to [2^0  * APRDIV / f_AWU] ms
  AWU_TIMEBASE_2        = (u8)2,  //!< AWU Timebase equals to [2^1  * APRDIV / f_AWU] ms
  AWU_TIMEBASE_4        = (u8)3,  //!< AWU Timebase equals to [2^2  * APRDIV / f_AWU] ms
  AWU_TIMEBASE_8        = (u8)4,  //!< AWU Timebase equals to [2^3  * APRDIV / f_AWU] ms
  AWU_TIMEBASE_16       = (u8)5,  //!< AWU Timebase equals to [2^4  * APRDIV / f_AWU] ms
  AWU_TIMEBASE_32       = (u8)6,  //!< AWU Timebase equals to [2^5  * APRDIV / f_AWU] ms
  AWU_TIMEBASE_64       = (u8)7,  //!< AWU Timebase equals to [2^6  * APRDIV / f_AWU] ms
  AWU_TIMEBASE_128      = (u8)8,  //!< AWU Timebase equals to [2^7  * APRDIV / f_AWU] ms
  AWU_TIMEBASE_256      = (u8)9,  //!< AWU Timebase equals to [2^8  * APRDIV / f_AWU] ms
  AWU_TIMEBASE_1024     = (u8)10, //!< AWU Timebase equals to [2^9  * APRDIV / f_AWU] ms
  AWU_TIMEBASE_2048     = (u8)11, //!< AWU Timebase equals to [2^10 * APRDIV / f_AWU] ms
  AWU_TIMEBASE_4096     = (u8)12, //!< AWU Timebase equals to [2^11 * APRDIV / f_AWU] ms
  AWU_TIMEBASE_8192     = (u8)13, //!< AWU Timebase equals to [2^12 * APRDIV / f_AWU] ms
  AWU_TIMEBASE_16384    = (u8)14, //!< AWU Timebase equals to [2^13 * APRDIV / f_AWU] ms
  AWU_TIMEBASE_32768    = (u8)15  //!< AWU Timebase equals to [2^14 * APRDIV / f_AWU] ms
} AWU_Timebase_TypeDef;

/**
  * @}
  */

/* Exported constants --------------------------------------------------------*/

/** @addtogroup AWU_Exported_Constants
  * @{
  */

/**
  * @}
  */

/* Exported macros ------------------------------------------------------------*/

/* Private macros ------------------------------------------------------------*/

/* Exported functions ------------------------------------------------------- */
void AWU_Reset(void);
void AWU_Init(u8 AWU_Prescaler, AWU_Timebase_TypeDef AWU_TimeBase);
void AWU_Enable(FunctionalState NewState);
void AWU_IdleModeEnable(void);
FlagStatus AWU_GetStatus(void);

/**
  * @}
  */

#endif /* __STLUX_AWU_H */

/******************* (C) COPYRIGHT 2015 STMicroelectronics *****END OF FILE****/
