/**
  ******************************************************************************
  * @file stlux_stmr.h
  * @brief This file contains function definitions System Timer of STLUX / STNRG
  * @author STMicroelectronics
  * @version V2.0
  * @date 27/10/2015
  ******************************************************************************
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __STLUX_STMR_H
#define __STLUX_STMR_H

#include "stm8s_type.h"
#include "stlux.h"


/** STMR Prescaler */
typedef enum
{
    STMR_PRESCALER_1	 = ((u8)0x00),	/*!< Time base Prescaler = 1 (No effect)*/
    STMR_PRESCALER_2   	 = ((u8)0x01),  /*!< Time base Prescaler = 2 */
    STMR_PRESCALER_4   	 = ((u8)0x02),  /*!< Time base Prescaler = 4 */
    STMR_PRESCALER_8	 = ((u8)0x03),  /*!< Time base Prescaler = 8 */
    STMR_PRESCALER_16  	 = ((u8)0x04),  /*!< Time base Prescaler = 16 */
    STMR_PRESCALER_32    = ((u8)0x05),  /*!< Time base Prescaler = 32 */
    STMR_PRESCALER_64    = ((u8)0x06),  /*!< Time base Prescaler = 64 */
    STMR_PRESCALER_128   = ((u8)0x07)  /*!< Time base Prescaler = 128 */
}STMR_Prescaler_TypeDef;

/** STMR One Pulse Mode */
typedef enum
{
    STMR_OPMODE_SINGLE		 = ((u8)0x01),  /*!< Single one Pulse mode (OPM Active) */
    STMR_OPMODE_REPETITIVE   = ((u8)0x00)   /*!< Repetitive Pulse mode (OPM inactive) */
}STMR_OPMode_TypeDef;

/** STMR Prescaler Reload Mode */
typedef enum
{
  STMR_PSCRELOADMODE_UPDATE          = ((u8)0x00),
  STMR_PSCRELOADMODE_IMMEDIATE       = ((u8)0x01)
} STMR_PSCReloadMode_TypeDef;

/** STMR Update Source */
typedef enum
{
  STMR_UPDATESOURCE_GLOBAL           = ((u8)0x00),
  STMR_UPDATESOURCE_REGULAR          = ((u8)0x01)
} STMR_UpdateSource_TypeDef;


/** STMR Event Source */
typedef enum
{
  STMR_EVENTSOURCE_UPDATE            = ((u8)0x01)
}STMR_EventSource_TypeDef;

/** STMR Flags */
typedef enum
{
  STMR_FLAG_UPDATE                   = ((u8)0x01)
}STMR_FLAG_TypeDef;

/** STMR interrupt sources */
typedef enum
{
  STMR_IT_UPDATE                     = ((u8)0x01)
}STMR_IT_TypeDef;


/*---Exported FUNCTIONS---*/

void STMR_Reset(void);
void STMR_TimeBaseInit(STMR_Prescaler_TypeDef STMR_Prescaler, u16 STMR_Period);
void STMR_Cmd(FunctionalState NewState);
void STMR_ITConfig(STMR_IT_TypeDef STMR_IT, FunctionalState NewState);
void STMR_UpdateDisableConfig(FunctionalState Newstate);
void STMR_UpdateRequestConfig(STMR_UpdateSource_TypeDef STMR_UpdateSource);
void STMR_SelectOnePulseMode(STMR_OPMode_TypeDef STMR_OPMode);
void STMR_PrescalerConfig(STMR_Prescaler_TypeDef Prescaler, STMR_PSCReloadMode_TypeDef STMR_PSCReloadMode);
void STMR_ARRPreloadConfig(FunctionalState Newstate);
void STMR_GenerateEvent(STMR_EventSource_TypeDef STMR_EventSource);
void STMR_SetCounter(u16 Counter);
void STMR_SetAutoreload(u16 Autoreload);
u16 STMR_GetCounter(void);
STMR_Prescaler_TypeDef STMR_GetPrescaler(void);
FlagStatus STMR_GetFlagStatus(STMR_FLAG_TypeDef STMR_FLAG);
void STMR_ClearFlag(STMR_FLAG_TypeDef STMR_FLAG);
ITStatus STMR_GetITStatus(STMR_IT_TypeDef STMR_IT);
void STMR_ClearITPendingBit(STMR_IT_TypeDef STMR_IT);

#endif


/*** (c) 2015  STMicroelectronics ****************** END OF FILE ***/

