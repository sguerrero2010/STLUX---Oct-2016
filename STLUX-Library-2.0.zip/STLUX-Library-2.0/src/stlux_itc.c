/**
  ******************************************************************************
  * @file stlux_itc.c
  * @brief    Main Interrupt Service Routines.
  * @author   STMicroelectronics
  * @version V2.0
  * @date 27/10/2015
  ******************************************************************************
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "stlux_itc.h"

/** @addtogroup ITC_Private_Functions
  * @{
  */

/**
* @brief Utility function used to read CC register.
* @par Parameters:
* None
* @retval u8 Content of CC register (in A register).
  */
u8 ITC_GetCPUCC(void)
{
#ifdef _COSMIC_
  _asm("push cc");
  _asm("pop a");
  return; /* Ignore compiler warning, the returned value is in A register */
#elif defined _RAISONANCE_ /* _RAISONANCE_ */
  return _getCC_();
#else /* _IAR_ */
  asm("push cc");
  asm("pop a");
  return 0;
#endif /* _COSMIC_*/
}


/**
  * @}
  */

/* Public functions ----------------------------------------------------------*/

/** @addtogroup ITC_Public_Functions
  * @{
  */

/**
* @brief Deinitializes the ITC registers to their default reset value.
* @par Parameters:
* None
* @retval
* None
  */
INLINE void ITC_Reset(void)
{
    ITC->SPR0 = ITC_SPRX_RESET_VALUE;
    ITC->SPR1 = ITC_SPRX_RESET_VALUE;
    ITC->SPR2 = ITC_SPRX_RESET_VALUE;
    ITC->SPR3 = ITC_SPRX_RESET_VALUE;
    ITC->SPR4 = ITC_SPRX_RESET_VALUE;
    ITC->SPR5 = ITC_SPRX_RESET_VALUE;
    ITC->SPR6 = ITC_SPRX_RESET_VALUE;
    ITC->SPR7 = ITC_SPRX_RESET_VALUE;
}

/**
* @brief Get the software interrupt priority bits (I1, I0) value from CPU CC register.
* @par Parameters:
* None
* @retval u8 The software interrupt priority bits value.
  */
INLINE u8 ITC_GetSoftIntStatus(void)
{
    return (u8)(ITC_GetCPUCC() & CPU_CC_I1I0);
}

/**
* @brief Get the software priority of the specified interrupt source.
* @param[in] IrqNum The IRQ number to access.
* @retval ITC_PriorityLevel_TypeDef The software priority of the interrupt source.
  */
INLINE ITC_PriorityLevel_TypeDef ITC_GetSoftwarePriority(ITC_Irq_TypeDef IrqNum)
{

    u8 Value = 0;
    u8 Mask;

    /* Define the mask corresponding to the bits position in the SPR register */
    Mask = (u8)(0x03U << (((u8)IrqNum % 4U) * 2U));

    switch (IrqNum)
    {
    case ITC_IRQ_NMI: /* NMI software priority can be read but has no meaning */
    case ITC_IRQ_AWU:
    case ITC_IRQ_CLK:
    case ITC_IRQ_PORT0:
        Value = (u8)(ITC->SPR0 & Mask); /* Read software priority */
        break;
    case ITC_IRQ_PORT1:
    case ITC_IRQ_PORT2:
    case ITC_IRQ_SMED0:
    case ITC_IRQ_SMED1:
        Value = (u8)(ITC->SPR1 & Mask); /* Read software priority */
        break;

#if defined(_STNRG388A_) || defined(_STNRG328A_) || defined(_STNRG288A_)        
    case ITC_IRQ_INPP3:
        Value = (u8)(ITC->SPR2 & Mask); /* Read software priority */
        break;
#endif //STNRG
        
    case ITC_IRQ_SMED2:
        Value = (u8)(ITC->SPR3 & Mask); /* Read software priority */
        break;
    case ITC_IRQ_SMED3:
    case ITC_IRQ_UART_TX:
    case ITC_IRQ_UART_RX:
    case ITC_IRQ_I2C:
        Value = (u8)(ITC->SPR4 & Mask); /* Read software priority */
        break;
    case ITC_IRQ_ADC:
    case ITC_IRQ_STMR:
        Value = (u8)(ITC->SPR5 & Mask); /* Read software priority */
        break;
    case ITC_IRQ_FLASH:
    case ITC_IRQ_DALI:
    case ITC_IRQ_SMED4:
    case ITC_IRQ_SMED5:		
        Value = (u8)(ITC->SPR6 & Mask); /* Read software priority */
        break;
    default:
        break;
    }

    Value >>= (u8)(((u8)IrqNum % 4u) * 2u);

    return((ITC_PriorityLevel_TypeDef)Value);

}

/**
* @brief Set the software priority of the specified interrupt source.
* @param[in] IrqNum The interrupt source to access.
* @param[in] PriorityValue The software priority value to set.
* @retval ITC_PriorityLevel_TypeDef The software priority of the interrupt source.
* @par Required preconditions:
* - The modification of the software priority is only possible when the interrupts are disabled.
* - The normal behavior is to disable the interrupts before calling this function, and re-enable it after.
* - The priority level 0 cannot be set (see product specification for more details).
*/
INLINE void ITC_SetSoftwarePriority(ITC_Irq_TypeDef IrqNum, ITC_PriorityLevel_TypeDef PriorityValue)
{

    u8 Mask;
    u8 NewPriority;

    /* Define the mask corresponding to the bits position in the SPR register */
    /* The mask is reversed in order to clear the 2 bits after more easily */
    Mask = (u8)(~(u8)(0x03U << (((u8)IrqNum % 4U) * 2U)));

    /* Define the new priority to write */
    NewPriority = (u8)((u8)(PriorityValue) << (((u8)IrqNum % 4U) * 2U));

    switch (IrqNum)
    {
    case ITC_IRQ_NMI: /* NMI software priority can be read but has no meaning */
    case ITC_IRQ_AWU:
    case ITC_IRQ_CLK:
    case ITC_IRQ_PORT0:
        ITC->SPR0 &= Mask;
        ITC->SPR0 |= NewPriority;
        break;
    case ITC_IRQ_PORT2:
    case ITC_IRQ_SMED0:
    case ITC_IRQ_SMED1:
        ITC->SPR1 &= Mask;
        ITC->SPR1 |= NewPriority;
        break;
#if defined(_STNRG388A_) || defined(_STNRG328A_) || defined(_STNRG288A_)                
    case ITC_IRQ_INPP3:
        ITC->SPR2 &= Mask;
        ITC->SPR2 |= NewPriority;
        break;
#endif //STNRG
    case ITC_IRQ_SMED2:
        ITC->SPR3 &= Mask;
        ITC->SPR3 |= NewPriority;
        break;
    case ITC_IRQ_SMED3:
    case ITC_IRQ_UART_TX:
    case ITC_IRQ_UART_RX:
    case ITC_IRQ_I2C:
        ITC->SPR4 &= Mask;
        ITC->SPR4 |= NewPriority;
        break;
    case ITC_IRQ_ADC:
    case ITC_IRQ_STMR:
        ITC->SPR5 &= Mask;
        ITC->SPR5 |= NewPriority;
        break;
    case ITC_IRQ_FLASH:
    case ITC_IRQ_DALI:
    case ITC_IRQ_SMED4:
    case ITC_IRQ_SMED5:		
        ITC->SPR6 &= Mask;
        ITC->SPR6 |= NewPriority;
        break;
    default:
        break;

    }

}

/**
  * @}
  */

/******************* (C) COPYRIGHT 2015 STMicroelectronics *****END OF FILE****/
