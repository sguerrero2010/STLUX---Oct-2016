/**
  ******************************************************************************
  * @file stlux_stmr.c
  * @brief This file contains System Timer functions of STLUX / STNRG
  * @author STMicroelectronics
  * @version V2.0
  * @date 27/10/2015
  ******************************************************************************
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  ******************************************************************************
  */

#include "stlux_stmr.h"

/**
  * @brief Deinitializes the STMR peripheral registers to their default reset values.
  * @param[in] :
  * None
  * @retval None
  */
INLINE void STMR_Reset(void)
{
    STMR->CR1 = STMR_CR1_RESET_VALUE;
    STMR->IER = STMR_IER_RESET_VALUE;
	STMR->SR1 = STMR_SR1_RESET_VALUE;
	STMR->EGR = STMR_EGR_RESET_VALUE;
    STMR->CNTH = STMR_CNTH_RESET_VALUE;
	STMR->CNTL = STMR_CNTL_RESET_VALUE;
    STMR->PSCL = STMR_PSCL_RESET_VALUE;
    STMR->ARRL = STMR_ARRL_RESET_VALUE;
    STMR->ARRH = STMR_ARRH_RESET_VALUE;	
}

/**
  * @brief Initializes the STMR Time Base Unit according to the specified parameters.
  * @param[in]  STMR_Prescaler specifies the Prescaler from STMR_Prescaler_TypeDef.
  * @param[in]  STMR_Period specifies the Period value.
  * @retval None
  */
INLINE void STMR_TimeBaseInit(STMR_Prescaler_TypeDef STMR_Prescaler, u16 STMR_Period)
{
    /* Set the Prescaler value */
    STMR->PSCL = (u8)(STMR_Prescaler);
    /* Set the Autoreload value */
    STMR->ARRH = (u8)(STMR_Period >> 8);
	STMR->ARRL = (u8)(STMR_Period);
}

/**
  * @brief Enables or disables the STMR peripheral.
  * @param[in] NewState new state of the STMR peripheral. This parameter can
  * be ENABLE or DISABLE.
  * @retval None
  */
INLINE void STMR_Cmd(FunctionalState NewState)
{
    /* set or Reset the CEN Bit */
    if (NewState != DISABLE)
    {
        STMR->CR1 |= STMR_CR1_CEN;
    }
    else
    {
        STMR->CR1 &= (u8)(~STMR_CR1_CEN);
    }
}

/**
  * @brief Enables or disables the specified STMR interrupts.
  * @param[in] NewState new state of the STMR peripheral.
  * This parameter can be: ENABLE or DISABLE.
  * @param[in] STMR_IT specifies the STMR interrupts sources to be enabled or disabled.
  * This parameter can be any combination of the following values:
  * - STMR_IT_UPDATE: STMR update Interrupt source
  * @param[in] NewState new state of the STMR peripheral.
  * @retval None
  */
INLINE void STMR_ITConfig(STMR_IT_TypeDef STMR_IT, FunctionalState NewState)
{
    if (NewState != DISABLE)
    {
        /* Enable the Interrupt sources */
        STMR->IER |= (u8)STMR_IT;
    }
    else
    {
        /* Disable the Interrupt sources */
        STMR->IER &= (u8)(~STMR_IT);
    }
}

/**
  * @brief Enables or Disables the STMR Update event.
  * @param[in] NewState new state of the STMR peripheral Preload register. This parameter can
  * be ENABLE or DISABLE.
  * @retval None
  */
INLINE void STMR_UpdateDisableConfig(FunctionalState NewState)
{

    /* Set or Reset the UDIS Bit */
    if (NewState != DISABLE)
    {
        STMR->CR1 |= STMR_CR1_UDIS;
    }
    else
    {
        STMR->CR1 &= (u8)(~STMR_CR1_UDIS);
    }
}

/**
  * @brief Selects the STMR Update Request Interrupt source.
  * @param[in] STMR_UpdateSource specifies the Update source.
  * This parameter can be one of the following values
  *                       - STMR_UPDATESOURCE_REGULAR
  *                       - STMR_UPDATESOURCE_GLOBAL
  * @retval None
  */
INLINE void STMR_UpdateRequestConfig(STMR_UpdateSource_TypeDef STMR_UpdateSource)
{

    /* Set or Reset the URS Bit */
    if (STMR_UpdateSource != STMR_UPDATESOURCE_GLOBAL)
    {
        STMR->CR1 |= STMR_CR1_URS;
    }
    else
    {
        STMR->CR1 &= (u8)(~STMR_CR1_URS);
    }
}

/**
  * @brief Selects the STMR�s One Pulse Mode.
  * @param[in] STMR_OPMode specifies the OPM Mode to be used.
  * This parameter can be one of the following values
  *                    - STMR_OPMODE_SINGLE
  *                    - STMR_OPMODE_REPETITIVE
  * @retval None
  */
INLINE void STMR_SelectOnePulseMode(STMR_OPMode_TypeDef STMR_OPMode)
{

    /* Set or Reset the OPM Bit */
    if (STMR_OPMode != STMR_OPMODE_REPETITIVE)
    {
        STMR->CR1 |= STMR_CR1_OPM;
    }
    else
    {
        STMR->CR1 &= (u8)(~STMR_CR1_OPM);
    }

}

/**
  * @brief Configures the STMR Prescaler.
  * @param[in] Prescaler specifies the Prescaler Register value
  * This parameter can be one of the following values
  *                       -  STMR_PRESCALER_1
  *                       -  STMR_PRESCALER_2
  *                       -  STMR_PRESCALER_4
  *                       -  STMR_PRESCALER_8
  *                       -  STMR_PRESCALER_16
  *                       -  STMR_PRESCALER_32
  *                       -  STMR_PRESCALER_64
  *                       -  STMR_PRESCALER_128
  * @param[in] STMR_PSCReloadMode specifies the STMR Prescaler Reload mode.
  * This parameter can be one of the following values
  *                       - STMR_PSCRELOADMODE_IMMEDIATE: The Prescaler is loaded
  *                         immediatly.
  *                       - STMR_PSCRELOADMODE_UPDATE: The Prescaler is loaded at
  *                         the update event.
  * @retval None
  */
INLINE void STMR_PrescalerConfig(STMR_Prescaler_TypeDef Prescaler, STMR_PSCReloadMode_TypeDef STMR_PSCReloadMode)
{

    /* Set the Prescaler value */
    STMR->PSCL = (u8)Prescaler;

    /* Set or reset the UG Bit */
    STMR->EGR = (u8)STMR_PSCReloadMode;
}

/**
  * @brief Enables or disables STMR peripheral Preload register on ARR.
  * @param[in] NewState new state of the STMR peripheral Preload register.
  * This parameter can be ENABLE or DISABLE.
  * @retval None
  */
INLINE void STMR_ARRPreloadConfig(FunctionalState NewState)
{

    /* Set or Reset the ARPE Bit */
    if (NewState != DISABLE)
    {
        STMR->CR1 |= STMR_CR1_ARPE;
    }
    else
    {
        STMR->CR1 &= (u8)(~STMR_CR1_ARPE);
    }
}

/**
  * @brief Configures the STMR event to be generated by software.
  * @param[in] STMR_EventSource specifies the event source.
  * This parameter can be one of the following values:
  *                       - STMR_EVENTSOURCE_UPDATE: STMR update Event source
  * @retval None
  */
INLINE void STMR_GenerateEvent(STMR_EventSource_TypeDef STMR_EventSource)
{

    /* Set the event sources */
    STMR->EGR = (u8)(STMR_EventSource);
}


/**
  * @brief Sets the STMR Counter Register value.
  * @param[in] Counter specifies the Counter register new value.
  * This parameter is between 0x0000 and 0xFFFF.
  * @retval None
  */
INLINE void STMR_SetCounter(u16 Counter)
{
    /* Set the Counter Register value */
	STMR->CNTH = (u8)(Counter >> 8);
    STMR->CNTL = (u8)(Counter);	
	
}

/**
  * @brief Sets the STMR Autoreload Register value.
  * @param[in] Autoreload specifies the Autoreload register new value.
  * This parameter is between 0x00 and 0xFF.
  * @retval None
  */
INLINE void STMR_SetAutoreload(u16 Autoreload)
{
    /* Set the Autoreload Register value */
	STMR->ARRH = (u8)(Autoreload >> 8);
    STMR->ARRL = (u8)(Autoreload);	
	
}

/**
  * @brief Gets the STMR Counter value.
  * @param[in] :
  * None
  * @retval Counter Register value.
  */
INLINE u16 STMR_GetCounter(void)
{
    /* Get the Counter Register value */
    u16 tmpcnt = 0;
	u8 tmpcntl = 0, tmpcnth = 0;
	
    tmpcnth = STMR->CNTH;
    tmpcntl = STMR->CNTL;

    tmpcnt = (u16)(tmpcntl);
    tmpcnt |= (u16)((u16)tmpcnth << 8);
    
    return (u16)tmpcnt;
}

/**
  * @brief Gets the STMR Prescaler value.
  * @param[in] :
  * None
  * @retval Prescaler Register configuration value.
  */
INLINE STMR_Prescaler_TypeDef STMR_GetPrescaler(void)
{
    /* Get the Prescaler Register value */
    return (STMR_Prescaler_TypeDef)(STMR->PSCL);
}

/**
  * @brief Checks whether the specified STMR flag is set or not.
  * @param[in] STMR_FLAG specifies the flag to check.
  * This parameter can be one of the following values:
  *                       - STMR_FLAG_UPDATE: STMR update Flag
  * @retval FlagStatus The new state of STMR_FLAG (SET or RESET).
  */
INLINE FlagStatus STMR_GetFlagStatus(STMR_FLAG_TypeDef STMR_FLAG)
{

    if ((STMR->SR1 & STMR_FLAG) != RESET )
    {
        return (FlagStatus)(SET);
    }
    else
    {
        return (FlagStatus)(RESET);
    }
}

/**
  * @brief Clears the STMR�s pending flags.
  * @param[in] STMR_FLAG specifies the flag to clear.
  * This parameter can be one of the following values:
  *                       - STMR_FLAG_UPDATE: STMR update Flag
  * @retval None.
  */
INLINE void STMR_ClearFlag(STMR_FLAG_TypeDef STMR_FLAG)
{

    /* Clear the flags (rc_w0) clear this bit by writing 0. Writing �1� has no effect*/
    STMR->SR1 = (u8)(~STMR_FLAG);

}
/**
  * @brief Checks whether the STMR interrupt has occurred or not.
  * @param[in] STMR_IT specifies the STMR interrupt source to check.
  * This parameter can be one of the following values:
  *                       - STMR_IT_UPDATE: STMR update Interrupt source
  * @retval ITStatus The new state of the STMR_IT (SET or RESET).
  */
INLINE ITStatus STMR_GetITStatus(STMR_IT_TypeDef STMR_IT)
{

    if (((STMR->SR1 & STMR_IT) != RESET ) && ((STMR->IER & STMR_IT) != RESET ))
    {
        return (ITStatus)(SET);
    }
    else
    {
        return (ITStatus)(RESET);
    }
}

/**
  * @brief Clears the STMR's interrupt pending bits.
  * @param[in] STMR_IT specifies the pending bit to clear.
  * This parameter can be one of the following values:
  *                       - STMR_IT_UPDATE: STMR update Interrupt source
  * @retval None.
  */
INLINE void STMR_ClearITPendingBit(STMR_IT_TypeDef STMR_IT)
{

    /* Clear the IT pending Bit */
    STMR->SR1 = (u8)(~STMR_IT);
}



/*** (c) 2015  STMicroelectronics ****************** END OF FILE ***/



