/**
  ******************************************************************************
  * @file stlux_smed.c
  * @brief This file contains SMED functions of STLUX / STNRG
  * @author STMicroelectronics
  * @version V2.0
  * @date 25/10/2015
  ******************************************************************************
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  ******************************************************************************
  */

#include "stlux_smed.h"

INLINE void SMED_Start(SMED_TypeDef* SMEDx){

SMEDx->CTR |= (SMED_CTR_START_CNT | SMED_CTR_FSM_ENA);

}

/**************************************************/

INLINE void SMED_Stop(SMED_TypeDef* SMEDx){

SMEDx->CTR = 0;

}


/*************************************************/
INLINE u8 SMED_SetTime(SMED_TypeDef* SMEDx, SMED_TIMES_Typedef TimeRegister, u16 value){
    switch(TimeRegister)
        {
            case SMED_T0:
                       if (SMEDx->CTR_TMR & SMED_CTR_TMR_TIME_T0_VAL){
                          return 0x00;
                       }
                       break;
            case SMED_T1:
                       if (SMEDx->CTR_TMR & SMED_CTR_TMR_TIME_T1_VAL){
                          return 0x00;
                       }
                       break;
            case SMED_T2:
                       if (SMEDx->CTR_TMR & SMED_CTR_TMR_TIME_T2_VAL){
                          return 0x00;
                       }
                       break;
            case SMED_T3:
                       if (SMEDx->CTR_TMR & SMED_CTR_TMR_TIME_T3_VAL){
                          return 0x00;
                       }
                       break;
        }

        *(&(SMEDx->CTR) + TimeRegister) = (u8)value;
        *(&(SMEDx->CTR) + TimeRegister+1) = (u8)(value>>8);
        return 0x01;
}

/*************************************************/
INLINE u8 SMED_ValidateTimeValues(SMED_TypeDef* SMEDx, SMED_VALIDATE_TypeDef TimeVal){
  if (SMEDx->CTR_TMR & TimeVal){
      return 0x00;
  }
  SMEDx->CTR_TMR |= TimeVal;
  return 0x01;
}


/*** (c) 2015  STMicroelectronics ****************** END OF FILE ***/


