/**
  ******************************************************************************
  * @file    stlux_awu.c
  * @brief   This file contains all the functions for the AWU peripheral.  
  * @author  STMicroelectronics 
  * @version V2.0
  * @date 27/10/2015
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "stlux_awu.h"

/** 
  * @{
  */
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/* Public functions ----------------------------------------------------------*/

/**
  * @addtogroup AWU_Public_Functions
  * @{
  */

/**
  * @brief  Deinitializes the AWU peripheral registers to their default reset
  * values.
  * @param  None
  * @retval None
  */
INLINE void AWU_Reset(void)
{
    AWU->CSR = AWU_CSR_RESET_VALUE;
    AWU->APR = AWU_APR_RESET_VALUE;
    AWU->TBR = AWU_TBR_RESET_VALUE;
}

/**
  * @brief  Initializes the AWU peripheral according to the specified parameters.
  * @param   AWU_Prescaler : Number of steps to be couted between two AWU Interrupts.
  * AWU_Prescaler must be a value between [0-62].
  * @param   AWU_TimeBase : Value of the single step.
  * can be one of the values of @ref AWU_Timebase_TypeDef.
  * the Total time between two interrupts will be TIME=[2^(TBR-1) * APRDIV / f_AWU]ms;
  * @retval None
  * @par Required preconditions:
  * The LS RC calibration must be performed before calling this function.
  */
INLINE void AWU_Init(u8 AWU_Prescaler, AWU_Timebase_TypeDef AWU_TimeBase)
{
    /* Enable the AWU peripheral */
    //AWU->CSR |= AWU_CSR_AWUEN;

    /* Set the TimeBase */
    AWU->TBR &= (u8)(~AWU_TBR_AWUTB);
    AWU->TBR |= (u8)AWU_TimeBase;

    /* Set the APR divider */
    AWU->APR = AWU_Prescaler;

}

/**
  * @brief  Enable or disable the AWU peripheral.
  * @param   NewState Indicates the new state of the AWU peripheral.
  * @retval None
  * @par Required preconditions:
  * Initialisation of AWU and LS RC calibration must be done before.
  */
INLINE void AWU_Enable(FunctionalState NewState)
{
    if (NewState != DISABLE)
    {
        /* Enable the AWU peripheral */
        AWU->CSR |= AWU_CSR_AWUEN;
    }
    else
    {
        /* Disable the AWU peripheral */
        AWU->CSR &= (u8)(~AWU_CSR_AWUEN);
    }
}

/**
  * @brief  Configures AWU in Idle mode to reduce power consumption.
  * @param  None
  * @retval None
  */
INLINE void AWU_IdleModeEnable(void)
{
    /* Disable AWU peripheral */
    AWU->CSR &= (u8)(~AWU_CSR_AWUEN);

    /* No AWU timebase */
    AWU->TBR = (u8)(~AWU_TBR_AWUTB);
}

/**
  * @brief  Returns status of the AWU peripheral flag.
  * @param  None
  * @retval FlagStatus : Status of the AWU flag.
  * This parameter can be any of the @ref FlagStatus enumeration.
  */
INLINE FlagStatus AWU_GetStatus(void)
{
    return((FlagStatus)(((u8)(AWU->CSR & AWU_CSR_AWUF) == (u8)0x00) ? RESET : SET));
}


/**
  * @}
  */
  
/**
  * @}
  */
  
/******************* (C) COPYRIGHT 2015 STMicroelectronics *****END OF FILE****/
