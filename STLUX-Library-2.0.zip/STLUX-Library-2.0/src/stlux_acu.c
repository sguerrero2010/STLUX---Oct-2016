/**
  ******************************************************************************
  * @file stlux_acu.c
  * @brief This file contains all the functions/macros for the ADC peripheral.
  * @author STMicroelectronics
  * @version V2.0
  * @date 27/10/2015
  ******************************************************************************
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "stlux_acu.h"
#include "stlux.h"




/* Private typedef -----------------------------------------------------------*/

/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/* Public functions ----------------------------------------------------------*/

/**
  * @addtogroup ACU_Public_Functions
  * @{
  */

/**
  * @brief Deinitializes the ACU peripheral registers to their default reset
  * values.
  * @par Parameters:
  * None
  * @retval None
  */
INLINE void ACU_Reset(void)
{
    MSC->DACCTR    =  MSC_DACCTR_RESET_VALUE;
    MSC->DACIN0    =  MSC_DACIN0_RESET_VALUE;
    MSC->DACIN1    =  MSC_DACIN1_RESET_VALUE;
    MSC->DACIN2    =  MSC_DACIN2_RESET_VALUE;
    MSC->DACIN3    =  MSC_DACIN3_RESET_VALUE;
    MSC->INPP3     =  MSC_INPP3_RESET_VALUE;

}


/*-----------------------------------------------------------------------------------------*/
#if defined(_STLUX385A_) || defined(_STLUX383A_) || defined(_STLUX325A_)

INLINE void ACU_Init(void)
{
#if defined(_STLUX385A_) || defined(_STLUX383A_) || defined(_STLUX325A_)
    /* turn on the whole ACU unit */
    MSC->DACCTR |= MSC_DACCTR_DACBIAS_EN;
#endif

    /* set-up first compare values*/    
    MSC->DACIN0 = DACIN_0mV;
    MSC->DACIN1 = DACIN_0mV;
    MSC->DACIN2 = DACIN_0mV;
    MSC->DACIN3 = DACIN_0mV;

    /* wait 400ns -> each nop is 1/16MHz, could be changed for different Fcpu*/
    nop();
    nop();
    nop();
    nop();
    nop();
    nop();
    nop();
}
#endif

/*-----------------------------------------------------------------------------------------*/
INLINE void ACU_Enable(ACU_Selection_TypeDef ACUx, ACU_CP_SEL_Typedef CP_SEL)
{
#if defined(_STLUX385A_) || defined(_STLUX383A_) || defined(_STLUX325A_)
    /* enable desired comparators */
    if (ACUx != CMP_3){
        MSC->DACCTR |= ACUx;
    }
    else{
        if (CP_SEL != ACU_CP3_SEL_EXT){
            MSC->DACCTR |= (ACUx | MSC_DACCTR_DAC3_EN);        
        }
        else{
            MSC->DACIN3 =  MSC_DACIN3_RESET_VALUE;
            MSC->DACCTR |= (MSC_DACCTR_DAC3_EN | CP_SEL);                  
        }
    }
#else //FOR ALL THE NEW DEVICES (STNRG FAMILY + STLUX285A)
    if (CP_SEL==ACU_CPx_SEL_INT){ //INTERNAL Ref
        MSC->DACCTR |= ACUx;
    }
    else{ //EXTERNAL Ref
        MSC->DACCTR &= ~ACUx;
        MSC->DACCTR |= CP_SEL;
    }
#endif 
}

/*-----------------------------------------------------------------------------------------*/
INLINE void ACU_Disable(ACU_Selection_TypeDef ACUx)
{
#if defined(_STLUX385A_) || defined(_STLUX383A_) || defined(_STLUX325A_)
    /* enable desired comparators */
    if (ACUx != CMP_3){
        MSC->DACCTR &= ~ACUx;
    }
    else{
        MSC->DACCTR &= ~(ACUx | MSC_DACCTR_DAC3_EN | ACU_CP3_SEL_EXT);        
    }
#else //FOR ALL THE NEW DEVICES (STNRG FAMILY + STLUX285A)
    MSC->DACCTR &= ~((ACUx  << 4)| ACUx);
#endif
}

/*-----------------------------------------------------------------------------------------*/
INLINE bool ACU_Read(ACU_Selection_TypeDef ACUx)
{
    return ((bool)(MSC->INPP3 & ACUx));
}

/*-----------------------------------------------------------------------------------------*/
INLINE void ACU_SetCompareLevel(ACU_Selection_TypeDef ACUx,ACU_DACIN_VALUES_TypeDef DACIN)
{
    switch(ACUx)
        {
            case CMP_0:
                       MSC->DACIN0 = DACIN;
                       break;
            case CMP_1:
                       MSC->DACIN1 = DACIN;
                       break;
            case CMP_2:
                       MSC->DACIN2 = DACIN;
                       break;
            case CMP_3:
                       MSC->DACIN3 = DACIN;
                       break;
        }
}

/*---------------------------------------------------------------------------------------*/
#if !defined(_STLUX385A_) && !defined(_STLUX383A_) && !defined(_STLUX325A_)
INLINE void ACU_SetHysteresisLevel(ACU_Selection_TypeDef ACUx,ACU_HYS_VALUES_TypeDef HYSIN)
{
    switch(ACUx)
        {
            case CMP_0:
                       MSC->IDXADD = MSC_DAC0HYS;
                       if (HYSIN > HYSTDN_V_CODE0) 
                       { 
                            MSC->IDXDAT &= (0x8F);
                            MSC->IDXDAT |= HYSIN;
                       }
                        else
                       {
                            MSC->IDXDAT &= (0xF8);
                            MSC->IDXDAT |= HYSIN;
                       }
                       break;
            case CMP_1:
                       MSC->IDXADD = MSC_DAC1HYS;
                      if (HYSIN > HYSTDN_V_CODE0) 
                       { 
                            MSC->IDXDAT &= (0x8F);
                            MSC->IDXDAT |= HYSIN;
                       }
                        else
                       {
                            MSC->IDXDAT &= (0xF8);
                            MSC->IDXDAT |= HYSIN;
                       }
                       break;
            case CMP_2:
                       MSC->IDXADD = MSC_DAC2HYS;
                      if (HYSIN > HYSTDN_V_CODE0) 
                       { 
                            MSC->IDXDAT &= (0x8F);
                            MSC->IDXDAT |= HYSIN;
                       }
                        else
                       {
                            MSC->IDXDAT &= (0xF8);
                            MSC->IDXDAT |= HYSIN;
                       }
                       break;
            case CMP_3:
                       MSC->IDXADD = MSC_DAC3HYS;
                      if (HYSIN > HYSTDN_V_CODE0) 
                       { 
                            MSC->IDXDAT &= (0x8F);
                            MSC->IDXDAT |= HYSIN;
                       }
                        else
                       {
                            MSC->IDXDAT &= (0xF8);
                            MSC->IDXDAT |= HYSIN;
                       }
                       break;
        }

}
#endif

/**
  * @}
  */

/******************* (C) COPYRIGHT 2015 STMicroelectronics *****END OF FILE****/
