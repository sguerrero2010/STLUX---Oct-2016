/**
  ******************************************************************************
  * @file stlux_atm.c
  * @brief This file contains all the functions/macros for the Basic Timer.
  * @author STMicroelectronics
  * @version V2.0
  * @date 27/10/2015
  ******************************************************************************
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/

#include "stlux_btm.h"
#if defined(_STNRG388A_) || defined(_STNRG328A_) || defined(_STNRG288A_)
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/

/* Private Constants ---------------------------------------------------------*/

/**
  * @addtogroup CLK_Private_Constants
  * @{
  */

/**
  * @}
  */

/* Public functions ----------------------------------------------------------*/

INLINE void BTM_Reset(void)
{
    MSC->CFGP10 = MSC_CFGP10_RESET_VALUE;
    MSC->STSP1  = MSC_STSP1_RESET_VALUE;
    
    MSC->IDXADD = MSC_FTM0CKSEL;
    MSC->IDXDAT = MSC_FTM0CKSEL_RESET_VALUE;

    MSC->IDXADD = MSC_FTM0CKDIV;
    MSC->IDXDAT = MSC_FTM0CKDIV_RESET_VALUE;

    MSC->IDXADD = MSC_FTM0CONF;
    MSC->IDXDAT = MSC_FTM0CONF_RESET_VALUE;

    MSC->IDXADD = MSC_FTM1CKDIV;
    MSC->IDXDAT = MSC_FTM1CKDIV_RESET_VALUE;

    MSC->IDXADD = MSC_FTM1CONF;
    MSC->IDXDAT = MSC_FTM1CONF_RESET_VALUE;
}

INLINE void BTM_Config(BTM_Selection_TypeDef BTMx, CLK_BTM_Source_TypeDef CLK_SRC,u8 CLK_DIV, u8 CLK_CNT, BTM_ITPolarity_TypeDef IT_LEV, BTM_ITTrigger_TypeDef IT_SEL, BTM_ITType_TypeDef IT_TYPE)
{
    // ENABLE PLL to ensure Basic Timer Unit is ON
    CLK->PLLR |= CLK_PLLR_PLLON;
    // Wait for the PLL to be locked
    while((CLK->PLLR & CLK_PLLR_LOCKP) == 0); 

    if (BTMx&BTM_0 != 0){
        // Select Clock Source
        MSC->IDXADD  = MSC_FTM0CKSEL;
        MSC->IDXDAT &= ~0x07;
        MSC->IDXDAT |= CLK_SRC;
        // Select Prescaler Value
        MSC->IDXADD  = MSC_FTM0CKDIV;
        MSC->IDXDAT  = CLK_DIV;
        // Select Clock Configuration
        MSC->IDXADD  = MSC_FTM0CONF;
        MSC->IDXDAT  = CLK_CNT&0x1F;
    
        //Set the capture mode used for the interrupt generation
        if (IT_SEL != BTM_IT_SEL_LEVEL){
            MSC->CFGP10 &= BTM_IT_SEL_LEVWAKEUP;    //Set Interrupt Trigger on high/low asynchronous level with wakeup capability
            if (IT_SEL != BTM_IT_SEL_LEVWAKEUP){
                MSC->CFGP10 |= BTM_IT_SEL_EDGE;     //Set Interrupt Trigger on rising/falling edge
            }
        }
        else{
            MSC->CFGP10 |= BTM_IT_SEL_LEVEL;        //Set Interrupt Trigger on high/low level 
        }
    
        //Set the type of interrupt between normal maskable and non maskable interrupt
        if (IT_TYPE != BTM_IT_TYPE_IRQ){
            if (IT_TYPE == BTM_IT_TYPE_NMI){
                MSC->CFGP10 |= IT_TYPE; //Interrupt Type 1=NMI;    
            }
            GPIO1->CR2  &= (u8)(~0x01); //Set bit 0 high -> Clear Interrupt Mask Functionality for Polling  
        }
        else{
            MSC->CFGP10 &= IT_TYPE; //Interrupt Type 0=IRQ;
            GPIO1->CR2  |= 0x01; //Set bit 0 high -> Add Interrupt Mask Functionality      
        }
    }

    if (BTMx&BTM_1 != 0){
        // Select Clock Source
        MSC->IDXADD  = MSC_FTM0CKSEL;
        MSC->IDXDAT &= ~0x70;
        MSC->IDXDAT |= (CLK_SRC<<4);
        // Select Prescaler Value
        MSC->IDXADD  = MSC_FTM1CKDIV;
        MSC->IDXDAT  = CLK_DIV;
        // Select Clock Configuration
        MSC->IDXADD  = MSC_FTM1CONF;
        MSC->IDXDAT  = CLK_CNT&0x1F;

    //Set the capture mode used for the interrupt generation
        if (IT_SEL != BTM_IT_SEL_LEVEL){
            MSC->CFGP11 &= BTM_IT_SEL_LEVWAKEUP;    //Set Interrupt Trigger on high/low asynchronous level with wakeup capability
            if (IT_SEL != BTM_IT_SEL_LEVWAKEUP){
                MSC->CFGP11 |= BTM_IT_SEL_EDGE;     //Set Interrupt Trigger on rising/falling edge
            }
        }
        else{
            MSC->CFGP11 |= BTM_IT_SEL_LEVEL;        //Set Interrupt Trigger on high/low level 
        }
    
        //Set the type of interrupt between normal maskable and non maskable interrupt
        if (IT_TYPE != BTM_IT_TYPE_IRQ){
            if (IT_TYPE == BTM_IT_TYPE_NMI){
                MSC->CFGP11 |= IT_TYPE; //Interrupt Type 1=NMI;    
            }
            GPIO1->CR2  &= (u8)(~0x02); //Set bit 1 high -> Clear Interrupt Mask Functionality for Polling  
        }
        else{
            MSC->CFGP11 &= IT_TYPE; //Interrupt Type 0=IRQ;
            GPIO1->CR2  |= 0x02; //Set bit 1 high -> Add Interrupt Mask Functionality      
        }
    }
}

INLINE void BTM_ITConfig(BTM_Selection_TypeDef BTMx, FunctionalState NewState)
{
    if (BTMx&BTM_0 != 0){
        if (NewState != DISABLE)
            MSC->CFGP10 |= 0x08; //Interrupt Enable          
        else
            MSC->CFGP10 &= (u8)(~0x08); //External Interrupt Disabled
    }
    if (BTMx&BTM_1 != 0){
        if (NewState != DISABLE)
            MSC->CFGP11 |= 0x08; //Interrupt Enable          
        else
            MSC->CFGP11 &= (u8)(~0x08); //External Interrupt Disabled
    }    	
}

INLINE void BTM_ITClear(BTM_Selection_TypeDef BTMx)
{
		MSC->STSP1 |= BTMx; ////BSCTIMx ISR Clear
}

INLINE void BTM_Cmd(BTM_Selection_TypeDef BTMx, FunctionalState NewState)
{
    MSC->IDXADD  = MSC_FTM0CKSEL;
    if (NewState != DISABLE)
        MSC->IDXDAT |= (1 << ((0x02 << BTMx)-1));    //Basic Timer Enable
    else
        MSC->IDXDAT &= ~(1 << ((0x02 << BTMx)-1));   //Basic Timer Enable

}
#endif
/******************* (C) COPYRIGHT 2015 STMicroelectronics *****END OF FILE****/