/**
  ******************************************************************************
  * @file stlux_atm.c
  * @brief This file contains all the functions/macros for the Auxiliaty Timer.
  * @author STMicroelectronics
  * @version V2.0
  * @date 27/10/2015
  ******************************************************************************
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/

#include "stlux_atm.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/

/* Private Constants ---------------------------------------------------------*/

/**
  * @addtogroup CLK_Private_Constants
  * @{
  */

/**
  * @}
  */

/* Public functions ----------------------------------------------------------*/

INLINE void ATM_Reset(void)
{
    CLK->CCOR = CLK_CCOR_RESET_VALUE;
    while (CLK->CCOR & CLK_CCOR_CCOEN)
    {}
    CLK->CCOR = CLK_CCOR_RESET_VALUE;
		CLK->CCODIVR = CLK_CCODIVR_RESET_VALUE;
}

INLINE void ATM_Config(CLK_Output_TypeDef CLK_CCO,u8 CLK_CCODIVR, ATM_ITPolarity_TypeDef IT_LEV, ATM_ITTrigger_TypeDef IT_SEL, ATM_ITType_TypeDef IT_TYPE)
{
    /* Clears of the CCO type bits part */
    CLK->CCOR &= (u8)(~CLK_CCOR_CCOSEL);

    /* Selects the source provided on cco_ck output */
    CLK->CCOR |= (u8)CLK_CCO;
	
    /* Set Division Factor (n) for CCO clock, CKCCO = CK / (n + 1) */
    CLK->CCODIVR = CLK_CCODIVR;

    /* Enable the clock output */
    //CLK->CCOR |= CLK_CCOR_CCOEN;
    
    //Set the polarity of the sensed signal (raising/falling edge or high/low level)
    if (IT_LEV != ATM_IT_LEV_HIGH) {
        MSC->CFGP15 &= IT_LEV; //Set Interrupt Sensitivity Level on low level or falling edge
    }
    else {
      MSC->CFGP15 |= IT_LEV; //Set Interrupt Sensitivity Level on high level or rising edge
    }
    
    //Set the capture mode used for the interrupt generation
    if (IT_SEL != ATM_IT_SEL_LEVEL){
        MSC->CFGP15 &= ATM_IT_SEL_LEVWAKEUP;    //Set Interrupt Trigger on high/low asynchronous level with wakeup capability
        if (IT_SEL != ATM_IT_SEL_LEVWAKEUP){
            MSC->CFGP15 |= ATM_IT_SEL_EDGE;     //Set Interrupt Trigger on rising/falling edge
        }
    }
    else{
        MSC->CFGP15 |= ATM_IT_SEL_LEVEL;        //Set Interrupt Trigger on high/low level 
    }
    
    //Set the type of interrupt between normal maskable and non maskable interrupt
    if (IT_TYPE != ATM_IT_TYPE_IRQ){
        if (IT_TYPE == ATM_IT_TYPE_NMI){
            MSC->CFGP15 |= IT_TYPE; //Interrupt Type 1=NMI;    
        }
        GPIO1->CR2  &= (u8)(~0x20); //Set bit 5 high -> Clear Interrupt Mask Functionality for Polling  
    }
    else{
        MSC->CFGP15 &= IT_TYPE; //Interrupt Type 0=IRQ;
        GPIO1->CR2  |= 0x20; //Set bit 5 high -> Add Interrupt Mask Functionality      
    }
}

INLINE void ATM_OutDigIn0(FunctionalState NewState)
{
    if (NewState != DISABLE)
    {
        /* Set CCOEN bit */
        CLK->CCOR |= CLK_CCOR_CCOEN;    //This enables CCO clock to be mapped on phy output DIGIN0.
    }
    else
    {
        /* Reset CCOEN bit */
        CLK->CCOR &= (u8)(~CLK_CCOR_CCOEN); //This disables CCO clock to be mapped on phy output DIGIN0.
    }
}

INLINE void ATM_ITConfig(FunctionalState NewState)
{
    if (NewState != DISABLE)
    {
          MSC->CFGP15 |= 0x08; //Interrupt Enable          
    }
    else
    {
          MSC->CFGP15 &= (u8)(~0x08); //External Interrupt Disabled
    }
    	
}

INLINE void ATM_ITClear(void)
{
		MSC->STSP1 |= 0x20; //ISR AUXTIM IT Clear
}

/******************* (C) COPYRIGHT 2015 STMicroelectronics *****END OF FILE****/