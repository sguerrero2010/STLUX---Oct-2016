/**
  ******************************************************************************
  * @file stlux_adc.c
  * @brief This file contains all the functions/macros for the ADC peripheral.
  * @author STMicroelectronics
  * @version V2.0
  * @date 27/10/2015
  ******************************************************************************
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "stlux_adc.h"
#include "stlux.h"




/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/* Public functions ----------------------------------------------------------*/

/**
  * @addtogroup ADC_Public_Functions
  * @{
  */

/**
  * @brief Deinitializes the ADC0 peripheral registers to their default reset
  * values.
  * @par Parameters:
  * None
  * @retval None
  */
  
INLINE void ADC_Reset(void)
{
    SetBit(ADC->CFG,ADC_CFG_SEQ_DATA_FIFO_FLUSH_bit);   /**< Flush the data and sequencer buffers */
    ADC->CFG    =  ADC_CFG_RESET_VALUE;
    ADC->SOC    =  ADC_SOC_RESET_VALUE;
    ADC->IER    =  ADC_IER_RESET_VALUE;
    ADC->SR     =  (~ADC_SR_RESET_VALUE & 0x03);
    ADC->DLYCNT =  ADC_DLYCNT_RESET_VALUE;
}


/*-----------------------------------------------------------------------------------------*/
INLINE void ADC_Init(ADC_ConvMode_TypeDef ADC_ConvMode_Init, ADC_DataFormat_TypeDef ADC_DataFormat_Init)
{
    ClrBit (ADC->CFG,ADC_CFG_PD_bit);                   /**< Enable the ADC_CFG.PD = 0 before to start the SOC*/
    SetBit(ADC->CFG,ADC_CFG_SEQ_DATA_FIFO_FLUSH_bit);   /**< Flush the data and sequencer buffers */
   
    ADC_ConvMode_Init |= ADC_DataFormat_Init;           /**< Setup output data format*/
    ADC->CFG  |= ADC_ConvMode_Init;                     /**< Setup Conversion Mode */
}


/*-----------------------------------------------------------------------------------------*/

INLINE void ADC_Interrupt(ADC_IntEndConvMode_TypeDef ADC_IntEndConvMode_Interrupt,
                   ADC_IntEndSeqMode_TypeDef ADC_IntEndSeqMode_Interrupt,
                   ADC_IntSeqFull_TypeDef ADC_IntSeqFull_Interrupt)
{
    ADC_IntEndConvMode_Interrupt |= ADC_IntEndSeqMode_Interrupt;
    ADC_IntEndConvMode_Interrupt |= ADC_IntSeqFull_Interrupt;
    ADC->IER = ADC_IntEndConvMode_Interrupt;
}


/*-----------------------------------------------------------------------------------------*/

INLINE void ADC_Sequencer(ADC_Channel_TypeDef ADC_Channel_Sequencer, ADC_Gain_TypeDef ADC_Gain_Sequencer)
{
    ADC_Channel_Sequencer |= ADC_Gain_Sequencer;
    ADC->SEQ = ADC_Channel_Sequencer;
}


/*-----------------------------------------------------------------------------------------*/
INLINE void ADC_Start(void)
{
    ADC->SOC = ADC_Start_EN;
}

/*-----------------------------------------------------------------------------------------*/
INLINE void ADC_Stop(void)
{
    ADC->CFG |= ADC_CFG_STOP;
}

/*-----------------------------------------------------------------------------------------*/
INLINE void ADC_PowerUp(void)
{
    ADC->CFG = 0;				// remove power down reset condition
    ADC->CFG = ADC_CFG_STOP;	// stop the sequencer
    nop();
    ADC->CFG = 0;				// remove power down reset condition
}

/*-----------------------------------------------------------------------------------------*/
INLINE void ADC_PowerDown(void)
{
    ADC->CFG = ADC_CFG_SEQ_DATA_FIFO_FLUSH;	// flush the sequencer
    ADC->SR = ADC_SR_EOS|ADC_SR_EOC;		// clear pending interrupts
    nop();	
    ADC->CFG = ADC_CFG_PD;		// powerdown the ADC
}

/*-----------------------------------------------------------------------------------------*/
void ADC_Abort(void)
{
u8 tmp;
		ADC->CFG |= ADC_CFG_STOP; 
    // wait 20 Fadc clock - max is 5uS@4MHz
    for(tmp=0; tmp<30; tmp++){
				nop();
		}
    ADC->SR = ADC_SR_EOS|ADC_SR_EOC;
    ADC->CFG |= ADC_CFG_SEQ_DATA_FIFO_FLUSH;
}

/*-----------------------------------------------------------------------------------------*/

INLINE void ADC_Delay(u8 ADC_Delay_Value)
{
      ADC->DLYCNT = ADC_Delay_Value;
}

/*-----------------------------------------------------------------------------------------*/


INLINE u16 ADC_Measure(ADC_Channel_TypeDef ADC_Channel_Measure, ADC_Gain_TypeDef ADC_Gain_Measure)
{
    DATAWORD data16;
    
    // initialize sequencer for conversion cycle
    ADC->SEQ = ((u8)ADC_Channel_Measure | (u8)ADC_Gain_Measure);
    
    // start ADC conversion
    ADC->SOC = ADC_Start_EN;
                         
    while((ADC->SR & ADC_StatusEOS_SET) == 0)
    {
    }

    data16.byte.lo = ADC->DATL_0;
    data16.byte.hi = ADC->DATH_0;

    return(data16.word);
}

/*-----------------------------------------------------------------------------------------*/
INLINE u8 ADC_GetStatus(void){
  return ADC->SR;
}

/*-----------------------------------------------------------------------------------------*/
INLINE void ADC_SetStatus(ADC_StatusEOS_TypeDef EOS, ADC_StatusEOC_TypeDef EOC){
  ADC->SR = (u8)EOS|(u8)EOC;		// Set status
}

/********************/





/**
  * @}
  */

/******************* (C) COPYRIGHT 2015 STMicroelectronics *****END OF FILE****/
