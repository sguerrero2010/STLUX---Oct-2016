/**
  ********************************************************************************
  * @file stlux_uart.c
  * @brief This file contains all the functions for the UART peripheral.
  * @author STMicroelectronics
  * @version V2.0
  * @date 27/10/2015
  ******************************************************************************
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "stlux_UART.h"
#include "stlux_clk.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/* Public functions ----------------------------------------------------------*/

/** @}
  * @addtogroup UART_Public_Functions
  * @{
  */

/**
  * @brief Deinitializes the UART peripheral.
  * @par Full description:
  * Set the UART peripheral registers to their default reset values.
  * @retval None
	*/
INLINE void UART_Reset(void)
{
    u8 dummy = 0;

    /*< Clear the Idle Line Detected bit in the status rerister by a read
       to the UART_SR register followed by a Read to the UART_DR register */
    dummy = UART->SR;
    dummy = UART->DR;

    UART->BRR2 = UART_BRR2_RESET_VALUE;  /*< Set UART_BRR2 to reset value 0x00 */
    UART->BRR1 = UART_BRR1_RESET_VALUE;  /*< Set UART_BRR1 to reset value 0x00 */

    UART->CR1 = UART_CR1_RESET_VALUE; /*< Set UART_CR1 to reset value 0x00  */
    UART->CR2 = UART_CR2_RESET_VALUE; /*< Set UART_CR2 to reset value 0x00  */
    UART->CR3 = UART_CR3_RESET_VALUE;  /*< Set UART_CR3 to reset value 0x00  */
}

/**
  * @brief Initializes the UART according to the specified parameters.
  * @param[in] BaudRate: The baudrate.
  * @param[in] WordLength : This parameter can be any of the @ref UART_WordLength_TypeDef enumeration.
  * @param[in] StopBits: This parameter can be any of the @ref UART_StopBits_TypeDef enumeration.
  * @param[in] Parity: This parameter can be any of the @ref UART_Parity_TypeDef enumeration.
  * @param[in] Mode: This parameter can be any of the @ref UART_Mode_TypeDef values
  * @retval
  * None
  */
INLINE void UART_Init(u32 BaudRate,
               UART_WordLength_TypeDef WordLength,
               UART_StopBits_TypeDef StopBits,
               UART_Parity_TypeDef Parity,
               UART_PIN_TypeDef PIN,
               UART_Mode_TypeDef Mode)
{
    u32 BaudRate_Mantissa = 0;


    UART->CR1 &= (u8)(~UART_CR1_M);  /**< Clear the word length bit */
    UART->CR1 |= (u8)WordLength; /**< Set the word length bit according to UART_WordLength value */

    UART->CR3 &= (u8)(~UART_CR3_STOP);  /**< Clear the STOP bits */
    UART->CR3 |= (u8)StopBits;  /**< Set the STOP bits number according to UART_StopBits value  */

    UART->CR1 &= (u8)(~(UART_CR1_PCEN | UART_CR1_PS  ));  /**< Clear the Parity Control bit */
    UART->CR1 |= (u8)Parity;  /**< Set the Parity Control bit to UART_Parity value */

    UART->BRR1 &= (u8)(~UART_BRR1_DIVM);  /**< Clear the LSB mantissa of UARTDIV  */
    UART->BRR2 &= (u8)(~UART_BRR2_DIVM);  /**< Clear the MSB mantissa of UARTDIV  */
    UART->BRR2 &= (u8)(~UART_BRR2_DIVF);  /**< Clear the Fraction bits of UARTDIV */

    /**< Set the UART BaudRates in BRR1 and BRR2 registers according to UART_BaudRate value */
    
    BaudRate_Mantissa    = (((u32)CLK_GetClockFreq() << 1) / BaudRate );
    BaudRate_Mantissa    = (BaudRate_Mantissa + 0x00000001) >> 1; //rounding
    UART->BRR2 |= (u8)BaudRate_Mantissa  & (u8)0x0F;
    UART->BRR1 |= (u8)(BaudRate_Mantissa >> 4);           //< Set the LSB mantissa of UARTDIV
    UART->BRR2 |= (u8)(BaudRate_Mantissa >> 8) & (u8)0xF0;
    
    UART->CR2 &= (u8)~(UART_CR2_TEN | UART_CR2_REN); /**< Disable the Transmitter and Receiver before seting the LBCL, CPOL and CPHA bits */

    if ((u8)Mode & (u8)UART_MODE_TX_ENABLE)
    {
        UART->CR2 |= (u8)UART_CR2_TEN;  /**< Set the Transmitter Enable bit */
    }
    else
    {
        UART->CR2 &= (u8)(~UART_CR2_TEN);  /**< Clear the Transmitter Disable bit */
    }
    if ((u8)Mode & (u8)UART_MODE_RX_ENABLE)
    {
        UART->CR2 |= (u8)UART_CR2_REN;  /**< Set the Receiver Enable bit */
    }
    else
    {
        UART->CR2 &= (u8)(~UART_CR2_REN);  /**< Clear the Receiver Disable bit */
    }
    
    if (PIN == UART_PIN_14_15)
    {
        MSC->IOMXP0 &= ~(MSC_IOMXP0_SEL_P054);
        MSC->IOMXP0 |= ((u8)MSC_IOMXP0_SEL_P054 & UART_PIN_14_15);
    }
    else if (PIN == UART_PIN_20_21)
    {
        MSC->IOMXP0 &= ~(MSC_IOMXP0_SEL_P032);
        MSC->IOMXP0 |= ((u8)MSC_IOMXP0_SEL_P032 & UART_PIN_20_21);
    }    
    else if (PIN == UART_PIN_22_23)
    {
        MSC->IOMXP0 &= ~(MSC_IOMXP0_SEL_P010);
        MSC->IOMXP0 |= ((u8)MSC_IOMXP0_SEL_P010 & UART_PIN_22_23);
    }
}



/**
  * @brief Enable the UART peripheral.
  * @par Full description:
  * Enable the UART peripheral.
  * @param[in] NewState new state of the UART Communication.
  * This parameter can be:
  * - ENABLE
  * - DISABLE
  * @retval
  * None
  */
INLINE void UART_Cmd(FunctionalState NewState)
{
    if (NewState != DISABLE)
    {
        UART->CR1 &= (u8)(~UART_CR1_UARTD); /**< UART Enable */
    }
    else
    {
        UART->CR1 |= UART_CR1_UARTD;  /**< UART Disable (for low power consumption) */
    }
}

/**
  * @brief Enables or disables the specified UART interrupts.
  * @par Full description:
  * Enables or disables the specified UART interrupts.
  * @param[in] UART_IT specifies the UART interrupt sources to be enabled or disabled.
  * This parameter can be one of the following values:
  *   - UART_IT_TXE:  Tansmit Data Register empty interrupt
  *   - UART_IT_TC:   Transmission complete interrupt
  *   - UART_IT_RXNE_OR: Receive Data register not empty/Over run error interrupt
  *   - UART_IT_IDLE: Idle line detection interrupt
  *   - UART_IT_PE:   Parity Error interrupt
  * @param[in] NewState new state of the specified UART interrupts.
  * This parameter can be: ENABLE or DISABLE.
  * @retval
  * None
  */
INLINE void UART_ITConfig(UART_IT_TypeDef UART_IT, FunctionalState NewState)
{
    u8 uartreg, itpos = 0x00;
    
    /* Get the UART register index */
    uartreg = (u8)(UART_IT >> (u8)0x08);
    /* Get the UART IT index */
    itpos = (u8)((u8)1 << (u8)((u8)UART_IT & (u8)0x0F));

    if (NewState != DISABLE)
    {
        /**< Enable the Interrupt bits according to UART_IT mask */
        if (uartreg == 0x01)
        {
            UART->CR1 |= itpos;
        }
        else if (uartreg == 0x02)
        {
            UART->CR2 |= itpos;
        }
    }
    else
    {
        /**< Disable the interrupt bits according to UART_IT mask */
        if (uartreg == 0x01)
        {
            UART->CR1 &= (u8)(~itpos);
        }
        else if (uartreg == 0x02)
        {
            UART->CR2 &= (u8)(~itpos);
        }
    }

}

INLINE u8 UART_IsITEnabled(UART_IT_TypeDef UART_IT){
  if ((UART_IT >> 8)==0x02){
      return (UART->CR2 & (1<< ((u8)UART_IT & 0x0F)));
  }
  else if ((UART_IT >> 8)==0x01){
      return (UART->CR1 & (1<< ((u8)UART_IT & 0x0F)));
  }
  return (0);
}

/**
  * @brief Selects the UART WakeUp method.
  * @par Full description:
  * Selects the UART WakeUp method.
  * @param[in] UART_WakeUp: specifies the UART wakeup method.
  * This parameter can be any of the @ref UART_WakeUp_TypeDef values.
  * @retval
  * None
  */
INLINE void UART_WakeUpConfig(UART_WakeUp_TypeDef UART_WakeUp)
{

    UART->CR1 &= ((u8)~UART_CR1_WAKE);
    UART->CR1 |= (u8)UART_WakeUp;
}
/**
  * @brief Determines if the UART is in mute mode or not.
  * @par Full description:
  * Determines if the UART is in mute mode or not.
  * @param[in] NewState: new state of the UART mode.
  * This parameter can be: ENABLE or DISABLE.
  * @retval
  * None
  */
INLINE void UART_ReceiverWakeUpCmd(FunctionalState NewState)
{
  
    if (NewState != DISABLE)
    {
        /* Enable the mute mode UART by setting the RWU bit in the CR2 register */
        UART->CR2 |= UART_CR2_RWU;
    }
    else
    {
        /* Disable the mute mode UART by clearing the RWU bit in the CR1 register */
        UART->CR2 &= ((u8)~UART_CR2_RWU);
    }
}

/**
  * @brief Returns the most recent received data by the UART peripheral.
  * @par Full description:
  * Returns the most recent received data by the UART peripheral.
  * @retval u8 Received Data
  * @par Required preconditions:
  * UART_Cmd(ENABLE);
  */
INLINE u8 UART_ReceiveData8(void)
{
    return ((u8)UART->DR);
}


/**
  * @brief Returns the most recent received data by the UART peripheral.
  * @par Full description:
  * Returns the most recent received data by the UART peripheral.
  * @retval u16 Received Data
  * @par Required preconditions:
  * UART_Cmd(ENABLE);
  */
INLINE u16 UART_ReceiveData9(void)
{
    return (u16)( (((u16) UART->DR) | ((u16)(((u16)( (u16)UART->CR1 & (u16)UART_CR1_R8)) << 1))) & ((u16)0x01FF));
}

/**
  * @brief Transmits 8 bit data through the UART peripheral.
  * @par Full description:
  * Transmits 8 bit data through the UART peripheral.
  * @param[in] Data: the data to transmit.
  * @retval
  * None
  * @par Required preconditions:
  * UART_Cmd(ENABLE);
  */
INLINE void UART_SendData8(u8 Data)
{
    /* Transmit Data */
    UART->DR = Data;
}

/**
  * @brief Transmits 9 bit data through the UART peripheral.
  * @par Full description:
  * Transmits 9 bit data through the UART peripheral.
  * @param[in] Data: the data to transmit.
  * @retval
  * None
  * @par Required preconditions:
  * UART_Cmd(ENABLE);
  */
INLINE void UART_SendData9(u16 Data)
{
    /**< Clear the transmit data bit 8 [8]  */
    UART->CR1 &= ((u8)~UART_CR1_T8);
    /**< Write the transmit data bit [8]  */
    UART->CR1 |= (u8)(((u8)(Data >> 2)) & UART_CR1_T8);
    /**< Write the transmit data bit [0:7] */
    UART->DR   = (u8)(Data);
}

/**
  * @brief Transmits break characters.
  * @par Full description:
  * Transmits break characters on the UART peripheral.
  * @retval
  * None
  */
INLINE void UART_SendBreak(void)
{
    UART->CR2 |= UART_CR2_SBK;
}

/**
  * @brief Checks whether the specified UART flag is set or not.
  * @par Full description:
  * Checks whether the specified UART flag is set or not.
  * @param[in] UART_FLAG specifies the flag to check.
  * This parameter can be any of the @ref UART_Flag_TypeDef enumeration.
  * @retval FlagStatus (SET or RESET)
  */
INLINE FlagStatus UART_GetFlagStatus(UART_Flag_TypeDef UART_FLAG)
{
    FlagStatus status = RESET;

  
    /* Check the status of the specified UART flag*/
    if (UART_FLAG == UART_FLAG_SBK)
    {
        if ((UART->CR2 & (u8)UART_FLAG) != (u8)0x00)
        {
            /* UART_FLAG is set*/
            status = SET;
        }
        else
        {
            /* UART_FLAG is reset*/
            status = RESET;
        }
    }
    else
    {
        if ((UART->SR & (u8)UART_FLAG) != (u8)0x00)
        {
            /* UART_FLAG is set*/
            status = SET;
        }
        else
        {
            /* UART_FLAG is reset*/
            status = RESET;
        }
    }
    /* Return the UART_FLAG status*/
    return status;
}
/**
  * @brief Clears the UART flags.
  * @par Full description:
  * Clears the UART flags.
  * @param[in] UART_FLAG specifies the flag to clear
  * This parameter can be any combination of the following values:
  *   - UART_FLAG_RXNE: Receive data register not empty flag.
  * @par Notes:
  *   - PE (Parity error), FE (Framing error), NE (Noise error), OR (OverRun error)
  *     and IDLE (Idle line detected) flags are cleared by software sequence: a read
  *    operation to UART_SR register (UART_GetFlagStatus())followed by a read operation
  *     to UART_DR register(UART_ReceiveData8() or UART_ReceiveData9()).
  *   - RXNE flag can be also cleared by a read to the UART_DR register
  *     (UART_ReceiveData8()or UART_ReceiveData9()).
  *   - TC flag can be also cleared by software sequence: a read operation to UART_SR
  *     register (UART_GetFlagStatus()) followed by a write operation to UART_DR register
  *     (UART_SendData8() or UART_SendData9()).
  *   - TXE flag is cleared only by a write to the UART_DR register (UART_SendData8() or
  *     UART_SendData9()).
  *   - SBK flag is cleared during the stop bit of break.
  * @retval
  * None
  */

INLINE void UART_ClearFlag(UART_Flag_TypeDef UART_FLAG)
{

    /* Clear the Receive Register Not Empty flag */
    if (UART_FLAG == UART_FLAG_RXNE)
    {
        UART->SR = (u8)~(UART_SR_RXNE);
    }
}

/**
  * @brief Checks whether the specified UART interrupt has occurred or not.
  * @par Full description:
  * Checks whether the specified UART interrupt has occurred or not.
  * @param[in] UART_IT: Specifies the UART interrupt pending bit to check.
  * This parameter can be one of the following values:
  *   - UART_IT_TXE:  Tansmit Data Register empty interrupt
  *   - UART_IT_TC:   Transmission complete interrupt
  *   - UART_IT_RXNE: Receive Data register not empty interrupt
  *   - UART_IT_IDLE: Idle line detection interrupt
  *   - UART_IT_OR:  OverRun Error interrupt
  *   - UART_IT_PE:   Parity Error interrupt
  * @retval
  * ITStatus The new state of UART_IT (SET or RESET).
  */
INLINE ITStatus UART_GetITStatus(UART_IT_TypeDef UART_IT)
{
    ITStatus pendingbitstatus = RESET;
    u8 itpos = 0;
    u8 itmask1 = 0;
    u8 itmask2 = 0;
    u8 enablestatus = 0;


    /* Get the UART IT index */
    itpos = (u8)((u8)1 << (u8)((u8)UART_IT & (u8)0x0F));
    /* Get the UART IT index */
    itmask1 = (u8)((u8)UART_IT >> (u8)4);
    /* Set the IT mask*/
    itmask2 = (u8)((u8)1 << itmask1);


    /* Check the status of the specified UART pending bit*/
    if (UART_IT == UART_IT_PE)
    {
        /* Get the UART_IT enable bit status*/
        enablestatus = (u8)((u8)UART->CR1 & itmask2);
        /* Check the status of the specified UART interrupt*/

        if (((UART->SR & itpos) != (u8)0x00) && enablestatus)
        {
            /* Interrupt occurred*/
            pendingbitstatus = SET;
        }
        else
        {
            /* Interrupt not occurred*/
            pendingbitstatus = RESET;
        }
    }
    else
    {
        /* Get the UART_IT enable bit status*/
        enablestatus = (u8)((u8)UART->CR2 & itmask2);
        /* Check the status of the specified UART interrupt*/
        if (((UART->SR & itpos) != (u8)0x00) && enablestatus)
        {
            /* Interrupt occurred*/
            pendingbitstatus = SET;
        }
        else
        {
            /* Interrupt not occurred*/
            pendingbitstatus = RESET;
        }
    }

    /* Return the UART_IT status*/
    return  pendingbitstatus;
}

/**
  * @brief Clears the UART pending flags.
  * @par Full description:
  * Clears the UART pending bit.
  * @param[in] UART_IT specifies the pending bit to clear
  * This parameter can be one of the following values:
  *   - UART_IT_RXNE: Receive Data register not empty interrupt.
  * @par Notes:
  *   - PE (Parity error), FE (Framing error), NE (Noise error), OR (OverRun error) and
  *     IDLE (Idle line detected) pending bits are cleared by software sequence: a read
  *     operation to UART_SR register (UART_GetITStatus()) followed by a read operation
  *     to UART_DR register (UART_ReceiveData8() or UART_ReceiveData9()).
  *   - RXNE pending bit can be also cleared by a read to the UART_DR register
  *     (UART_ReceiveData8() or UART_ReceiveData9()).
  *   - TC (Transmit complet) pending bit can be cleared by software sequence: a read
  *     operation to UART_SR register (UART_GetITStatus()) followed by a write operation
  *     to UART_DR register (UART_SendData8()or UART_SendData9()).
  *   - TXE pending bit is cleared only by a write to the UART_DR register
  *     (UART_SendData8() or UART_SendData9()).
  * @retval
  * None
  */
INLINE void UART_ClearITPendingBit(UART_IT_TypeDef UART_IT)
{
   
    /*< Clear the Receive Register Not Empty pending bit */
    if (UART_IT == UART_IT_RXNE)
    {
        UART->SR = (u8)~(UART_SR_RXNE);
    }
}

/**
  * @}
  */

/******************* (C) COPYRIGHT 2015 STMicroelectronics *****END OF FILE****/
