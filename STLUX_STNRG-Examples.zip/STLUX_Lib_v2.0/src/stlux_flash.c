/**
  ******************************************************************************
  * @file    stlux_flash.c
  * @brief This file contains all the prototypes/macros for the Flash Data Memory.
  * @author STMicroelectronics
  * @version V2.0
  * @date 27/10/2015
  ******************************************************************************
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "stlux_flash.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private Constants ---------------------------------------------------------*/


INLINE void Unlock_eeprom_data_area()
{
          // unlock eeprom data zone write operation
	FLASH->DUKR = FLASH_RASS_KEY1;
    FLASH->DUKR = FLASH_RASS_KEY2;
}

/**
  * @brief  Locks the data EEPROM memory
  * @param  None
  * @retval None
  */
INLINE void Lock_eeprom_data_area()
{
          // unlock eeprom data zone write operation
	FLASH->DUKR = FLASH_DUKR_RESET_VALUE;
}

INLINE void Dump_data_to_eeprom(u16 ramaddr, u16 eeaddr)
{
  u8* ramtmp = (u8*)ramaddr;
  u8* eetmp  = (u8*)eeaddr;
  u8  val = *ramtmp;

	// wait previous write operation, if pending
	while(!(FLASH->IAPSR & FLASH_IAPSR_HVOFF)) 
		;
	// check if WR is enabled
	if(FLASH->IAPSR & FLASH_IAPSR_DUL) {
		*eetmp = (u8) (ramaddr>>8);    eetmp++;
	} 
	// wait previous write operation, if pending
	while(!(FLASH->IAPSR & FLASH_IAPSR_HVOFF)) 
		;
	// check if WR is enabled
	if(FLASH->IAPSR & FLASH_IAPSR_DUL) {
                *eetmp = (u8) ramaddr;         eetmp++;
	} 
	// wait previous write operation, if pending
	while(!(FLASH->IAPSR & FLASH_IAPSR_HVOFF)) 
		;
	// check if WR is enabled
	if(FLASH->IAPSR & FLASH_IAPSR_DUL) {
                *eetmp   = val;
	} 
}

/**
 ******************************************************************************************
 *	\brief write one location into eeprom
 *
 *	The function is called by the main to write one eeprom value
 *
 *	\param val		value to be stored
 *	\param *addr	address to store the val
 *	\return none
 ******************************************************************************************
 */
INLINE void Write_data_eeprom(u16 addr, u8 val)
{

	// wait previous write operation, if pending
	while(!(FLASH->IAPSR & FLASH_IAPSR_HVOFF)) 
		;
	// check if WR is enabled
	if(FLASH->IAPSR & FLASH_IAPSR_DUL) {
		*(u8*)addr = val;
	} 
}

/**
 ******************************************************************************************
 *	\brief setup the last value stored into eeprom
 *
 *	The function is called by the main to read the eeprom value
 *
 *	\param *addr to read data
 *	\return data read from *addr
 ******************************************************************************************
 */
INLINE u8 Read_8_data_eeprom(u16 addr)
{
	return *(u8*)addr;
}

/******************* (C) COPYRIGHT 2015 STMicroelectronics *****END OF FILE****/
