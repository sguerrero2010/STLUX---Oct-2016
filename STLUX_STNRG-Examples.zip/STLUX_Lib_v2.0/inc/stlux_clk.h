/**
  ******************************************************************************
  * @file stlux_clk.h
  * @brief This file contains function for clock peripheral of STLUX / STNRG
  * @author STMicroelectronics
  * @version V2.0
  * @date 27/10/2015
  ******************************************************************************
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  ******************************************************************************
  */


/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __STLUX_CLK_H
#define __STLUX_CLK_H

/* Includes ------------------------------------------------------------------*/
/* Contains the description of STLUX385A */
#include "stlux.h"

/*----------------------------------------------------------------------------*/

/* Exported types ------------------------------------------------------------*/
/** @addtogroup CLK_Exported_Types
  * @{
  */

typedef enum {
CLK_SMED0 = (u8)0x00,
CLK_SMED1 = (u8)0x01,
CLK_SMED2 = (u8)0x02,
CLK_SMED3 = (u8)0x03,
CLK_SMED4 = (u8)0x04,
CLK_SMED5 = (u8)0x05

}CLK_SMD_TypeDef;
/**
   * @brief  CLK SMED Clock Source.
   */
typedef enum {
	CLK_SMED_SOURCE_HSI    = (u8)0x00, /*!< Clock Source HSI. */
	CLK_SMED_SOURCE_PLL    = (u8)0x01, /*!< Clock Source PLL. */
	CLK_SMED_SOURCE_LSI    = (u8)0x02, /*!< Clock Source LSI. */
	CLK_SMED_SOURCE_HSE    = (u8)0x03 /*!< Clock Source HSE. */
} CLK_SMED_Source_TypeDef;

/**
   * @brief  CLK ADC Clock Source.
   */
typedef enum {
	CLK_ADC_SOURCE_HSI    = (u8)0x00, /*!< Clock Source HSI. */
	CLK_ADC_SOURCE_PLL    = (u8)0x01, /*!< Clock Source PLL. */
	CLK_ADC_SOURCE_LSI    = (u8)0x02, /*!< Clock Source LSI. */
	CLK_ADC_SOURCE_HSE    = (u8)0x03 /*!< Clock Source HSE. */
} CLK_ADC_Source_TypeDef;

/**
   * @brief  CLK SMED Clock division factor.
   */
typedef enum {
    CLK_SMED_PRESCALER_1	 	= ((u8)0x00),	/*!< Time base Prescaler = 1 (No effect)*/
    CLK_SMED_PRESCALER_2   	= ((u8)0x10),  /*!< Time base Prescaler = 2 */
    CLK_SMED_PRESCALER_4   	= ((u8)0x20),  /*!< Time base Prescaler = 4 */
    CLK_SMED_PRESCALER_8	 	= ((u8)0x30),  /*!< Time base Prescaler = 8 */
    CLK_SMED_PRESCALER_16  	= ((u8)0x40),  /*!< Time base Prescaler = 16 */
    CLK_SMED_PRESCALER_32   = ((u8)0x50),  /*!< Time base Prescaler = 32 */
    CLK_SMED_PRESCALER_64   = ((u8)0x60),  /*!< Time base Prescaler = 64 */
    CLK_SMED_PRESCALER_128  = ((u8)0x70)  /*!< Time base Prescaler = 128 */
} CLK_SMED_PRESCALER_TypeDef;

/**
   * @brief  PLL Clock Source.
   */
typedef enum {
  CLK_PLL_SOURCE_HSI    = (u8)0x00, /*!< Clock Source HSI. */
  CLK_PLL_SOURCE_HSE    = (u8)0x04 /*!< Clock Source HSE. */
} CLK_PLL_Source_TypeDef;

/**
   * @brief  CLK PLL Clock division factor for CCO.
   */
typedef enum {
    CLK_PLL_DIVIDER_4	 		= ((u8)0x00),  /*!< Time base DIVIDER  /4 */
    CLK_PLL_DIVIDER_5   		= ((u8)0x01),  /*!< Time base DIVIDER  /5 */
    CLK_PLL_DIVIDER_6   		= ((u8)0x02),  /*!< Time base DIVIDER  /6 */
    CLK_PLL_DIVIDER_7	 		= ((u8)0x03),  /*!< Time base DIVIDER  /7 */
    CLK_PLL_PRESCALER_1	 		= ((u8)0x00),  /*!< Time base PRESCALER  1 */
    CLK_PLL_PRESCALER_2   		= ((u8)0x08),  /*!< Time base PRESCALER  2 */
    CLK_PLL_PRESCALER_4   		= ((u8)0x10),  /*!< Time base PRESCALER  4 */
    CLK_PLL_PRESCALER_8	 		= ((u8)0x18)  /*!< Time base PRESCALER  8 */
	
} CLK_PLL_DIVPRES_TypeDef;



/**
   * @brief  CLK AWU Clock division factor.
   */
typedef enum {
    CLK_AWU_DIVIDER_1	 	= ((u8)0x00),	/*!< Time base Divider = 1 (No effect)*/
    CLK_AWU_DIVIDER_2   	= ((u8)0x01),	/*!< Time base Divider = 2 */
    CLK_AWU_DIVIDER_4   	= ((u8)0x02),  /*!< Time base Divider = 4 */
    CLK_AWU_DIVIDER_8	 	= ((u8)0x03),  /*!< Time base Divider = 8 */
    CLK_AWU_DIVIDER_16  	= ((u8)0x04),  /*!< Time base Divider = 16 */
    CLK_AWU_DIVIDER_32    	= ((u8)0x05),  /*!< Time base Divider = 32 */
    CLK_AWU_DIVIDER_64    	= ((u8)0x06),  /*!< Time base Divider = 64 */
    CLK_AWU_DIVIDER_128   	= ((u8)0x07),  /*!< Time base Divider = 128 */
	CLK_AWU_DIVIDER_256   	= ((u8)0x08)  	/*!< Time base Divider = 256	 */
} CLK_AWU_DIVIDER_TypeDef;


/**
   * @brief Switch Mode Auto, Manual.
   */
typedef enum {
  CLK_SWITCHMODE_MANUAL = (u8)0x00, /*!< Enable the manual clock switching mode */
  CLK_SWITCHMODE_AUTO   = (u8)0x01  /*!< Enable the automatic clock switching mode */
} CLK_SwitchMode_TypeDef;

/**
   * @brief Current Clock State.
   */
typedef enum {
  CLK_CURRENTCLOCKSTATE_DISABLE = (u8)0x00, /*!< Current clock disable */
  CLK_CURRENTCLOCKSTATE_ENABLE  = (u8)0x01  /*!< Current clock enable */
} CLK_CurrentClockState_TypeDef;

/**
   * @brief  Clock security system configuration.
   */
typedef enum {
  CLK_CSSCONFIG_ENABLEWITHIT = (u8)0x05, /*!< Enable CSS with detection interrupt */
  CLK_CSSCONFIG_ENABLE    = (u8)0x01, /*!< Enable CSS without detection interrupt */
  CLK_CSSCONFIG_DISABLE      = (u8)0x00  /*!< Leave CSS desactivated (to be used in CLK_Init() function) */
} CLK_CSSConfig_TypeDef;

/**
   * @brief  CLK Clock Source.
   */
typedef enum {
  CLK_SOURCE_HSI    = (u8)0xE1, /*!< Clock Source HSI. */
  CLK_SOURCE_LSI    = (u8)0xD2, /*!< Clock Source LSI. */
  CLK_SOURCE_HSE    = (u8)0xB4 /*!< Clock Source HSE. */
} CLK_Source_TypeDef;

/**
   * @brief  CLK HSI Calibration Value.
   */
typedef enum {
  CLK_HSITRIMVALUE_0   = (u8)0x00, /*!< HSI Calibtation Value 0 */
  CLK_HSITRIMVALUE_1   = (u8)0x01, /*!< HSI Calibtation Value 1 */
  CLK_HSITRIMVALUE_2   = (u8)0x02, /*!< HSI Calibtation Value 2 */
  CLK_HSITRIMVALUE_3   = (u8)0x03, /*!< HSI Calibtation Value 3 */
  CLK_HSITRIMVALUE_4   = (u8)0x04, /*!< HSI Calibtation Value 4 */
  CLK_HSITRIMVALUE_5   = (u8)0x05, /*!< HSI Calibtation Value 5 */
  CLK_HSITRIMVALUE_6   = (u8)0x06, /*!< HSI Calibtation Value 6 */
  CLK_HSITRIMVALUE_7   = (u8)0x07  /*!< HSI Calibtation Value 7 */
} CLK_HSITrimValue_TypeDef;

/**
   * @brief   CLK  Clock Output
   */
typedef enum {
  CLK_OUTPUT_HSI      		= (u8)0x00, /*!< Clock Output HSI */
  CLK_OUTPUT_LSI      		= (u8)0x02, /*!< Clock Output LSI */
  CLK_OUTPUT_HSE      		= (u8)0x04, /*!< Clock Output HSE */
	CLK_OUTPUT_PLL      		= (u8)0x06, /*!< Clock Output PLL */
  CLK_OUTPUT_CPU      		= (u8)0x08, /*!< Clock Output */
  CLK_OUTPUT_CKM  				= (u8)0x0A, /*!< Clock Output*/
  CLK_OUTPUT_SMED0_CK 		= (u8)0x0C, /*!< Clock Output */
  CLK_OUTPUT_SMED1_CK 		= (u8)0x0E, /*!< Clock Output */
  CLK_OUTPUT_SMED2_CK 		= (u8)0x10, /*!< Clock Output */
  CLK_OUTPUT_SMED3_CK 		= (u8)0x12, /*!< Clock Output */
  CLK_OUTPUT_SMED4_CK 		= (u8)0x14, /*!< Clock Output */
  CLK_OUTPUT_SMED5_CK 		= (u8)0x16, /*!< Clock Output */
	CLK_OUTPUT_ADC_CK  			= (u8)0x18, /*!< Clock Output */
	CLK_OUTPUT_AWU_CK   		= (u8)0x1C, /*!< Clock Output */
  CLK_OUTPUT_PRESCALED_PLL_CK	= (u8)0x1E  /*!< Clock Output OTHER */
} CLK_Output_TypeDef;

/**
   * @brief   CLK Enable peripheral
   */
/* Elements values convention: 0xXY
    X = choice between the peripheral registers
        X = 0 : PCKENR1
        X = 1 : PCKENR2
    Y = Peripheral position in the register
*/
typedef enum {
  CLK_PERIPHERAL_I2C    = (u8)0x00, /*!< Peripheral Clock Enable 1 */
  CLK_PERIPHERAL_GPIO0  = (u8)0x01, /*!< Peripheral Clock Enable 1 */
  CLK_PERIPHERAL_UART   = (u8)0x02, /*!< Peripheral Clock Enable 1 */
	CLK_PERIPHERAL_DALI   = (u8)0x03, /*!< Peripheral Clock Enable 1 */
	CLK_PERIPHERAL_STMR   = (u8)0x04, /*!< Peripheral Clock Enable 1 */
	CLK_PERIPHERAL_GPIO1  = (u8)0x05, /*!< Peripheral Clock Enable 1 */
  CLK_PERIPHERAL_AWU    = (u8)0x06, /*!< Peripheral Clock Enable 1 */
  CLK_PERIPHERAL_ADC 		= (u8)0x07, /*!< Peripheral Clock Enable 1 */
  CLK_PERIPHERAL_SMED0 	= (u8)0x10, /*!< Peripheral Clock Enable 2 */
  CLK_PERIPHERAL_SMED1 	= (u8)0x11, /*!< Peripheral Clock Enable 2 */
  CLK_PERIPHERAL_SMED2 	= (u8)0x12, /*!< Peripheral Clock Enable 2 */
  CLK_PERIPHERAL_SMED3 	= (u8)0x13, /*!< Peripheral Clock Enable 2 */
  CLK_PERIPHERAL_SMED4 	= (u8)0x14, /*!< Peripheral Clock Enable 2 */
  CLK_PERIPHERAL_SMED5 	= (u8)0x15, /*!< Peripheral Clock Enable 2 */
  CLK_PERIPHERAL_MSC 		= (u8)0x17  /*!< Peripheral Clock Enable 2 */
} CLK_Peripheral_TypeDef;

/**
   * @brief  CLK Flags.
   */
/* Elements values convention: 0xXZZ
    X = choice between the flags registers
        X = 1 : ICKR
        X = 2 : ECKR
        X = 3 : SWCR
				X = 4 : CSSR
				X = 5 : CCOR
   ZZ = flag mask in the register (same as map file)
*/
typedef enum {
  CLK_FLAG_LSIRDY  = (u16)0x0110, /*!< Low speed internal oscillator ready Flag */
  CLK_FLAG_HSIRDY  = (u16)0x0102, /*!< High speed internal oscillator ready Flag */
  CLK_FLAG_HSERDY  	= (u16)0x0202, /*!< High speed external oscillator ready Flag */
  CLK_FLAG_SWIF   	= (u16)0x0308, /*!< Clock switch interrupt Flag */
  CLK_FLAG_SWBSY    = (u16)0x0301, /*!< Switch busy Flag */
  CLK_FLAG_CSSD   	= (u16)0x0408, /*!< Clock security system detection Flag */
  CLK_FLAG_AUX   		= (u16)0x0402, /*!< Auxiliary oscillator connected to master clock */
  CLK_FLAG_CCOBSY  	= (u16)0x0504, /*!< Configurable clock output busy */
  CLK_FLAG_CCORDY   = (u16)0x0502 /*!< Configurable clock output ready */

}CLK_Flag_TypeDef;

/**
   * @brief CLK interrupt configuration and Flags cleared by software.
   */
typedef enum {
  CLK_IT_CSSD   = (u8)0x0C, /*!< Clock security system detection Flag */
  CLK_IT_SWIF   = (u8)0x1C /*!< Clock switch interrupt Flag */
}CLK_IT_TypeDef;

/**
   * @brief  CLK Clock Divisor.
   */
/* Warning:
   0xxxxxx = HSI divider
   1xxxxxx = CPU divider
   Other bits correspond to the divider's bits mapping
*/
typedef enum {
  CLK_PRESCALER_HSIDIV1   = (u8)0x00, /*!< High speed internal clock prescaler: 1 */
  CLK_PRESCALER_HSIDIV2   = (u8)0x08, /*!< High speed internal clock prescaler: 2 */
  CLK_PRESCALER_HSIDIV4   = (u8)0x10, /*!< High speed internal clock prescaler: 4 */
  CLK_PRESCALER_HSIDIV8   = (u8)0x18, /*!< High speed internal clock prescaler: 8 */
  CLK_PRESCALER_CPUDIV1   = (u8)0x80, /*!< CPU clock division factors 1 */
  CLK_PRESCALER_CPUDIV2   = (u8)0x81, /*!< CPU clock division factors 2 */
  CLK_PRESCALER_CPUDIV4   = (u8)0x82, /*!< CPU clock division factors 4 */
  CLK_PRESCALER_CPUDIV8   = (u8)0x83, /*!< CPU clock division factors 8 */
  CLK_PRESCALER_CPUDIV16  = (u8)0x84, /*!< CPU clock division factors 16 */
  CLK_PRESCALER_CPUDIV32  = (u8)0x85, /*!< CPU clock division factors 32 */
  CLK_PRESCALER_CPUDIV64  = (u8)0x86, /*!< CPU clock division factors 64 */
  CLK_PRESCALER_CPUDIV128 = (u8)0x87  /*!< CPU clock division factors 128 */
} CLK_Prescaler_TypeDef;

/**
   * @brief  SWIM Clock divider.
   */
typedef enum {
  CLK_SWIMDIVIDER_2 = (u8)0x00, /*!< SWIM clock is divided by 2 */
  CLK_SWIMDIVIDER_OTHER = (u8)0x01 /*!< SWIM clock is not divided by 2 */
}CLK_SWIMDivider_TypeDef;

/**
  * @}
  */

/* Exported constants --------------------------------------------------------*/

/** @addtogroup CLK_Exported_Constants
  * @{
  */

#define CLK_TIMEOUT ((u16)0x491)    /*!< Timeout for the clock switch operation. */
/**
  * @}
  */

/** @addtogroup CLK_Exported_functions
  * @{
  */
void CLK_Reset(void);
void CLK_HSECmd(FunctionalState NewState);
void CLK_HSICmd(FunctionalState NewState);
void CLK_LSICmd(FunctionalState NewState);
void CLK_CCOCmd(FunctionalState NewState);
void CLK_REGAHCmd(FunctionalState NewState);
void CLK_ClockSwitchCmd(FunctionalState NewState);
void CLK_FastHaltWakeUpCmd(FunctionalState NewState);
void CLK_PeripheralClockConfig(CLK_Peripheral_TypeDef CLK_Peripheral, FunctionalState NewState);
ErrorStatus CLK_ClockSwitchConfig(CLK_SwitchMode_TypeDef CLK_SwitchMode, CLK_Source_TypeDef CLK_NewClock, FunctionalState ITState, CLK_CurrentClockState_TypeDef CLK_CurrentClockState);
void CLK_HSIPrescalerConfig(CLK_Prescaler_TypeDef HSIPrescaler);
void CLK_ITConfig(CLK_IT_TypeDef CLK_IT, FunctionalState NewState);
void CLK_SYSCLKConfig(CLK_Prescaler_TypeDef CLK_Prescaler);
void CLK_SWIMConfig(CLK_SWIMDivider_TypeDef CLK_SWIMDivider);
void CLK_ClockSecuritySystemEnable(void);
void CLK_SYSCLKEmergencyClear(void);
void CLK_AdjustHSICalibrationValue(CLK_HSITrimValue_TypeDef CLK_HSICalibrationValue);
u32 CLK_GetClockFreq(void);
CLK_Source_TypeDef CLK_GetSYSCLKSource(void);
FlagStatus CLK_GetFlagStatus(CLK_Flag_TypeDef CLK_FLAG);
ITStatus CLK_GetITStatus(CLK_IT_TypeDef CLK_IT);
void CLK_ClearITPendingBit(CLK_IT_TypeDef CLK_IT);

/* function added/changed compare to STM8S firmware library */
void CLK_PLLConfig(CLK_PLL_Source_TypeDef CLK_PLL_Source, CLK_PLL_DIVPRES_TypeDef CLK_PLL_DIVPRES);
void CLK_PLLCmd(FunctionalState NewState);
void CLK_CCOConfig(CLK_Output_TypeDef CLK_CCO,u8 CLK_CCODIVR);
void CLK_ADCConfig(CLK_ADC_Source_TypeDef CLK_ADC_Source,u8 CLK_ADC_DIV);
void CLK_AWUConfig(CLK_AWU_DIVIDER_TypeDef CLK_AWU_DIVIDER);
void CLK_SMEDConfig(CLK_SMD_TypeDef CLK_SMD, CLK_SMED_Source_TypeDef Source, CLK_SMED_PRESCALER_TypeDef Prescaler);
/**
  * @}
  */
#endif /* __STM8S_CLK_H */

/******************* (C) COPYRIGHT 2015 STMicroelectronics *****END OF FILE****/
