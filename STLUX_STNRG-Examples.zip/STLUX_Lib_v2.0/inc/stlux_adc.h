/**
  ******************************************************************************
  * @file stlux_adc.h
  * @brief This file contains all the prototypes/macros for the ADC peripheral.
  * @author STMicroelectronics
  * @version V2.0
  * @date 27/10/2015
  ******************************************************************************
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  ******************************************************************************
  */


/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __STLUX_ADC_H
#define __STLUX_ADC_H

/* Includes ------------------------------------------------------------------*/
#include "stlux.h"

#define ADC_GetValue8(DATx_y) (ADC->DATx_y)


/*-----------------------------------------------------------------------------------------*/


/**
  * @brief ADC power down ADC_CFG_PD
  */
typedef enum {
  ADC_PowerDown_EN    = (u8)0x00, /**< The ADC analog macro is enabled */
  ADC_PowerDown_DIS   = (u8)0x01  /**< The ADC analog macro is disabled in power down */
} ADC_PowerDown_TypeDef;



/**
  * @brief ADC Stop the sequencer ADC_CFG_STOP
  */
typedef enum {
  ADC_StopSeq_EN    = (u8)0x20  /**< the Sequencer of ADC is reset and return to idle state   */
} ADC_StopSeq_TypeDef;



/**
  * @brief ADC DATA Buffer Flushing ADC_CFG_SEQ_DATA_FIFO_FLUSH
  */
typedef enum {
  ADC_SeqDataFlush_EN    = (u8)0x40  /**< The FIFO data buffer are flushed    */
} ADC_SeqDataFlush_TypeDef;



/**
  * @brief ADC conversion mode selection ADC_CFG_CIRCULAR
  */
typedef enum {
  ADC_ConvMode_SEQUENCE    = (u8)0x00,  /**< Sequence conversion mode */
  ADC_ConvMode_CIRCULAR     = (u8)0x08  /**< Circular conversion mode */
} ADC_ConvMode_TypeDef;



/**
  * @brief ADC data output format ADC_CFG_DATA_OUT_FORMAT
  */
typedef enum {
  ADC_DataFormat_H8L2    = (u8)0x00, /**< Left Alignment - DataH (9:2), DataL(1:0) */
  ADC_DataFormat_H2L8    = (u8)0x10  /**< Right Alignment - DataH (9:8), DataL(7:0)    */
} ADC_DataFormat_TypeDef;


/*-----------------------------------------------------------------------------------------*/


/**
  * @brief ADC start of conversion ADC_SOC_SOC 
  */
typedef enum {
  ADC_Start_EN   =   (u8)0x01 /*!< Start of conversion */
} ADC_Start_TypeDef;


/*-----------------------------------------------------------------------------------------*/


/**
  * @brief ADC End of Conversion mode interrupt enable ADC_IER_EOC_EN 
  */
typedef enum {
  ADC_IntEndConvMode_DIS  =   (u8)0x00, /**< The interrupt is disabled */
  ADC_IntEndConvMode_EN   =   (u8)0x01  /**< The interrupt is generated at every EoC of ADC analog macro */
} ADC_IntEndConvMode_TypeDef;



/**
  * @brief ADC End of Sequence mode interrupt enable ADC_IER_EOS_EN 
  */
typedef enum {
  ADC_IntEndSeqMode_DIS  =   (u8)0x00, /**< The interrupt is disabled */
  ADC_IntEndSeqMode_EN   =   (u8)0x02  /**< The interrupt is generated at the end of sequence conversion */
} ADC_IntEndSeqMode_TypeDef;



/**
  * @brief ADC End of Sequence mode interrupt enable ADC_IER_SEQ_FULL_EN 
  */
typedef enum {
  ADC_IntSeqFull_DIS  =   (u8)0x00, /**< The interrupt is disabled */
  ADC_IntSeqFull_EN   =   (u8)0x04  /**< The interrupt is generated if the Sequencer buffer is full */
} ADC_IntSeqFull_TypeDef;


/*-----------------------------------------------------------------------------------------*/


/**
  * @brief ADC analog channel selection ADC_SEQ_CH
  */
typedef enum {
  ADC_CHANNEL_0  = (u8)0x00, /**< Analog channel 0 */
  ADC_CHANNEL_1  = (u8)0x01, /**< Analog channel 1 */
  ADC_CHANNEL_2  = (u8)0x02, /**< Analog channel 2 */
  ADC_CHANNEL_3  = (u8)0x03, /**< Analog channel 3 */
  ADC_CHANNEL_4  = (u8)0x04, /**< Analog channel 4 */
#if defined(_STLUX325A_) || defined(_STLUX285A_) || defined(_STNRG328A_) || defined(_STNRG288A_)
  ADC_CHANNEL_5  = (u8)0x05 /**< Analog channel 5 */
#else //For other STLUX devices
  ADC_CHANNEL_5  = (u8)0x05, /**< Analog channel 5 */
  ADC_CHANNEL_6  = (u8)0x06, /**< Analog channel 6 */
  ADC_CHANNEL_7  = (u8)0x07  /**< Analog channel 7 */
#endif
} ADC_Channel_TypeDef;









/**
  * @brief ADC analog gain selection ADC_SEQ_Gain
  */
typedef enum {
#if defined(_STLUX385A_) || defined(_STNRG388A_)
  ADC_GAIN_16  = (u8)0x00, /**< Gain 1.6 */
  ADC_GAIN_64  = (u8)0x08 /**< Gain 6.4 */
#else
  ADC_GAIN_16  = (u8)0x00 /**< Gain 1.6 */
#endif //_STLUX385A_
} ADC_Gain_TypeDef;


/*-----------------------------------------------------------------------------------------*/


/**
  * @brief ADC Status registr - End of conversion mode ADC_SR_EOC
  */
typedef enum {
  ADC_StatusEOC_SET  = ADC_SR_EOC, /**< The EOC has been set */
  ADC_StatusEOC_NUL  = (u8)0x00
} ADC_StatusEOC_TypeDef;



/**
  * @brief ADC Status registr - End of sequence mode ADC_SR_SEQ
  */
typedef enum {
  ADC_StatusEOS_SET  = ADC_SR_EOS, /**< The EOS has been set */
  ADC_StatusEOS_NUL  = (u8)0x00
} ADC_StatusEOS_TypeDef;


/*-----------------------------------------------------------------------------------------*/





/**
  * @}
  */

/* Exported functions ------------------------------------------------------- */

/** @addtogroup ADC_Exported_Functions
  * @{
  */

void ADC_Reset(void);
void ADC_Init(ADC_ConvMode_TypeDef ADC_ConvMode_Init,
              ADC_DataFormat_TypeDef ADC_DataFormat_Init);

void ADC_Interrupt(ADC_IntEndConvMode_TypeDef ADC_IntEndConvMode_Interrupt,
                   ADC_IntEndSeqMode_TypeDef ADC_IntEndSeqMode_interrupt,
                   ADC_IntSeqFull_TypeDef ADC_IntSeqFull_Interrupt);

void ADC_Sequencer(ADC_Channel_TypeDef ADC_Channel_Sequencer,
                   ADC_Gain_TypeDef ADC_Gain_Sequencer);

void ADC_Start(void);
void ADC_Stop(void);
void ADC_PowerUp(void);
void ADC_PowerDown(void);
void ADC_Abort(void);
void ADC_Delay(u8 ADC_Delay_Value);
u16 ADC_Measure(ADC_Channel_TypeDef ADC_Channel_Measure, ADC_Gain_TypeDef ADC_Gain_Measure);
u8 ADC_GetStatus(void);
void ADC_SetStatus(ADC_StatusEOS_TypeDef EOS, ADC_StatusEOC_TypeDef EOC);

/**
  * @}
  */

#endif /* __STLUX_ADC_H */

/******************* (C) COPYRIGHT 2015 STMicroelectronics *****END OF FILE****/
