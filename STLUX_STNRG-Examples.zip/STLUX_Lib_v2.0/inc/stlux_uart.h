/**
  ********************************************************************************
  * @file stlux_uart.h
  * @brief This file contains all functions prototypes and macros for the UART peripheral.
  * @author STMicroelectronics
  * @version V2.0
  * @date 27/10/2015
  ******************************************************************************
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __STLUX_UART_H
#define __STLUX_UART_H

/* Includes ------------------------------------------------------------------*/
#include "stlux.h"
/* Exported types ------------------------------------------------------------*/

/** @addtogroup UART_Exported_Types
  * @{
  */

/**
  * @brief UART WakeUP Modes UART_CR1_WAKE
  */

typedef enum { UART_WAKEUP_IDLELINE       = (u8)0x00, /**< 0x01 Idle Line wake up                */
               UART_WAKEUP_ADDRESSMARK    = UART_CR1_WAKE /**< 0x02 Address Mark wake up          */
             } UART_WakeUp_TypeDef;

/**
  * @brief UART stop bits possible values
  */

typedef enum { UART_STOPBITS_1   = (u8)0x00,    /**< One stop bit is  transmitted at the end of frame*/
               UART_STOPBITS_0_5 = (u8)0x10,    /**< Half stop bits is transmitted at the end of frame*/
               UART_STOPBITS_2  = (u8)0x20,    /**< Two stop bits are  transmitted at the end of frame*/
               UART_STOPBITS_1_5 = (u8)0x30     /**< One and half stop bits*/
             } UART_StopBits_TypeDef;


/**
  * @brief UART parity possible values UART_CR1
  */
typedef enum { UART_PARITY_NO     = (u8)0x00,      /**< No Parity*/
               UART_PARITY_EVEN   = (u8)0x04,      /**< Even Parity*/
               UART_PARITY_ODD    = (u8)0x06       /**< Odd Parity*/
             } UART_Parity_TypeDef;

/**
  * @brief UART Word length possible values UART_CR1
  */
typedef enum { UART_WORDLENGTH_8D = (u8)0x00,/**< 0x00 8 bits Data  */
               UART_WORDLENGTH_9D = (u8)0x10 /**< 0x10 9 bits Data  */
             } UART_WordLength_TypeDef;

         /**
  * @brief UART PIN configuration
  */
typedef enum { UART_PIN_14_15 = (u8)0x30,
               UART_PIN_20_21 = (u8)0x0C,
               UART_PIN_22_23 = (u8)0x01 
             } UART_PIN_TypeDef;         
         
                  
/**
  * @brief UART Mode possible values UART_CR3
  */
typedef enum { UART_MODE_RX_ENABLE     = (u8)0x08,  /**< 0x08 Receive Enable                     */
               UART_MODE_TX_ENABLE     = (u8)0x04,  /**< 0x04 Transmit Enable                    */
               UART_MODE_TX_DISABLE    = (u8)0x80,  /**< 0x80 Transmit Disable                   */
               UART_MODE_RX_DISABLE    = (u8)0x40,  /**< 0x40 Single-wire Half-duplex mode       */
               UART_MODE_TXRX_ENABLE   = (u8)0x0C  /**< 0x0C Transmit Enable and Receive Enable */
             } UART_Mode_TypeDef;
/**
  * @brief UART Flag possible values
  */
typedef enum { UART_FLAG_TXE   = (u16)0x0080, /*!< Transmit Data Register Empty flag */
               UART_FLAG_TC  = (u16)0x0040, /*!< Transmission Complete flag */
               UART_FLAG_RXNE = (u16)0x0020, /*!< Read Data Register Not Empty flag */
               UART_FLAG_IDLE = (u16)0x0010, /*!< Idle line detected flag */
               UART_FLAG_OR   = (u16)0x0008, /*!< OverRun error flag */
               UART_FLAG_NF  = (u16)0x0004, /*!< Noise error flag */
               UART_FLAG_FE  = (u16)0x0002, /*!< Framing Error flag */
               UART_FLAG_PE  = (u16)0x0001, /*!< Parity Error flag */
               UART_FLAG_SBK   = (u16)0x0101  /*!< Send Break characters Flag */
             } UART_Flag_TypeDef;

typedef enum { UART_IT_TXE        = (u16)0x0277, /*!< Transmit interrupt */
               UART_IT_TC         = (u16)0x0266, /*!< Transmission Complete interrupt */
               UART_IT_RXNE       = (u16)0x0255, /*!< Receive interrupt */
               UART_IT_IDLE       = (u16)0x0244, /*!< IDLE line interrupt */
               UART_IT_OR         = (u16)0x0235, /*!< Overrun Error interrupt */
               UART_IT_PE         = (u16)0x0100, /*!< Parity Error interrupt */
               UART_IT_RXNE_OR    = (u16)0x0205  /*!< Receive/Overrun interrupt */
             } UART_IT_TypeDef;

/**
  * @}
  */

/* Exported constants --------------------------------------------------------*/
/* Exported macros ------------------------------------------------------------*/

/* Private macros ------------------------------------------------------------*/

/** @addtogroup UART_Private_Macros
  * @{
  */

/**
  * @brief Macro used by the assert function to check the different functions parameters.
  */

/**
 * @brief Macro used by the assert_param function in order to check the different sensitivity values for the MODEs
 * possible combination should be one of the following
 */
#define IS_UART_MODE_OK(Mode) \
  (((Mode) == (u8)UART_MODE_RX_ENABLE) || \
   ((Mode) == (u8)UART_MODE_RX_DISABLE) || \
   ((Mode) == (u8)UART_MODE_TX_ENABLE) || \
   ((Mode) == (u8)UART_MODE_TX_DISABLE) || \
   ((Mode) == (u8)UART_MODE_TXRX_ENABLE) || \
   ((Mode) == (u8)((u8)UART_MODE_TX_ENABLE|(u8)UART_MODE_RX_ENABLE)) || \
   ((Mode) == (u8)((u8)UART_MODE_TX_ENABLE|(u8)UART_MODE_RX_DISABLE)) || \
   ((Mode) == (u8)((u8)UART_MODE_TX_DISABLE|(u8)UART_MODE_RX_DISABLE)) || \
   ((Mode) == (u8)((u8)UART_MODE_TX_DISABLE|(u8)UART_MODE_RX_ENABLE)))

/**
 * @brief Macro used by the assert_param function in order to check the different sensitivity values for the WordLengths
 */
#define IS_UART_WORDLENGTH_OK(WordLength) \
  (((WordLength) == UART_WORDLENGTH_8D) || \
   ((WordLength) == UART_WORDLENGTH_9D))

/**
  * @brief Macro used by the assert_param function in order to check the different sensitivity values for the FLAGs
  */
#define IS_UART_FLAG_OK(Flag) \
  (((Flag) == UART_FLAG_TXE) || \
   ((Flag) == UART_FLAG_TC)  || \
   ((Flag) == UART_FLAG_RXNE) || \
   ((Flag) == UART_FLAG_IDLE) || \
   ((Flag) == UART_FLAG_OR) || \
   ((Flag) == UART_FLAG_NF) || \
   ((Flag) == UART_FLAG_FE) || \
   ((Flag) == UART_FLAG_PE) || \
   ((Flag) == UART_FLAG_SBK))
/**
  * @brief Macro used by the assert_param function in order to check the different sensitivity values for the FLAGs that can be cleared by writing 0
  */
#define IS_UART_CLEAR_FLAG_OK(Flag) \
  (((Flag) == UART_FLAG_RXNE))

/**
  * @brief Macro used by the assert_param function in order to check the different sensitivity values for the Interrupts
  */

#define IS_UART_CONFIG_IT_OK(Interrupt) \
  (((Interrupt) == UART_IT_PE) || \
   ((Interrupt) == UART_IT_TXE) || \
   ((Interrupt) == UART_IT_TC) || \
   ((Interrupt) == UART_IT_RXNE_OR ) || \
   ((Interrupt) == UART_IT_IDLE))

/**
  * @brief Macro used by the assert function in order to check the different sensitivity values for the pending bit
  */
#define IS_UART_GET_IT_OK(ITPendingBit) \
  (((ITPendingBit) == UART_IT_TXE)  || \
   ((ITPendingBit) == UART_IT_TC)   || \
   ((ITPendingBit) == UART_IT_RXNE) || \
   ((ITPendingBit) == UART_IT_IDLE) || \
   ((ITPendingBit) == UART_IT_OR)  || \
   ((ITPendingBit) == UART_IT_PE))

/**
  * @brief Macro used by the assert function in order to check the different sensitivity values for the pending bit that can be cleared by writing 0
  */
#define IS_UART_CLEAR_IT_OK(ITPendingBit) \
  (((ITPendingBit) == UART_IT_RXNE))
/**
  * @brief Macro used by the assert_param function in order to check the different sensitivity values for the WakeUps
  */
#define IS_UART_WAKEUP_OK(WakeUp) \
  (((WakeUp) == UART_WAKEUP_IDLELINE) || \
   ((WakeUp) == UART_WAKEUP_ADDRESSMARK))


/**
  * @brief Macro used by the assert_param function in order to check the different sensitivity values for the UART_StopBits
  */
#define IS_UART_STOPBITS_OK(StopBit) (((StopBit) == UART_STOPBITS_1) || \
                                       ((StopBit) == UART_STOPBITS_0_5) || \
                                       ((StopBit) == UART_STOPBITS_2) || \
                                       ((StopBit) == UART_STOPBITS_1_5 ))

/**
 * @brief Macro used by the assert_param function in order to check the different sensitivity values for the Paritys
 */
#define IS_UART_PARITY_OK(Parity) (((Parity) == UART_PARITY_NO) || \
                                    ((Parity) == UART_PARITY_EVEN) || \
                                    ((Parity) == UART_PARITY_ODD ))

/**
 * @brief Macro used by the assert_param function in order to check the maximum baudrate value
 */
#define IS_UART_BAUDRATE_OK(NUM) ((NUM) <= (u32)625000)


/**
 * @brief Macro used by the assert_param function in order to check the address of the UART or UART node
 */
#define UART_ADDRESS_MAX ((u8)16)
#define IS_UART_ADDRESS_OK(node) ((node) < UART_ADDRESS_MAX )

/**
  * @}
  */

/* Exported functions ------------------------------------------------------- */

/** @addtogroup UART_Exported_Functions
  * @{
  */

void UART_Reset(void);
void UART_Init(u32 BaudRate,
               UART_WordLength_TypeDef WordLength,
               UART_StopBits_TypeDef StopBits,
               UART_Parity_TypeDef Parity,
               UART_PIN_TypeDef PIN,
               UART_Mode_TypeDef Mode);
                
void UART_Cmd(FunctionalState NewState);
void UART_ITConfig(UART_IT_TypeDef UART_IT, FunctionalState NewState);
u8 UART_IsITEnabled(UART_IT_TypeDef UART_IT);
void UART_WakeUpConfig(UART_WakeUp_TypeDef UART_WakeUp);
void UART_ReceiverWakeUpCmd(FunctionalState NewState);
u8 UART_ReceiveData8(void);
u16 UART_ReceiveData9(void);
void UART_SendData8(u8 Data);
void UART_SendData9(u16 Data);
void UART_SendBreak(void);
FlagStatus UART_GetFlagStatus(UART_Flag_TypeDef UART_FLAG);
void UART_ClearFlag(UART_Flag_TypeDef UART_FLAG);
ITStatus UART_GetITStatus(UART_IT_TypeDef UART_IT);
void UART_ClearITPendingBit(UART_IT_TypeDef UART_IT);

/**
  * @}
  */

#endif /* __STLUX_UART_H */

/******************* (C) COPYRIGHT 2015 STMicroelectronics *****END OF FILE****/
