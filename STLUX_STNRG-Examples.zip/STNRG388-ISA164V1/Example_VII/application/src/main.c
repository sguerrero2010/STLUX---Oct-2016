#include "stlux.h"
#include "stlux_clk.h"
#include "stlux_smed.h"
#include "stlux_acu.h"

//Uncomment in case you want to use the automatically generated fuction My_ACU_Init() to initialize the ACU;
extern void My_ACU_Init();

void main ( void )
{
    // ENABLE LSI Clock
    CLK_LSICmd(ENABLE);

    // work with HSI at maximum frequency
    CLK_HSIPrescalerConfig(CLK_PRESCALER_HSIDIV1);
        
    // enable PLL - Used by the SMED5
    CLK_PLLCmd(ENABLE);
    while((CLK->PLLR & CLK_PLLR_LOCKP) == 0);
    
    // initialize Comparators    
    My_ACU_Init();

    // initialize the SMED registers
    SMED_Init();    
    
    // Start SMED5, then SMED2 and SMED3
    SMED_Start(SMED5);
    wfi();
    SMED_Start(SMED2);
    SMED_Start(SMED3);

    while (1) {
        wfi(); // noting to do, SMED5 running without CPU control
    }
}
