/**	\file stlux_optionbytes.c
******************************************************************************************
* 
*	\brief	STLUX Option Bytes Definitions
*
*	This file contains the value of the Option Bytes registers.
*	The definitions are used by the RAISONANCE IDE to initialize the Option
*	bytes contents during the loading phase.
******************************************************************************************
*/
#ifdef _RAISONANCE_ 

#include "stlux.h"

//#ifdef _STNRG388A_
at 0x4800 CONST const	u8  ROP			= 0x00;
at 0x4801 CONST const	u16	UBC			= 0x00FF;
at 0x4803 CONST const	u16	GENCFG		= 0x00FF;
at 0x4805 CONST const	u16	MISCUOPT	= 0x28D7;
at 0x4807 CONST const	u16	CLKCTL		= 0x8976;
at 0x4809 CONST const	u16	HSESTAB		= 0x00FF;
at 0x480B CONST const	u16	RES1		= 0x00FF;
at 0x480D CONST const	u16	WAITSTATE	= 0x00FF;
at 0x480F CONST const	u16	AFR_IOMXP0	= 0x00FF;
at 0x4811 CONST const	u16	AFR_IOMXP1	= 0x3FC0;
at 0x4813 CONST const	u16	AFR_IOMXP2	= 0x7A85;
at 0x4815 CONST const	u16	MSC_OPT0	= 0x11EE;
at 0x4817 CONST const	u8	RES2[103];
at 0x487E CONST const	u16	OPTBL		= 0x55AA;
//#endif //_STLUX385A_

#endif //_RAISONANCE_ 



#ifdef _COSMIC_ 
#include "stlux.h"
#pragma section const {optbytes}
const	u8		ROP =           0x00;   // Memory read out protection
const	u16		USB =           0x00FF; // User boot code register
const	u16		GENCFG =        0x00FF; // General configuration register
const	u16		MISCUOPT =      0x28D7; // Miscellaneous configuration register
const	u16		CLKCTL =        0x8976; // Clock configuration register
const	u16		HSESTAB =       0x00FF; // HSE Clock stabilization register
const	u16		ENHFEAT =       0x00FF; // Enable BscTimx and ADC MFlush Features 
const	u16		WAITSTATE =     0x00FF; // Flash wait state register
const	u16		AFR_IOMXP0 =    0x00FF;	// Alternative Port 0 configuration register
const	u16		AFR_IOMXP1 =    0x3FC0;	// Alternative Port 1 configuration register
const	u16		AFR_IOMXP2 =    0x7A85;	// Alternative Port 2 configuration register
const	u16		MSC_OPT0 =      0x11EE;	    // Miscellaneous configuration register 2
#pragma section const {}
#pragma section const {optbl}
const	u16		OPTBL =         0x55AA; // Boot Loading not allowed
#pragma section const {}
#endif //_COSMIC_ 

