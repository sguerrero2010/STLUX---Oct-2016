/**
  ******************************************************************************
  * @file     stlux_it.c
  * @brief    Main Interrupt Service Routines.
  * @author   STMicroelectronics
  * @version V2.0
  * @date 27/10/2015
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  ******************************************************************************
  */ 

/* this file is not part of the library and should be modified for the application use */

/* Includes ------------------------------------------------------------------*/
#include "stlux_it.h"
#include "stlux_btm.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/* Public functions ----------------------------------------------------------*/

/**
  * @brief  TRAP interrupt routine
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER_TRAP(TRAP_IRQHandler)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
}

/**
  * @brief  Non Maskable interrupt routine
  * @param None
  * @retval
  * None
  */
INTERRUPT_HANDLER(NMI_IRQHandler, 0)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
   // MSC->STSP1 |= 0x20; //AUXTIM ISR Clear - To be enabled if NMI TYPE is set
    
}

/**
  * @brief  Auto Wake Up Interrupt routine
  * @param None
  * @retval
  * None
  */
INTERRUPT_HANDLER(AWU_IRQHandler, 1)	
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
}

/**
  * @brief  Clock Controller Interrupt routine
  * @param None
  * @retval
  * None
  */
INTERRUPT_HANDLER(CLK_IRQHandler, 2)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
}


/**
  * @brief External Interrupt PORT0 Interruption routine.
  * @par Parameters:
  * None
  * @retval
  * None
  */
INTERRUPT_HANDLER(PORT0_IRQHandler,3)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
	return;	
}
/**
  * @brief External Interrupt PORT0 Interruption routine.
  * @par Parameters:
  * None
  * @retval
  * None
  */
INTERRUPT_HANDLER(PORT1_IRQHandler,4)   //Auxiliary/Basic Timer
{
    /* In order to detect unexpected events during development,
        it is recommended to set a breakpoint on the following instruction.

    if ((MSC->STSP1 & 0x01) != 0){   //BSCTIM0 IT 
        BTM_ITClear(BTM_0);
        GPIO0->ODR ^= 0x10; //Toggle red led
    }
   */
    return;	
}


INTERRUPT_HANDLER(PORT2_IRQHandler,5){
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
	return;	
}

INTERRUPT_HANDLER(SMED0_IRQHandler,6)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
return; 
}

INTERRUPT_HANDLER(SMED1_IRQHandler,7)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
return; 
}

#if defined(_STNRG388A_) || defined(_STNRG328A_) || defined(_STNRG288A_)
INTERRUPT_HANDLER(INPP3_IRQHandler,8)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
return; 
}
#endif //STNGR

INTERRUPT_HANDLER(SMED2_IRQHandler,15)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
return; 
}

INTERRUPT_HANDLER(SMED3_IRQHandler,16)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
return; 
}

INTERRUPT_HANDLER(UART_TX_IRQHandler,17)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
}

INTERRUPT_HANDLER(UART_RX_IRQHandler,18)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
	return;
}

INTERRUPT_HANDLER(I2C_IRQHandler,19)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
	return;
}

INTERRUPT_HANDLER(ADC_IRQHandler,22)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
	return;
}

INTERRUPT_HANDLER(STMR_IRQHandler,23) 		/* irq23 - STMR Update interrupt */
{
  //STMR->SR1 = 0x00;	// clear pending interrupt
  
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
    
    return;
}


INTERRUPT_HANDLER(FLASH_IRQHandler,24)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
	return;
}

INTERRUPT_HANDLER(DALI_IRQHandler,25)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
	return;
}

INTERRUPT_HANDLER(SMED4_IRQHandler,26)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
return; 
}

INTERRUPT_HANDLER(SMED5_IRQHandler,27)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
return; 
}

/**
  * @}
  */

/******************* (C) COPYRIGHT 2015 STMicroelectronics *****END OF FILE****/
