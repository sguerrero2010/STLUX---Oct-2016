#include "stlux.h"
#include "stlux_clk.h"
#include "stlux_btm.h"
#include "stlux_smed.h"
#include "stlux_acu.h"

//Uncomment in case you want to use the automatically generated fuction My_ACU_Init() to initialize the ACU;
extern void My_ACU_Init();

void main ( void )
{
    // ENABLE LSI Clock
    CLK_LSICmd(ENABLE);

    // work with HSI at maximum frequency
    CLK_HSIPrescalerConfig(CLK_PRESCALER_HSIDIV1);
        
    // enable PLL - Used by the SMED5
    CLK_PLLCmd(ENABLE);
    while((CLK->PLLR & CLK_PLLR_LOCKP) == 0);
    
    // Configure Basic Timer 0 (BSCTIM0)
//    BTM_Config(BTM_0, CLK_BTM_SOURCE_LSI, 255, 31, BTM_IT_LEV_HIGH, BTM_IT_SEL_EDGE, BTM_IT_TYPE_IRQ);
    
#if ACU_LIBRARY_SETUP
    // initialize Comparators    
    ACU_Enable(CMP_2, ACU_CPx_SEL_INT);
    ACU_SetCompareLevel(CMP_2, DACIN_410mV);    //Set maximum voltage level to 410mV
    ACU_SetHysteresisLevel(CMP_2,HYSTUP_V_CODE4); //Set maximum voltage level hysteresis to about 444mV

    ACU_Enable(CMP_3, ACU_CPx_SEL_INT);
    ACU_SetCompareLevel(CMP_3, DACIN_246mV);    //Set minimum voltage level hysteresis to 223mV
    ACU_SetHysteresisLevel(CMP_3,HYSTDN_V_CODE4); //Set minimum voltage level hysteresis to about 200mV
#else
    //Alternativery the automatically generated fuction My_ACU_Init() can be used to initialize the ACU;
    My_ACU_Init();
#endif
    
    // initialize the SMED registers
    SMED_Init();    
    
    // Start the SMED 5
    SMED_Start(SMED5);

//    BTM_ITConfig(BTM_0, ENABLE); //Enable Basic Timer 0 (BSCTIM0) Interrupt
//    BTM_Cmd(BTM_0, ENABLE);      //Enable Basic Timer 0 (BSCTIM0)
        
    while (1) {
        // wfi(); // noting to do, SMED5 running without CPU control
        nop();
        /*if (ACU_Read(CMP_3))
            GPIO_WriteHigh(GPIO0, GPIO_PIN_2);
        else
            GPIO_WriteLow(GPIO0, GPIO_PIN_2);
        */
    }
}
