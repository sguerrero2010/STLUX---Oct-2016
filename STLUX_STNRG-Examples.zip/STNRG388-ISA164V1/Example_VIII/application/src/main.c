#include "stlux.h"
#include "stlux_clk.h"
#include "stlux_smed.h"
#include "stlux_acu.h"
#include "stlux_adc.h"
#include "stlux_flash.h"

//Uncomment in case you want to use the automatically generated fuction My_ACU_Init() to initialize the ACU;
extern void My_ACU_Init();
extern void My_ADC_Init();

void main ( void )
{
#ifndef _RAISONANCE_

    FLASH->CR2  = 0x80; //FLASH_CR2_OPT;
    FLASH->NCR2 = 0x7F; //FLASH_NCR2_NOPT;
    
    Unlock_eeprom_data_area();
    
    // wait previous write operation, if pending
    while(!(FLASH->IAPSR & FLASH_IAPSR_HVOFF));
    OPT->CLKCTL = 0xa9;

    // wait previous write operation, if pending
    while(!(FLASH->IAPSR & FLASH_IAPSR_HVOFF));
    OPT->NCLKCTL = 0x56;

    // wait previous write operation, if pending
    while(!(FLASH->IAPSR & FLASH_IAPSR_HVOFF));
    OPT->AFR_IOMXP2 = 0x3a;

    // wait previous write operation, if pending
    while(!(FLASH->IAPSR & FLASH_IAPSR_HVOFF));
    OPT->nAFR_IOMXP2 = 0xc5;

    // wait previous write operation, if pending
    while(!(FLASH->IAPSR & FLASH_IAPSR_HVOFF));
   
    Lock_eeprom_data_area();
    
#endif  //_RAISONANCE_
  
    // ENABLE LSI Clock
    CLK_LSICmd(ENABLE);

    // work with HSI at maximum frequency
    CLK_HSIPrescalerConfig(CLK_PRESCALER_HSIDIV1);
        
    // enable PLL - Used by the SMED5
    CLK_PLLCmd(ENABLE);
    while((CLK->PLLR & CLK_PLLR_LOCKP) == 0);
    
    // initialize Comparators    
    My_ACU_Init();
    
    // enable ADC clock
    CLK_PeripheralClockConfig(CLK_PERIPHERAL_ADC, ENABLE);

    // initialize ADC
    CLK_ADCConfig(CLK_ADC_SOURCE_PLL, 1);
    ADC_PowerUp();

    // data right aligned - circular mode enabled - flush sequencer fifo        
    //ADC_Init(ADC_ConvMode_SEQUENCE, ADC_DataFormat_H2L8);
    
    // initialize sequencer for first conversion cycle
    //ADC_Sequencer(ADC_CHANNEL_5, ADC_GAIN_16);
 
    My_ADC_Init();
          
    ADC_Interrupt(ADC_IntEndConvMode_EN, ADC_IntEndSeqMode_DIS, ADC_IntSeqFull_DIS);
        
    // start first ADC conversion
    ADC_Start();    
    
    // initialize the SMED registers
    SMED_Init();    
    
    // Start SMED5, then SMED2 and SMED3
    SMED_Start(SMED5);
    
    //rim();

    while (1) {
        wfi(); // noting to do, SMED5 running without CPU control
    }
}
