#include "stlux.h"
#include "stlux_clk.h"
#include "stlux_smed.h"

extern void SMED_Init();

void main ( void )
{
    // work with HSI at maximum frequency
    CLK_HSIPrescalerConfig(CLK_PRESCALER_HSIDIV1);
        
    // enable PLL - Used by the SMED
    CLK_PLLCmd(ENABLE);

    while((CLK->PLLR & CLK_PLLR_LOCKP) == 0);

    // initialize the SMED registers
    SMED_Init();

    // Start the SMED 0
    SMED_Start(SMED0);

    while (1) {
        nop(); // noting to do, SMED0 running without CPU control
    }
}
