/*	BASIC INTERRUPT VECTOR TABLE FOR STM8 devices
 *	Copyright (c) 2007 STMicroelectronics
 */



typedef void @far (*interrupt_handler_t)(void);

struct interrupt_vector {
	unsigned char interrupt_instruction;
	interrupt_handler_t interrupt_handler;
};

#define INTERRUPT_HANDLER(a,b) @far @interrupt void a(void)

INTERRUPT_HANDLER(NonHandledInterrupt,1)
{
	/* in order to detect unexpected events during development, 
	   it is recommended to set a breakpoint on the following instruction
	*/
	//{_asm("nop\n");};
    return;
}


extern 	void _stext();     									/* startup routine */
// declare here the interrupt entry label
extern	void AWU_ISR();								        /* AWU int routine */ 
extern	void P0_ISR();							            /* PORT 0 int routine */ 
extern	void CCO_INT();							            /* PORT 1 int routine */ 
extern	void PORT2();							            /* PORT 2 int routine */ 
extern	void SMED0_ISR();						        	/* SMED0  int routine */ 
extern	void SMED1_ISR();						        	/* SMED1  int routine */ 
extern	void SMED2_ISR();						        	/* SMED2  int routine */ 
extern	void SMED3_ISR();				        			/* SMED3  int routine */ 
extern	void SMED4_ISR();		        					/* SMED4  int routine */ 
extern	void SMED5_ISR();       							/* SMED5  int routine */ 
extern	void UART_TX_ISR();	        						/* UART_TX  int routine */ 
extern	void UART_RX_ISR();			        				/* UART_RX  int routine */ 
extern	void ADC_ISR();			        					/* ADC      int routine */ 
extern	void STMR_ISR();								    /* STMR     int routine */ 
extern	void Dali_Int();								    /* DALI     int routine */ 
extern  void NonHandledInterrupt();


#pragma section const {vector}

struct interrupt_vector const _vectab[] = {
    {0x82, (interrupt_handler_t)_stext}, 					/* reset */
    {0x82, NonHandledInterrupt}, 							/* trap  */
    {0x82, NonHandledInterrupt}, 							/* NMI irq0  */
    {0x82, NonHandledInterrupt}, 	       	                /* AWU irq1  */
    {0x82, NonHandledInterrupt},                            /* CKC irq2  */
    {0x82, NonHandledInterrupt}, 	                        /* PORT 0 irq3  */
    {0x82, NonHandledInterrupt},                            /* AUXTIM irq4  */
    {0x82, NonHandledInterrupt},                            /* PORT2 irq5  */
    {0x82, NonHandledInterrupt},                            /* SMED0  irq6   */
    {0x82, NonHandledInterrupt},                            /* SMED1  irq7   */
    {0x82, NonHandledInterrupt},                            /* irq8  */
    {0x82, NonHandledInterrupt},                            /* irq9  */
    {0x82, NonHandledInterrupt},                            /* irq10 */
    {0x82, NonHandledInterrupt},                            /* irq11 */
    {0x82, NonHandledInterrupt},                            /* irq12 */
    {0x82, NonHandledInterrupt},                            /* irq13 */
    {0x82, NonHandledInterrupt},                            /* irq14 */
    {0x82, NonHandledInterrupt},                            /* SMED 2 irq15  */
    {0x82, NonHandledInterrupt}, 	                        /* SMED 3 irq16  */
    {0x82, NonHandledInterrupt}, 	                        /* UART_TX irq17 */
    {0x82, NonHandledInterrupt},                            /* UART_RX irq18 */
    {0x82, NonHandledInterrupt},                            /* I2C irq19 */
    {0x82, NonHandledInterrupt},                            /* irq20 */
    {0x82, NonHandledInterrupt},                            /* irq21 */
    {0x82, NonHandledInterrupt},       			            /* ADC  irq22    */
    {0x82, NonHandledInterrupt}, 		                    /* STMR irq23    */
    {0x82, NonHandledInterrupt},                            /* FLASH irq24 */
    {0x82, NonHandledInterrupt},                            /* DALI  irq25   */
    {0x82, NonHandledInterrupt}, 		                    /* SMED4 irq26   */
    {0x82, NonHandledInterrupt},		                    /* SMED5 irq27   */
    {0x82, NonHandledInterrupt},                            /* irq28 */
    {0x82, NonHandledInterrupt},                            /* irq29 */
};
//#endif
