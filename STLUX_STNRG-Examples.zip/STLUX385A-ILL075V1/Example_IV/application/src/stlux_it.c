/**
  ******************************************************************************
  * @file     stlux_it.c
  * @author   STMicroelectronics
  * @version  V1.0
  * @date     17/01/2014
  * @brief    Main Interrupt Service Routines.
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  ******************************************************************************
  */ 

/* this file is not part of the library and should be modified for the application use */

/* Includes ------------------------------------------------------------------*/
#include "stlux_it.h"
#include "adc.h"
#include "stlux_smed.h"

extern vu16 Vres;
extern vu16 Vavg;
extern vu16 Vsamples[(1<<N_SAMPLES_EXP)];
extern vu32 Acc;
extern vu8  idx;
extern vu8  Run_SMED;

extern vu16  init_delay;

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
#define INIT_TRANS 1024 //Initial delay to avoid startup noise

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/* Public functions ----------------------------------------------------------*/

/**
  * @brief  TRAP interrupt routine
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER_TRAP(TRAP_IRQHandler)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
}

/**
  * @brief  Non Maskable interrupt routine
  * @param None
  * @retval
  * None
  */
INTERRUPT_HANDLER(NMI_IRQHandler, 0)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
}

/**
  * @brief  Auto Wake Up Interrupt routine
  * @param None
  * @retval
  * None
  */
INTERRUPT_HANDLER(AWU_IRQHandler, 1)	
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
}

/**
  * @brief  Clock Controller Interrupt routine
  * @param None
  * @retval
  * None
  */
INTERRUPT_HANDLER(CLK_IRQHandler, 2)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
}


/**
  * @brief External Interrupt PORT0 Interruption routine.
  * @par Parameters:
  * None
  * @retval
  * None
  */
INTERRUPT_HANDLER(PORT0_IRQHandler,3)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
	return;	
}
/**
  * @brief External Interrupt PORT0 Interruption routine.
  * @par Parameters:
  * None
  * @retval
  * None
  */
INTERRUPT_HANDLER(AUXTIM_IRQHandler,4)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
	return;	
}


INTERRUPT_HANDLER(PORT2_IRQHandler,5){
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
	return;	
}

INTERRUPT_HANDLER(SMED0_IRQHandler,6)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
return; 
}

INTERRUPT_HANDLER(SMED1_IRQHandler,7)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
return; 
}

INTERRUPT_HANDLER(SMED2_IRQHandler,15)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
return; 
}

INTERRUPT_HANDLER(SMED3_IRQHandler,16)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
return; 
}

INTERRUPT_HANDLER(UART_TX_IRQHandler,17)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
}

INTERRUPT_HANDLER(UART_RX_IRQHandler,18)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
	return;
}

INTERRUPT_HANDLER(I2C_IRQHandler,19)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
	return;
}

INTERRUPT_HANDLER(ADC_IRQHandler,22)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
	return;
}

INTERRUPT_HANDLER(STMR_IRQHandler,23) 		/* irq23 - STMR Update interrupt */
{
    u16 Ton;

    STMR->SR1 = 0x00;	// clear pending interrupt
    ADC_ISR();			// execute regulation functions
    
    Acc -= Vsamples[idx];
    Acc += Vres;
    Vsamples[idx] = Vres;
    
    if (init_delay < INIT_TRANS){
      init_delay++;
    }
    else{
        Vavg = (Acc >> N_SAMPLES_EXP);
    
        if ((Vavg >= LO_TH)&&(Vavg <= HI_TH)&&(Run_SMED==0x00)){
            Run_SMED = 1;
            SMED_Start(SMED0);
        }
    
        if (((Vavg < LO_TH)||(Vavg > HI_TH))&&(Run_SMED)){
            Run_SMED = 0;
            SMED_Stop(SMED0);
        }
    
        if (Run_SMED){
            Ton = (((u32)Vavg * 0x165) >> 7) - 0x199;

            SMED_SetTime(SMED0, SMED_T0, Ton);
            SMED_ValidateTimeValues(SMED0, SMED_T0_VAL);      
        }    
    }
    idx++;
    idx &= ((1<<N_SAMPLES_EXP)-1);

    return;
}


INTERRUPT_HANDLER(FLASH_IRQHandler,24)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
	return;
}

INTERRUPT_HANDLER(DALI_IRQHandler,25)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
	return;
}

INTERRUPT_HANDLER(SMED4_IRQHandler,26)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
return; 
}

INTERRUPT_HANDLER(SMED5_IRQHandler,27)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
return; 
}

/**
  * @}
  */

/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
