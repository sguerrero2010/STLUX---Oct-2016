#include "stlux.h"
#include "stlux_clk.h"
#include "stlux_smed.h"
#include "stlux_gpio.h"
#include "stlux_stmr.h"
#include "adc.h"

#define	START_TICK			100		// timer period
#define X0_START_TH                     64

extern void SMED_Init();

/**
******************************************************************************************
*	\brief STMR Initialization
* 
*	The STMR is set to generate an interrupt at a 10KHz frequency
******************************************************************************************
*/
void STMR_Init(void)
{
    // enable STMR clock
    CLK_PeripheralClockConfig(CLK_PERIPHERAL_STMR, ENABLE);
        
    // disable timer
    STMR_Cmd(DISABLE);
    
    // update event disable
    STMR_UpdateDisableConfig(ENABLE);
    
    // initial value for startup phase
    // prescaling by 4 
    STMR_TimeBaseInit(STMR_PRESCALER_4, START_TICK);
    
    // enable counter
    STMR_ARRPreloadConfig(ENABLE);
    STMR_Cmd(ENABLE);
    // update event disable
    STMR_UpdateDisableConfig(DISABLE);
    
    // enable interrupt
    STMR_ITConfig(STMR_IT_UPDATE, ENABLE);
}


void main ( void )
{
    // work with HSI at maximum frequency
    CLK_HSIPrescalerConfig(CLK_PRESCALER_HSIDIV1);
        
    // enable PLL - Used by the SMED
    CLK_PLLCmd(ENABLE);

    while((CLK->PLLR & CLK_PLLR_LOCKP) == 0);
    
    // initialize the GPIO registers
    GPIO_Init(GPIO0, GPIO_PIN_2, GPIO_MODE_OUT_PP_HIGH_FAST);

    // initialize the SMED registers
    SMED_Init();
    
    // initialize the ADC registers
    ADC_ISR_Init();
    
    STMR_Init();
    
    rim();

    while (1) {
        wfi(); // noting to do, SMED0 running without CPU control
    }
}
