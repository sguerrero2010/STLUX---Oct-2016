/**	\file adc.c
******************************************************************************************
* 
*	\brief	ADC Functions
*
*	Initialization and handling of the ADC, used to sample the Vcc voltage,
*	The ADC is configured to work at gain 1.6 at the maximum available frequency.
******************************************************************************************
*/
#include "adc.h"

// Local defines

// Local accessible variables
//vu8 adc_int_cnt;
vu16 Vres;
vu16 Vavg;
vu16 Vsamples[(1<<N_SAMPLES_EXP)];
vu32 Acc;
vu8  idx;
vu8  Run_SMED;
vu16  init_delay;


/**
******************************************************************************************
*	\brief ADC ISR function
*
*	The command is called by the STMR interrupt function to maintain the ADC
*	sampling frequency.
*	At each interrupt the sampled variables are acquired.
******************************************************************************************
*/

void ADC_ISR(void)
{
    Vres = ADC_Measure(ADC_CHANNEL_7, ADC_GAIN_16);
}

/**
******************************************************************************************
*	\brief ADC Initialization
*
*	The ADC is used to sample the analog variables used by regulation algorithms.
*	The ADC is configured to work at the maximum possible speed of 6 MHz using
*	the PLL/8 as source clock.
******************************************************************************************
*/

void ADC_ISR_Init(void)
{
	// enable ADC clock
        CLK_PeripheralClockConfig(CLK_PERIPHERAL_ADC, ENABLE);
	
	// select PLL/8 source clock divided by 2 (96/8/2=6MHz)
        CLK_ADCConfig(CLK_ADC_SOURCE_PLL, 1);

        ADC_PowerUp();

	// data right aligned
        ADC_Init(ADC_ConvMode_SEQUENCE, ADC_DataFormat_H2L8);
          
        // clear counters
        Acc = 0;
        for (idx=0; idx<(1<<N_SAMPLES_EXP); idx++){
            Vsamples[idx]=0;
        }
        
        init_delay = 0;
        idx = 0;
        Run_SMED = 0;
}

/**
******************************************************************************************
*	\brief Stop ADC
*
*	The function stops the ADC sampling clearing the sequencer and moving
*	back the ADC to the power down state.
******************************************************************************************
*/

void ADC_ISR_Stop(void)
{
u8 cnt;
	// stop the sequencer
        ADC_Stop();
	
        for(cnt = 0;cnt < 48;cnt++) {
		nop();
	}
	
        ADC_PowerDown(); // powerdown the ADC
}
