/*	BASIC INTERRUPT VECTOR TABLE FOR STM8 devices
 *	Copyright (c) 2007 STMicroelectronics
 */



typedef void @far (*interrupt_handler_t)(void);

struct interrupt_vector {
	unsigned char interrupt_instruction;
	interrupt_handler_t interrupt_handler;
};

#define INTERRUPT_HANDLER(a,b) @far @interrupt void a(void)

INTERRUPT_HANDLER(NonHandledInterrupt,1)
{
	/* in order to detect unexpected events during development, 
	   it is recommended to set a breakpoint on the following instruction
	*/
	//{_asm("nop\n");};
    return;
}


extern 	void _stext();     									/* startup routine */
// declare here the interrupt entry label
extern	void STMR_IRQHandler();


#pragma section const {vector}

struct interrupt_vector const _vectab[] = {
    {0x82, (interrupt_handler_t)_stext}, 					/* reset */
    {0x82, NonHandledInterrupt}, 							/* trap  */
    {0x82, NonHandledInterrupt}, 							/* NMI irq0  */
    {0x82, NonHandledInterrupt}, 	       	                /* AWU irq1  */
    {0x82, NonHandledInterrupt},                            /* CKC irq2  */
    {0x82, NonHandledInterrupt}, 	                        /* PORT 0 irq3  */
    {0x82, NonHandledInterrupt},                            /* AUXTIM irq4  */
    {0x82, NonHandledInterrupt},                            /* PORT2 irq5  */
    {0x82, NonHandledInterrupt},                            /* SMED0  irq6   */
    {0x82, NonHandledInterrupt},                            /* SMED1  irq7   */
    {0x82, NonHandledInterrupt},                            /* irq8  */
    {0x82, NonHandledInterrupt},                            /* irq9  */
    {0x82, NonHandledInterrupt},                            /* irq10 */
    {0x82, NonHandledInterrupt},                            /* irq11 */
    {0x82, NonHandledInterrupt},                            /* irq12 */
    {0x82, NonHandledInterrupt},                            /* irq13 */
    {0x82, NonHandledInterrupt},                            /* irq14 */
    {0x82, NonHandledInterrupt},                            /* SMED 2 irq15  */
    {0x82, NonHandledInterrupt}, 	                        /* SMED 3 irq16  */
    {0x82, NonHandledInterrupt}, 	                        /* UART_TX irq17 */
    {0x82, NonHandledInterrupt},                            /* UART_RX irq18 */
    {0x82, NonHandledInterrupt},                            /* I2C irq19 */
    {0x82, NonHandledInterrupt},                            /* irq20 */
    {0x82, NonHandledInterrupt},                            /* irq21 */
    {0x82, NonHandledInterrupt},       			            /* ADC  irq22    */
    {0x82, (interrupt_handler_t)STMR_IRQHandler},           /* STMR irq23    */
    {0x82, NonHandledInterrupt},                            /* FLASH irq24 */
    {0x82, NonHandledInterrupt},                            /* DALI  irq25   */
    {0x82, NonHandledInterrupt}, 		                    /* SMED4 irq26   */
    {0x82, NonHandledInterrupt},		                    /* SMED5 irq27   */
    {0x82, NonHandledInterrupt},                            /* irq28 */
    {0x82, NonHandledInterrupt},                            /* irq29 */
};
//#endif
