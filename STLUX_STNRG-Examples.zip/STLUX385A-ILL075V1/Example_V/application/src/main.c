#include "stlux.h"
#include "stlux_clk.h"
#include "stlux_smed.h"
#include "stlux_acu.h"

void main ( void )
{
    // work with HSI at maximum frequency
    CLK_HSIPrescalerConfig(CLK_PRESCALER_HSIDIV1);
        
    // enable PLL - Used by the SMED5
    CLK_PLLCmd(ENABLE);

    while((CLK->PLLR & CLK_PLLR_LOCKP) == 0);
   
#if 1
    // initialize Comparators
    ACU_Init();
    ACU_Enable(CMP_2, ACU_CP3_SEL_INT);
    ACU_SetCompareLevel(CMP_2, DACIN_410mV);    //Set maximum voltage level to 410mV

    ACU_Enable(CMP_3, ACU_CP3_SEL_INT);
    ACU_SetCompareLevel(CMP_3, DACIN_246mV);    //Set maximum voltage level to 246mV
#else
    My_ACU_Init();
#endif

    // initialize the SMED registers
    SMED_Init();
    
    SMED_Start(SMED5);

    // Start the SMED 5
    while (1) {
        nop(); // noting to do, SMED5 running without CPU control
    }
}
