/**
 ******************************************************************************
 * @file    main.c
 * @author  STMicroelectronics
 * @version V1.0
 * @date    17/01/2014
 * @brief   Main code for STLux four channel LED demo board
 ******************************************************************************
 *
 * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
 * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
 * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
 * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
 * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
 * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
 *
 * <h2><center>&copy; COPYRIGHT 2012 STMicroelectronics</center></h2>
 ******************************************************************************
 */

#include "stlux.h"
#include "stlux_clk.h"
#include "stlux_atm.h"
#include "stlux_smed.h"
#include "stlux_stmr.h"
#include "adc.h"

#define	START_TICK			200		// timer period (50 �s)
#define X0_START_TH                     64

extern void SMED_Init();


/**
******************************************************************************************
*	\brief STMR Initialization
* 
*	The STMR is initially set for a fixed period used during the startup phase.
*	The STMR is then updated to generate an interrupt every 1/256 of the mains period
*	during the running phase.
*	At run time the value is automatically updated inside the SMED3 interrupt to
*	compensate for mains variations and for frequency changes (50/60 Hz).
******************************************************************************************
*/
void STMR_Init(void)
{
    // enable STMR clock
    CLK_PeripheralClockConfig(CLK_PERIPHERAL_STMR, ENABLE);
        
    // disable timer
    STMR_Cmd(DISABLE);
    
    // update event disable
    STMR_UpdateDisableConfig(ENABLE);
    
    // initial value for startup phase
    // prescaling by 4 
    STMR_TimeBaseInit(STMR_PRESCALER_4, START_TICK);
    
    // enable counter
    STMR_ARRPreloadConfig(ENABLE);
    STMR_Cmd(ENABLE);
    // update event disable
    STMR_UpdateDisableConfig(DISABLE);
    
    // enable interrupt
    STMR_ITConfig(STMR_IT_UPDATE, ENABLE);
}


void main ( void )
{
    // work with HSI at maximum frequency
    CLK_HSIPrescalerConfig(CLK_PRESCALER_HSIDIV1);
        
    // enable PLL - Used by the SMED
    CLK_PLLCmd(ENABLE);

    while((CLK->PLLR & CLK_PLLR_LOCKP) == 0);

    // initialize the SMED registers
    SMED_Init();
    
    ATM_Config(CLK_OUTPUT_HSI, 8, ATM_IT_LEV_HIGH, ATM_IT_SEL_EDGE, ATM_IT_TYPE_IRQ);
    ATM_ITConfig(ENABLE);
    
    // initialize the ADC registers
    ADC_ISR_Init();
    
    STMR_Init();
    
    rim();
    
    while (x0in < X0_START_TH); // Wait for x0in to be greater than threshold to start SMED0
        
    // Start the SMED 0
    SMED_Start(SMED0);

    while (1) {
        nop(); // noting to do, SMED0 running without CPU control
    }
}
