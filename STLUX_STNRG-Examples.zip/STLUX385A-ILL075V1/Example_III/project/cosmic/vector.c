/*	BASIC INTERRUPT VECTOR TABLE FOR STM8 devices
 *	Copyright (c) 2007 STMicroelectronics
 */



typedef void @far (*interrupt_handler_t)(void);

struct interrupt_vector {
	unsigned char interrupt_instruction;
	interrupt_handler_t interrupt_handler;
};

#define INTERRUPT_HANDLER(a,b) @far @interrupt void a(void)

INTERRUPT_HANDLER(NonHandledInterrupt,1)
{
	/* in order to detect unexpected events during development, 
	   it is recommended to set a breakpoint on the following instruction
	*/
	//{_asm("nop\n");};
	//{_asm("halt\n");};
    return;
}


extern 	void _stext();     									/* startup routine */
// declare here the interrupt entry label
extern	void TRAP_IRQHandler();
extern	void NMI_IRQHandler();
extern	void AWU_IRQHandler();
extern	void CLK_IRQHandler();
extern	void PORT0_IRQHandler();
extern	void PORT1_IRQHandler();
extern	void PORT2_IRQHandler();
extern	void SMED0_IRQHandler();
extern	void SMED1_IRQHandler();
#if defined(_STNRG388A_) || defined(_STNRG328A_) || defined(_STNRG288A_)
extern	void INPP3_IRQHandler();
#endif
extern	void SMED2_IRQHandler();
extern	void SMED3_IRQHandler();
extern	void UART_TX_IRQHandler();
extern	void UART_RX_IRQHandler();
extern	void I2C_IRQHandler();
extern	void ADC_IRQHandler();
extern	void STMR_IRQHandler();
extern	void FLASH_IRQHandler();
extern	void DALI_IRQHandler();
extern	void SMED4_IRQHandler();
extern	void SMED5_IRQHandler();


#pragma section const {vector}

struct interrupt_vector const _vectab[] = {
    {0x82, (interrupt_handler_t)_stext}, 					/* reset */
    {0x82, (interrupt_handler_t)TRAP_IRQHandler}, 			/* trap  */
    {0x82, (interrupt_handler_t)NMI_IRQHandler}, 			/* NMI irq0  */
    {0x82, (interrupt_handler_t)AWU_IRQHandler},            /* AWU irq1  */
    {0x82, (interrupt_handler_t)CLK_IRQHandler},            /* CKC irq2  */
    {0x82, (interrupt_handler_t)PORT0_IRQHandler},          /* PORT 0 irq3  */
    {0x82, (interrupt_handler_t)PORT1_IRQHandler},          /* AUXTIM irq4  */
    {0x82, (interrupt_handler_t)PORT2_IRQHandler},          /* PORT2 irq5  */
    {0x82, (interrupt_handler_t)SMED0_IRQHandler},          /* SMED0  irq6   */
    {0x82, (interrupt_handler_t)SMED1_IRQHandler},          /* SMED1  irq7   */
#if defined(_STNRG388A_) || defined(_STNRG328A_) || defined(_STNRG288A_)
    {0x82, (interrupt_handler_t)INPP3_IRQHandler},          /* irq8  */
#else
    {0x82, NonHandledInterrupt},                            /* irq8  */
#endif
    {0x82, NonHandledInterrupt},                            /* irq9  */
    {0x82, NonHandledInterrupt},                            /* irq10 */
    {0x82, NonHandledInterrupt},                            /* irq11 */
    {0x82, NonHandledInterrupt},                            /* irq12 */
    {0x82, NonHandledInterrupt},                            /* irq13 */
    {0x82, NonHandledInterrupt},                            /* irq14 */
    {0x82, (interrupt_handler_t)SMED2_IRQHandler},          /* SMED 2 irq15  */
    {0x82, (interrupt_handler_t)SMED3_IRQHandler}, 	        /* SMED 3 irq16  */
    {0x82, (interrupt_handler_t)UART_TX_IRQHandler},        /* UART_TX irq17 */
    {0x82, (interrupt_handler_t)UART_RX_IRQHandler},        /* UART_RX irq18 */
    {0x82, (interrupt_handler_t)I2C_IRQHandler},            /* I2C irq19 */
    {0x82, NonHandledInterrupt},                            /* irq20 */
    {0x82, NonHandledInterrupt},                            /* irq21 */
    {0x82, (interrupt_handler_t)ADC_IRQHandler},            /* ADC  irq22    */
    {0x82, (interrupt_handler_t)STMR_IRQHandler},           /* STMR irq23    */
    {0x82, (interrupt_handler_t)FLASH_IRQHandler},          /* FLASH irq24 */
    {0x82, (interrupt_handler_t)DALI_IRQHandler},           /* DALI  irq25   */
    {0x82, (interrupt_handler_t)SMED4_IRQHandler},          /* SMED4 irq26   */
    {0x82, (interrupt_handler_t)SMED5_IRQHandler},	        /* SMED5 irq27   */
    {0x82, NonHandledInterrupt},                            /* irq28 */
    {0x82, NonHandledInterrupt},                            /* irq29 */
};
//#endif
