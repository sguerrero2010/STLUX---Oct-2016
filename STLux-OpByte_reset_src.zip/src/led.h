/**
 ******************************************************************************
 * @file    led.h
 * @author  STMicroelectronics - L&C BU Application Team -
 * @version V1.0.5
 * @date    02/09/2011
 * @brief   Demo board for four led channel
 ******************************************************************************
 *
 * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
 * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
 * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
 * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
 * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
 * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
 *
 * <h2><center>&copy; COPYRIGHT 2012 STMicroelectronics</center></h2>
 ******************************************************************************
 *	HISTORY - 
 */


#ifndef __LED__H
#define	__LED__H

#include "uart.h"

/**
 * \brief	union for two consecutive byte and one word
 */
typedef union B2W_struct {
	vu8		b[2];	///< two byte, [0] is the upper field, [1] is the lower
	vu16	w;		///< is a b[0]:b[1] field union
} B2W;

// ====================================================
// ++++++++++++++++++++++++++++++++++++++++++++++++++++
// ====================================================
// Definition to use or not some features
#define USE_PORT_MEASURE	0
					// enable the DALI driver I/F using the STEVAL-ILM001V1 board
					// \note use DALI driver only when USE_PORT_MEASURE is disabled (0)
#if USE_PORT_MEASURE == 0
#define USE_DALI	0
#define	USE_DALIP_EXT_CMD 0
#endif
					// use the IWDG pher. if 1
#define	USE_IWDG	1

// ====================================================
// ++++++++++++++++++++++++++++++++++++++++++++++++++++
// ====================================================

#define FLASH_RASS_KEY1		0xAE
#define FLASH_RASS_KEY2		0x56

// define led bit position
#define	LED_R_b		0x04		///! port0.2 connected to led fault (red)
#define	LED_G_b		0x08		///! port0.3 connected to led run (green)
#if		USE_PORT_MEASURE
#define	SIGNAL_0	0x10		///! port0.4 SIGNAL 0
#define	SIGNAL_1	0x20		///! port0.5 SIGNAL 1
#endif

// into some test toggle Port0 bit 3
#define TRIG_TOG	GPIO0->ODR ^=  0x08;


#define	TICK_for_1S	1000		///! numbers of ticks into 1S
#define	TIMER_TICKS	(HSI_VALUE/TICK_for_1S)	///! Timer ticks value - HSI_VALUE are into stlux385.h


#define	IS_UNKN		0x00
#define	IS_385		0x01
#define	IS_385A		0x02
#define	IS_383A		0x03
#define	IS_325A		0x04
#define	IS_285A		0x05
#define	IS_388A		0x06
#define	IS_328A		0x07
#define	IS_288A		0x08
#define	IS_WBC		0x09

// global variable declaration
extern vu32	Time_T;
extern vu16	tick;
extern TINY vu8	rxcnt;
extern vu8	TINY	p_FL;
extern u8			ST_ID;



// global function declaration

extern void Setup_OptionByte_default( void );
extern u8	parse_monitor_cmd( char );
extern u8 Read_8_data_eeprom( u8* );
extern void Write_data_eeprom( u8 , u8* );
extern u8  Write_data_block( u16 , u8* );
extern void push_char(u8 c);
extern void Reset_EEPROM( void );

// extern declaration for EEPROM memory location
extern EEPROM u8 EE_one;
extern EEPROM u8 EE_two;

#endif  // __LED__H

