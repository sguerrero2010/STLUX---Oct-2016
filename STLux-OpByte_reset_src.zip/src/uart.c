/**
 ******************************************************************************
 * @file    uart.c
 * @author  STMicroelectronics - L&C BU Application Team
 * @version V1.0.0
 * @date    02/09/2011
 * @brief   Uart interface driver for STLux
 ******************************************************************************
 *
 * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
 * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
 * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
 * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
 * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
 * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
 *
 * <h2><center>&copy; COPYRIGHT 2012 STMicroelectronics</center></h2>
 ******************************************************************************
 *	This file contains the support functions to handle the UART buffer in
 *	interrupt mode
 ******************************************************************************
 */

#ifndef __UART__
#define	__UART__

#include <stdio.h>
#include "stlux.h"
#include "string.h"
#include "led.h"

// Locally global variables
volatile TINY u8	txcnt;			// transmitter buffer count
volatile u8	*txrpnt;				// transmitter read buffer pointer
volatile u8	*txwpnt;				// transmitter write buffer pointer
volatile u8	NEAR txbuff[TXSIZE];	// transmitter buffer
volatile TINY u8	rxcnt;			// receiver buffer count
volatile u8	*rxwpnt;				// receiver write buffer pointer
volatile u8	*rxrpnt;				// receiver read buffer pointer
volatile u8	NEAR rxbuff[RXSIZE];	// receiver buffer

/**
******************************************************************************************
*	\brief UART Transmit interrupt
*
*	The function is called at every TX interrupt to handle the transfer of the output
*	buffer.
*	If there are more than one character to transmit, send it and update count.
*	If there is only one character to transmit, change the interrupt from TIEN to TCIEN
*	and send it.
*	On the TCIEN interrupt disable the transmission interrupt until next send operation.
******************************************************************************************
*/

INTERRUPT_HANDLER( UART_TX_ISR, 17)
{
u8	status;

	status = UART->SR;			// read status register
	status &= UART->CR2;		// use only enabled flags
	if(status & UART_SR_TXE) {
		// Transmitter Empty interrupt
		UART->DR = *txrpnt++;				// write next character clearing pending TXE
		if(txrpnt >= &(txbuff[TXSIZE]) ) {
			txrpnt = txbuff;
		}
		if(txcnt == 1) {
			// last character in the buffer; switch to TCIEN
			UART->CR2 &= ~UART_CR2_TIEN;	// disable TIEN
			UART->CR2 |= UART_CR2_TCIEN;	// enable TCIEN
		}
		txcnt--;
	}
	else if(status & UART_SR_TC) {
		// Transmitter Completion Interrupt
		status = UART->SR;					// clear TC flag sequence
		status = UART->DR;	
		UART->CR2 &= ~UART_CR2_TCIEN;		// disable TCIEN
		txcnt = 0;
		txrpnt = txbuff;
		txwpnt = txbuff;
	}
    return;
}

/**
******************************************************************************************
*	\brief UART Receive interrupt
*
*	The function is called at every reception interrupt of the UART.
*	The received character is stored in the reception circular buffer and, the write
*	pointer and character count, are incremented. If the receiver buffer is full the
*	last received data is overwritten.
******************************************************************************************
*/

INTERRUPT_HANDLER( UART_RX_ISR, 18)
{
u8	status;

	status = UART->SR;			// read status register
	if(status & UART_SR_FE)                 // Frame error
	{
#if (USE_GPGUI_DEB)
		LineBreakDetection();
#endif
		rxcnt = UART->SR;				// clear frame error
		*rxwpnt = UART->DR;             // clear input byte
		rxwpnt = rxbuff;
		rxrpnt = rxbuff;   
		rxcnt = 0;
		return;
	}
	if(status & UART_SR_RXNE) {
		*rxwpnt = UART->DR;		// write last received character
		if(rxcnt <= RXSIZE) {
			// there is space
			rxwpnt++;
			rxcnt++;
			if(rxwpnt > &rxbuff[RXSIZE - 1]) {
				// wrap write pointer
				rxwpnt = rxbuff;
			}
		}
	} else if(status & UART_SR_OR ) {
		status = UART->DR;		// Clear overrun error
	}
	return;
}

/**
******************************************************************************************
*	\brief UART Initialization function
*
*	<b>Detail:</b>\n
*	The function is called during the startup phase to initialize the UART channel.
*	The UART uses GPIO00 as TX line and GPIO01 as RX line. The peripheral is initialized
*	to work as a standard USART interface 115200,N,8,1 and is completely interrupt driven.
******************************************************************************************
*/

void Uart_Init(void)
{
u8	c_tmp;

	if((ST_ID==IS_385A) || (ST_ID==IS_385) || (ST_ID==IS_388A) || (ST_ID==IS_383A)) {
		// if STLux385A
		// use GPIO00-GPIO01 as TX-RX lines for UART
		MSC->IOMXP0 &= ~0x03;			// clear P0 multiplexer for P0-P1
		MSC->IOMXP0 |=  0x01;			// set P0 multiplexer for P0-P1 as UART Tx-Rx
	} else if( ST_ID == IS_UNKN) {
		return; 
	} else {
		// For all others use GPIO04 and GPIO05
		// as TX-RX lines for UART
		MSC->IOMXP0 &= ~0x30;			// clear P0 multiplexer for P4-P5
		MSC->IOMXP0 |=  0x30;			// set P0 multiplexer for P4-P5 as UART Tx-Rx
	}

	UART->CR2 = UART_CR2_TEN|UART_CR2_REN;		// enable Transmitter and Receiver
	UART->CR1 = 0x00;				// no parity, 8 bits
	UART->CR3 = 0x00;				// 1 stop bit, LIN disabled
	UART->BRR2 = 0x0B;				// fractional part of baud rate for 115200 (115107)
	UART->BRR1 = 0x08;				// mantissa part of baud rate for 115200 (115107)
	c_tmp = UART->DR;				// read data register to clear pending interrupt
	rxrpnt = rxbuff;				// initialize receiver read pointer
	rxwpnt = rxbuff;				// initialize receiver write pointer
	txrpnt = txbuff;
	txwpnt = txbuff;
	rxcnt = 0;						// initialize receiver counter
	txcnt = 0;						// initialize transmit counter
	UART->CR2 = UART_CR2_TEN|UART_CR2_REN|UART_CR2_RIEN;	// enable Transmitter, Receiver and Receiver interrupt 
}

/**
******************************************************************************************
*	\brief UART Read function
*
*	<b>Detail:</b>\n
*	The function is called to read characters from the receiver buffer.
*	The function returns the character read or 0xFF if no character is available in the
*	buffer. It is assumed that the routine reads only ASCII characters, so 0xFF is
*	usable as empty marker.
*
*	\return	a char or an integer set to 0xFF if the buffer is empty.
******************************************************************************************
*/

u8 get_char(void)
{
u8 uc;

	if(rxcnt) {
		sim();
		rxcnt--;		//  update counter
		uc = *rxrpnt++;	// extract character and update read pointer
		rim();
		if(rxrpnt > &rxbuff[RXSIZE - 1]) {
			// wrap read pointer
			rxrpnt = rxbuff;
		}
		return(uc);
	}
	else {
		// no character available
		return 0xFF;
	}
}

/**
******************************************************************************************
*
*	\brief putchar - printf local interfaces function
*
*	<b>Detail:</b>\n
*	The function is called when the main program call the printf function
*	\note	txcnt is the character counter into buffer
*
*	\return	An integer set to 1 when correct - printf 
******************************************************************************************
*/

#ifdef _RAISONANCE_
int putchar(char c) reentrant
#else
int MyLowLevelPutchar(int c)
#endif
{
#if USE_IWDG
	IWDG->KR = 0xAA;	// refresh the time
#endif

#if !(USE_GPGUI_DEB)
	// hiperterminal like this
	if(c == '\n' ) {
#ifdef _RAISONANCE_
		putchar('\r');
#else
		MyLowLevelPutchar('\r');
#endif
	}
#endif

	// wait for free buffer
	while(txcnt >= TXSIZE ){
	   wfi();
	}

	// if no interrupt enable, enable it
	sim();			// disable interrupt
	if( ((UART->CR2 & UART_CR2_TCIEN) == 0) && ((UART->CR2&UART_CR2_TIEN) == 0) ) {
		UART->CR2 |= UART_CR2_TCIEN;	// enable only the TC bit
		UART->DR = c;					// write the first char into the output reg.
	} else {
		// store char
		*txwpnt++ = c;
		if(txwpnt >= &(txbuff[TXSIZE]) ) {
			txwpnt = txbuff;
		}
		txcnt++;	// next into the next position
		// clear TC bit and set TI bit
		if( (UART->CR2 & UART_CR2_TIEN) == 0 ) {
			UART->CR2 |= UART_CR2_TIEN;
			UART->CR2 &= ~UART_CR2_TCIEN;
		}
	}
	rim();			// re-enable interrupt
	return (1);
}

#ifdef _IAR_
#pragma module_name = "?__write"

size_t __write( int handle, const unsigned char * buf, size_t bufSize)
{
size_t nChars = 0;

	/* Check for the command to flush all handles */
	if (handle == -1) {
		return 0;
	}
	/* Check for stdout and stderr
	   (only necessary if FILE descriptors are enabled.) */
	if (handle != 1 && handle != 2) {
		return -1;
	}
	for (/* Empty */; bufSize > 0; --bufSize) {
		MyLowLevelPutchar (*buf);
		++buf;
		++nChars;
	}
	return nChars;

}
#endif

#endif // __UART__
