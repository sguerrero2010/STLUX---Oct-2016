/**
 ******************************************************************************
 * @file	main.c
 * @author	STMicroelectronics - L&C BU Application Team -
 * @version V1.0.10
 * @date	28/06/2012
 * @brief	Main code for STLUX-STNRG OPTION BYTE resotre
 ******************************************************************************
 *
 * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
 * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
 * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
 * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
 * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
 * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
 *
 * <h2><center>&copy; COPYRIGHT 2012 STMicroelectronics</center></h2>
 ******************************************************************************
 * the main code
 ******************************************************************************
 *	- HISTORY
 *		- R0 - startup the IDEA
 */

#define _REL_	0

#include <stdio.h>
#include "stlux.h"
#include "stlux_itc.h"
#include "led.h"

// global variable, used on other module

vu32			Time_T;				///< The time in "second" starting from power-on
vu16			tick;				///< used to store the tick - ticks is a 10kHz down counter
vu8		TINY	p_FL;		        ///< when one, 10KHz arrive

u8				ST_ID;


/**
 ******************************************************************************************
 *	\brief Timer ISR
 *
 *	ISR for the System Timer. 
 *
 *	\note	execution time is near few uS
 *
 ******************************************************************************************
 */

INTERRUPT_HANDLER( STMR_ISR, 23)
{
	STMR->SR1 = 0x00;					// clear pending interrupt

	p_FL++;

	// Update the internal time
	if((--tick) == 0) {
		tick=TICK_for_1S;
		Time_T++;
	}
	
}



/**
 ******************************************************************************************
 *	\brief Timer initialization.
 *
 *	The function initializes the System Timer to generate one interrupt every 100uS
 *	This time is used to manage all PFC and HB stage. When output power is fiew the
 *	timer interrupt is increase every 200uS or 500uS. 
 ******************************************************************************************
 */

void Timer_Init(void)
{
    p_FL = 0;
	Time_T = 0;					// setup time value to 0
	tick = TICK_for_1S;			// initialize ticks value
	STMR->CR1 = 0;				// disable counter
	STMR->CR1 = STMR_CR1_UDIS;	// update event disable
	STMR->ARRH = BYTE_1(TIMER_TICKS);			// autoreload count for 1K Hz 
	STMR->ARRL = BYTE_0(TIMER_TICKS);
	STMR->PSCL = 0x00;			// with prescaling by 1
	STMR->EGR = STMR_EGR_UG;	// generate update event
	STMR->CR1 = STMR_CR1_CEN;	// enable counter and update on overflow
	STMR->IER = STMR_IER_UIE;	// enable interrupt
}



/**
 ******************************************************************************************
 *	\brief "C" main entry
 *
 *	\param none
 ******************************************************************************************
 */

void main( void )
{
u8	rc;

	CLK->CKDIVR = 0x00;		// work with HSI at maximum frequency
							// setup Fcpu == HSI clock == 16MHz

	GPIO0->ODR = 0x3F;		// all lines to 1
	GPIO0->DDR = 0x3F;		// all lines to output
	GPIO0->CR1 = 0x3F;		// all lines in pushpull

	Time_T = 0;

	rc=((*REV_ID)&0x1F);

	if( rc == 0x00 && *DEV_ID==0x00 ) {
		ST_ID = IS_385;
	} else if( rc == 0x01 ) {
		if( *DEV_ID == 0x10 ) {
			ST_ID = IS_325A;
		} else if( *DEV_ID == 0x22) {
			ST_ID = IS_288A;
		} else if( *DEV_ID == 0x12) {
			ST_ID = IS_328A;
		} else if( *DEV_ID == 0x04) {
			ST_ID = IS_388A;
		} else if( *DEV_ID == 0x02) {
			ST_ID = IS_383A;
		} else if( *DEV_ID == 0x20) {
			ST_ID = IS_285A;
		} else if( *DEV_ID == 0x80) {
			ST_ID = IS_WBC;
		} else if( *DEV_ID == 0x00) {
			ST_ID = IS_385A;
		} else {
			ST_ID = IS_UNKN;
		}
	} else {
		ST_ID = IS_UNKN;
	}

    Uart_Init();
	Timer_Init();

	CLK->PLLR |= CLK_PLLR_PLLON;
	while((CLK->PLLR & CLK_PLLR_LOCKP) == 0); 

	// enable interrupt
	// NOTE: not use printf before this line
	rim();

	CLK->PCKENR2 = 0x80;		// STOP all SMED clock

    F_gest();
    Setup_OptionByte_default( );
    Reset_EEPROM();
    F_rese();

	// MAIN LOOP START
	while(1) {
		// ----------------------------------------
		// check if char ready from UART
		if(rxcnt) {
			rc = get_char();
			if(rc != 0xFF) {
				// store and command execution
				parse_monitor_cmd(rc);
			}
		}
//		wfi();
	}
}
