/**
 ******************************************************************************
 * @file    mo_cmd.c
 * @author  STMicroelectronics - L&C BU Application Team -
 * @version V1.0.5
 * @date    02/09/2011
 * @brief   parse the command line
 ******************************************************************************
 *
 * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
 * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
 * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
 * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
 * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
 * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
 *
 * <h2><center>&copy; COPYRIGHT 2012 STMicroelectronics</center></h2>
 ******************************************************************************
 * this file contain the command line interpreter and execution routines
 ******************************************************************************
 *	HISTORY - 
 *	detect "0x" argument and expand to decimal value
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "stlux.h"
#include "led.h"

// declare used function
u8 F_null( void );
u8 F_dmem( void );
u8 F_regr( void );
u8 F_regw( void );
u8 F_time( void );
u8 F_gest( void );
u8 F_rese( void );


typedef u8 (*FUNC)( void );	

typedef struct _MO_CMD {
	const char	*a;			///< command string
	const char	*o;			///< command option
	u8			opt;		///< number of option parameter - 0 not necessary present, 1 present
//	u8			par;		///< number of parameter - from 0 to 3 - use all input when 99 
	const char	*mo;		///< detail of command string
#ifdef _RAISONANCE_
		  FUNC	exec_;		///< executed routine
#elif defined (_IAR_)
	u8 (__near_func * exec_) (void) ;
#endif
} MO_CMD;


CONST MO_CMD mo_cmd [] = {
// cmd ,  option argument,     arg num,	Detail
// tk_c,  tk_2 tk_3,

{ "st" , "",					0x00,	"Get status", F_gest} ,									// ok
{ "rs" , "",					0x00,	"erase flash", F_rese} ,								// ok

{ "md" , "[add] [len]",			0x12,	"dump register/memory", F_dmem} ,						// ok
{ "rr" , "[add]",				0x11,	"get register/memory", F_regr} ,						// ok
{ "rw" , "[add] [dat]",			0x12,	"write register/memory", F_regw} ,						// ok

{ "ti" , "",					0x00,	"Get time", F_time} ,									// ok

{ "?"  , "",					0x00,	"get help", F_null } ,
{ ""   , "",					0x00,	"", F_null } ,		// last line terminator ?
};

#define	LINE_LENGTH	RXSIZE
#define	MAX_TOK		4
NEAR        	char	line[LINE_LENGTH];		///< store received character 
NEAR        	u8		pos=0;					///< store position at line[]
NEAR const  	char	*tk_c;					///< to store command token
NEAR const  	char	*tk_2;					///< to store single token
NEAR const  	char	*tk_3;					///< to store single token
NEAR const  	char	*tk_4;					///< to store single token

vu8	Is_Exit_From_HALT;
void printul( u32 );

void get_help( void )
{
u8 i;
	printf("Monitor channel command\n");
	for( i=0 ; mo_cmd[i].a != "" ; i++ ) {
        if(mo_cmd[i].opt&0x20) {
            continue;
        }
		printf("%-2s %-18s %s\n", mo_cmd[i].a, mo_cmd[i].o, mo_cmd[i].mo);
	}
	printf("use [enter] to end line, use [backspace] to delete char\n");
}




#if 0

//================================
IN_RAM(void FLASH_ProgramBlock(uint16_t BlockNum, FLASH_MemType_TypeDef FLASH_MemType,  
                        FLASH_ProgramMode_TypeDef FLASH_ProgMode, uint8_t *Buffer)) 
{ 
    uint16_t Count = 0; 
    uint32_t startaddress = 0; 

 
    /* Check parameters */ 
    assert_param(IS_MEMORY_TYPE_OK(FLASH_MemType)); 
    assert_param(IS_FLASH_PROGRAM_MODE_OK(FLASH_ProgMode)); 
    if (FLASH_MemType == FLASH_MEMTYPE_PROG) 
    { 
        assert_param(IS_FLASH_PROG_BLOCK_NUMBER_OK(BlockNum)); 
        startaddress = FLASH_PROG_START_PHYSICAL_ADDRESS; 
    } 
    else 
    { 
        assert_param(IS_FLASH_DATA_BLOCK_NUMBER_OK(BlockNum)); 
        startaddress = FLASH_DATA_START_PHYSICAL_ADDRESS; 
    } 

 
    /* Point to the first block address */ 
    startaddress = startaddress + ((uint32_t)BlockNum * FLASH_BLOCK_SIZE); 


    /* Selection of Standard or Fast programming mode */ 
    if (FLASH_ProgMode == FLASH_PROGRAMMODE_STANDARD) 
    { 
        /* Standard programming mode */ /*No need in standard mode */ 
        FLASH->CR2 |= FLASH_CR2_PRG; 
        FLASH->NCR2 &= (uint8_t)(~FLASH_NCR2_NPRG); 
    } 
    else 
    { 
        /* Fast programming mode */ 
        FLASH->CR2 |= FLASH_CR2_FPRG; 
        FLASH->NCR2 &= (uint8_t)(~FLASH_NCR2_NFPRG); 
    } 


    /* Copy data bytes from RAM to FLASH memory */ 
    for (Count = 0; Count < FLASH_BLOCK_SIZE; Count++) 
    { 
#if defined (STM8S208) || defined(STM8S207) || defined(STM8S007) || defined(STM8S105) || \ 
    defined(STM8S005) || defined (STM8AF62Ax) || defined (STM8AF52Ax) || defined (STM8AF626x) 
  *((PointerAttr uint8_t*) (uint16_t)startaddress + Count) = ((uint8_t)(Buffer[Count])); 
#elif defined(STM8S103) || defined(STM8S003) ||  defined (STM8S903) 
  *((PointerAttr uint8_t*) (uint16_t)startaddress + Count) = ((uint8_t)(Buffer[Count])); 
#endif        
    } 
} 
#endif


//================================


extern __ramfunc void FlEra( void );


/**
 *  \brief function to reset (set to 0) the first 256 byte of the FLASH memory area
 */
u8 F_rese( void )
{
    sim();      // disable any interrupts
    FlEra();
    rim();
    return 0;
}

/**
 *  \brief function to read the time
 */
u8 F_time ( void )
{
	printf("Time is ");
	printul(Time_T);
	printf(":%04d\n", tick );
	return 0;
}


/**
 *	\brief function to get internal status
 */
u8 F_gest ( void )
{

	switch(ST_ID) {
		case IS_385:
			printf("Is STLUX385");
			break;
		case IS_385A:
			printf("Is STLUX385A");
			break;
		case IS_383A:
			printf("Is STLUX383A");
			break;
		case IS_325A:
			printf("Is STLUX325A");
			break;
		case IS_285A:
			printf("Is STLUX325");
			break;
		case IS_388A:
			printf("Is STNRG388A");
			break;
		case IS_328A:
			printf("Is STNRG328A");
			break;
		case IS_288A:
			printf("Is STNRG288A");
			break;
		case IS_WBC:
			printf("Is STWBC");
			break;
		default:
			printf("Is unknown");
	}

#if 0
	pt = (u8*) &(ADC->DATL_0);

	for(i=0; i<8 ; i++) {
		ww.b[1] = *pt; // low part into proper word space
		pt++;
		ww.b[0] = *pt; // high part into proper word space
		pt++;
		printf("CH%d=%d ", i, ww.w);
	}
#endif
	printf("\n");
	return 0;
}


/**
 *	\brief function to dump a memory area
 */
u8 F_dmem ( void )
{
u16 ad, le, i;
u8*	addr=0;
u8 dat;

	ad = atoi(tk_2);
	le = atoi(tk_3);

	printf("Dump mem\n");
	for( i=0 ; i<le ; i++ ) {
		if((i&0x0F) == 0x00) {
			printf("ad 0x%04x", (ad));
		}

		dat = *(addr+ad);
		printf("-%02x", dat);
		ad++;

		if((i&0x0F) == 0x0F) {
			printf("\n");
		}
	}
	if((i&0x0F) != 0x00) {
		printf("\n");
	}
	return 0;		// no error
}

/**
 *	\brief function to read a register address
 */
u8 F_regr ( void )
{
u16 ad;
u8*	addr=0;
u8 dat;

	ad = atoi(tk_2);
	dat = *(addr+ad);
	printf("Read mem 0x%04x is 0x%02x\n", addr+ad, dat);
	return 0;		// no error
}

/**
 *	\brief function to write a register address
 */
u8 F_regw ( void )
{
u16 ad;
u8*	addr=0;
u8 dat;

	ad = atoi(tk_2);
	dat = atoi(tk_3);
	*(addr+ad) = dat;
	printf("Write mem 0x%04x to 0x%02x\n", ad, dat);
	return 0;		// no error
}



/**
 * used to print u32 numbers only - simplified version
 *
 * return	strings output to console 
 */

/* the following should be enough for u32 only */
#define PRINT_BUF_LEN 12
#define PRINT_BUF_BASE 10
#define PRINT_BUF_LETB 'A'

void printul( u32 i )
{
// temp buff.
char print_buf[PRINT_BUF_LEN];
char *s;
u32 u = i;
u16 t;

	// pointer start on last position
	s = print_buf + PRINT_BUF_LEN-1;
	// safety action ;-)
	*s = '\0';

	while (u) {
		t = u % PRINT_BUF_BASE;
		if( t >= 10 )
			t += PRINT_BUF_LETB - '0' - 10;
		*--s = t + '0';
		u /= PRINT_BUF_BASE;
	}
	// output result
	printf("%s",s);
}

/**
 * =========================================
 * service subroutines
 * =========================================
 */
/**
 * Convert an ASCII character to its integral value.
 * '0' returns 0,
 * '9' returns 9,
 * 'A' and 'a' return 10,
 * 'F' and 'f' return 15,
 * Other char return 0xff values.
 *
 * @par c character to convert ('0':'9'-'A':'F')
 * @retval converted value or 0xff when invalid
 */
u8 char2hex( u8 c )
{
	c-='0';
	if( c > 9 ) {
		// is other
		c-=7;
		if(c > 15) {
			// not [A-F]
			c-=0x20;
			if(c > 15 ) {
				// not [a-f]
				c=0xff;
			}
		}
	}
	return c;
}


/** **************************************************************************************
*	\brief null command
*	<b>Detail:</b>\n
*	subroutines for null command
*	\return	0 in any case
*****************************************************************************************/
u8 F_null ( void )
{
	printf("SORRY, not yet implemented\n");
	return 0;
}

/** **************************************************************************************
 *	\brief search token into command line
 *	<b>Detail:</b>\n
 *	parse single command received and extract token, call only one time 
 *	extract also a hex number on tk2 or tk3, if present
 *	\return	0
 *****************************************************************************************/
u8 searc_tock( void )
{
char	*tk = " ";
u8 x, i, y;
u16 num, mask=0x00FF;

	// parse line and check argument
	tk_c = strtok( &line[0], tk);
	tk_2 = strtok( NULL, tk);
	tk_3 = strtok( NULL, tk);
	tk_4 = strtok( NULL, tk);
	// search hexadecimal value on first token - "0x" token
	x = strncmp(tk_2, "0x", 2);
	if(!x){
		num=0;
		y = strlen(tk_2)-1;		// remove end char strings
		if(y>2) {
			for(i=0; i<(y-1) ; i++) {
				// start from the last char
				x = char2hex((tk_2[y-i])&mask);
				if(x == 0xFF) {
					// error on strings
					return 1;
				}
				num += (x<<(i*4));
			}
		}
		sprintf((char*)tk_2, "%04d", num);
	}
	x = strncmp(tk_3, "0x", 2);
	if(!x){
		num=0;
		y = strlen(tk_3)-1;		// remove end char strings
		if(y>2) {
			for(i=0; i<(y-1) ; i++) {
				// start from the last char
				x = char2hex((tk_3[y-i])&mask);
				if(x == 0xFF) {
					// error on strings
					return 1;
				}
				num += (x<<(i*4));
			}
		}
		sprintf((char*)tk_3, "%04d", num);
	}

	return 0;
}

/** **************************************************************************************
 *	\brief parse single line
 *	<b>Detail:</b>\n
 *	parse single command received
 *	\param	i is index for the position into mo_cmd structure
 *	\return	0 if command syntax is correct, 1 if not found or 2 if error on command syntax
 *	\note search also on next line [i] when command is equal
 *****************************************************************************************/
u8 parse_line( u8 i )
{
	
	switch(mo_cmd[i].opt&0x0F) {
		case 0:
			if((tk_2!=0) ) {
				return 1;
			}
			break;
		case 1:
			if((tk_2==0) || (tk_3!=0) ) {
				return 1;
			}
			break;
		case 2:
			if((tk_3==0) || (tk_4!=0) ) {
				return 1;
			}
			break;
		case 3:
			if( tk_4==0 ) {
				return 1;
			}
			break;
		case 99:
			// use all input char, not check
			break;

		default:
			return 2;
	}

//	printf("T1:%s; T2:%s; T3:%s; T4:%s\n", tk_c, tk_2, tk_3, tk_4);

	return 0;
}


/** **************************************************************************************
*	\brief parse single char from monitor line
*	\author	BOHO
*	<b>Detail:</b>\n
*	parse monitor line, execute command, manage backspace, etc.
*	\param	c is the character received from command line
*	\return	0 if command not completed, 1 if is completed and executed, 2 if error
*****************************************************************************************/
u8	parse_monitor_cmd( char c )
{
u8 i;
static u8 last=0;
	
	switch( c ) {
		case '?':
			get_help();

			pos=0;
			break;

#if USE_T_MUL
		case '-':
			dec_dimm( 0 );
			break;

		case '+':
			inc_dimm( 0 );
			break;
#endif

		case '.':
			// "." repeat last command
			if( last == 0 ) {
				break;
			}
			i = last;
			if( mo_cmd[i].exec_ ()) {
				// command error
				printf("error on [%s] cmd\n", &line[0]);
				pos=last=0;
				return 2;
			}
			break;

		case '\03':
			printf("\n ");
			pos=0;
			break;

		case '\b':
			// erase last char
			if(pos) {
				printf("\b \b");
				line[pos]=0;	// mark last position
				pos--;
			}
			break;

		case '\n':
		case '\r':
			// parse command
			if( pos == 0 ) {
				printf("give me one char\n");
				break;
			}
			// put terminator strings at end
			line[pos] = 0;
			
			// decompose line into single tock
			if( searc_tock( )) {
				printf("\nerror\n");
				pos=last=0;
				return 2;
			}

			// search into command line
			for( i=0 ; mo_cmd[i].a != ""; i++ ) {
				// compare command
				if (strncmp(tk_c, mo_cmd[i].a , 2) == 0) {
					// compare option
					if(parse_line( i ) == 0) {
						// command execution
						putchar('\n');
						if( mo_cmd[i].exec_ ()) {
							// command error
							printf("error on [%s] cmd\n", &line[0]);
							pos=last=0;
							return 2;
						}
						last=i;
						pos=0;
						return 1; // command executed
					}
				}
			}
			if(mo_cmd[i].a == "") {
				printf("\nwhat?: [%s] -- use [?] to get command\n", &line[0]);
			}
			pos=last=0;
			break;

		default:
			// add new character
			if( pos >= LINE_LENGTH ) {
				// to many char into buffer
				// do not add, please
				break;
			}
			// add char to buffer
			line[pos++] = c;
			putchar(c);
	}

	return 0;
}

#pragma section="MY_RAM"

__ramfunc void FlEra( void )
{
u8 i = 0;
u8 d = 0;
u8* ad;
    // enable flash writing
    if(!(FLASH->IAPSR & FLASH_IAPSR_PUL)) {
        FLASH->PUKR = 0x56;
        FLASH->PUKR = 0xAE;    
    }
    if((FLASH->IAPSR & FLASH_IAPSR_PUL) == 0) {
        return;
    }

    ad = (u8*) 0x8000;
    for(i=0; i<255; i++) {
        FLASH->CR2 |= FLASH_CR2_ERASE; 
        FLASH->NCR2 &= (u8)(~FLASH_CR2_ERASE); 

        *ad = d;        // erase the entire first FLASH memory block (128 Byte)
        ad++;
        *ad = d;
        ad++;
        *ad = d;
        ad++;
        *ad = d;
    
        // wait end write
        while(!(FLASH->IAPSR & FLASH_IAPSR_EOP)) {
            d++;
        }
        d=0;
        ad +=124;       // point to the next FLASH page
    }

    // restore access to FLASH
    FLASH->CR2 = 0x00; 
    FLASH->NCR2 = 0xFF; 
 
    ad = (u8*) 0x8000;
    for (i=0;i<0x4;i++) {
        if (*ad!= d) {
            while(1) {
                d++;
            }
            return ;
        }
        ad++;
    }
}


