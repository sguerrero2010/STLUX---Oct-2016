/**
 ******************************************************************************
 * @file    man_ee.c
 * @author  STMicroelectronics - L&C BU Application Team -
 * @version V1.0.1
 * @date    02/09/2011
 * @brief   manage the data eeprom and the startup value
 ******************************************************************************
 *
 * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
 * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
 * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
 * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
 * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
 * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
 *
 * <h2><center>&copy; COPYRIGHT 2012 STMicroelectronics</center></h2>
 ******************************************************************************
 * prepare, restore and save the main data into data EEPROM area
 ******************************************************************************
 *	HISTORY - 
 */


#include <stdio.h>
#include "stlux.h"
#include "led.h"

extern void  Wait_EEWrite_end( void );
// only one EEPORM location, point to the first location??
EEPROM u8 EE_one;



/**
 ******************************************************************************************
 *	\brief read one byte from eeprom data area
 *
 *	The function is called by the main to read the eeprom value
 *
 *	\param *addr to read data
 *	\return byte read from *addr
 ******************************************************************************************
 */
u8 Read_8_data_eeprom( u8* addr )
{
	Wait_EEWrite_end();
	return *addr;
}

/**
 ******************************************************************************************
 *	\brief read two byte from eeprom data area
 *
 *	The function is called by the main to read one u16 from eeprom value
 *
 *	\param *addr to read data
 *	\return byte read from *addr
 ******************************************************************************************
 */
u16 Read_16_data_eeprom( u8* addr )
{
u16 i;
	Wait_EEWrite_end();
	i=*addr;
	i+= (*(addr+1))<< 8;
	return i;
}

/**
 ******************************************************************************************
 *	\brief write one location into eeprom
 *
 *	The function is called by the main to write one eeprom value
 *
 *	\param val		value to be stored
 *	\param *addr	address to store the val
 *	\return none
 ******************************************************************************************
 */
void Write_data_eeprom( u8 val, u8* addr)
{

  	if(!(FLASH->IAPSR & FLASH_IAPSR_DUL)) {
		// unlook data zone write operation
		FLASH->DUKR = FLASH_RASS_KEY1;
		FLASH->DUKR = FLASH_RASS_KEY2;
	}

	Wait_EEWrite_end();
	if(*addr != val ) {
		*addr = val;
	}
}

/**
 ******************************************************************************************
 *	\brief write two location into eeprom
 *
 *	The function is called by the main to write two byte eeprom value
 *
 *	\param val		value to be stored
 *	\param *addr	address to store the val
 *	\return none
 ******************************************************************************************
 */
void Write_16_data_eeprom( u16 val, u8* addr)
{

  	if(!(FLASH->IAPSR & FLASH_IAPSR_DUL)) {
		// unlook data zone write operation
		FLASH->DUKR = FLASH_RASS_KEY1;
		FLASH->DUKR = FLASH_RASS_KEY2;
	}

	Wait_EEWrite_end();
	if(*addr != (val&0xFF) ) {
		*addr = (val&0xFF);
	}
	if(*(addr+1) != ((val>>8)&0xFF) ) {
		*(addr+1) = ((val>>8)&0xFF);
	}

}

/**
* @brief  wait end of last write operation
*/
void  Wait_EEWrite_end( void )
{
	// wait previous write operation, if pending
	while((FLASH->IAPSR & FLASH_IAPSR_EOP)) {
		IWDG->KR = 0xAA;	// refresh IWDG time
		wfi();
	}
}


/**
 ******************************************************************************************
 *	\brief copy one block from ram to eeprom data area
 *
 *	this routine store into data eeprom one code area
 *
 *	\param len	length of the area to be copied
 *	\param *buf	buffer pointer of address to be copied
 *	\return 0 if correcting write, otherwise != 0
 ******************************************************************************************
 */
u8  Write_data_block( u16 len, u8* buf)
{
u16 i;
u8*	loc = (u8*)&EE_one;		// first location to store
u8* tmp;
u8 wr_cnt = 0;

  	if(!(FLASH->IAPSR & FLASH_IAPSR_DUL)) {
		// unlook data zone write operation
		FLASH->DUKR = FLASH_RASS_KEY1;
		FLASH->DUKR = FLASH_RASS_KEY2;
	}

	tmp = buf;
	// Write
	for( i=0; i<len ; i++) {
		if(*loc != *tmp) {
			// write new val
			*loc++ = *tmp++;
			Wait_EEWrite_end();
            wr_cnt++;
		} else {
			// skip
			loc++;
			tmp++;
		}
	}

	// check
	loc = (u8*)&EE_one;
	for( i=0; i<len ; i++) {
		if(*loc++ != *buf++) {
			return 0xFF;
		}
	}
	return wr_cnt;
}

/**
 * \brief write into all EEPROM and check correcting value
 *        Use last 0x400 byte of ram at 0x300 to allocate the writing
 *        buffer.
 *
 */
void Reset_EEPROM( void )
{
u8* i;		// address pointer
u16 cnt;
u8	da;
u8  x;

	// reset EEPROM location
	x = da = 0;
    i = (u8*)(0x4000);
	for(cnt=0; cnt<0x400; cnt++) {
	    Wait_EEWrite_end();
        if(*i != da) {
            Write_data_eeprom( da, i );
            x++;
        }
		i++;
	}

    i = (u8*)(0x4000);
	for(cnt=0; cnt<0x400; cnt++) {
        if(Read_8_data_eeprom( i ) != da){
            x=0xff;
            break;
        }
		i++;
	}

	if( x == 0xff ) {
		printf("EEPROM Error\n");
		return ;
	}

	// sorry but is available only in debug mode, not in run mode, 
    if(x == 0) {
	    printf("EEPROM ok\n");
    } else {
	    printf("EEPROM erased\n");
    }

	return ;
}
